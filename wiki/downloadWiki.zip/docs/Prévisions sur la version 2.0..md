La version 2.0 incluera :

**Tabbed MDI**
**RibbonBar**