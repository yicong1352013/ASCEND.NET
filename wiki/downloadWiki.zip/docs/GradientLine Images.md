![](GradientLine Images_GradientLineGradient.png)

![](GradientLine Images_GradientLineGlass.png)

![](GradientLine Images_GradientLineGradientVertical.png) ![](GradientLine Images_GradientLineGlassVertical.png) ![](GradientLine Images_GradientLineDesign.png)

The GradientLine control has most of the capabilities of the GradientPanel control without the overhead of a container control.