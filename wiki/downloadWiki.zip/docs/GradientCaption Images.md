![](GradientCaption Images_GradientCaptionGradient.png)

![](GradientCaption Images_GradientCaptionGlass.png)

![](GradientCaption Images_GradientCaption2.png)

![](GradientCaption Images_GradientCaption3.png)

![](GradientCaption Images_GradientCaptionDesign2.png)