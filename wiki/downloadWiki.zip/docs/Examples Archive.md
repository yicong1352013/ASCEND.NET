**Beta 3 English examples**

Google Talk look and feel 
   A simple form using transparencies and curved corners.
   ![](Examples Archive_Down.png) [GoogleStyleBeta3.zip](Examples Archive_GoogleStyleBeta3.zip) C#

**Beta 2 English examples**

Google Talk look and feel 
   A simple form using transparencies and curved corners.
   ![](Examples Archive_Down.png) [GoogleStyleBeta2.zip](Examples Archive_GoogleStyleBeta2.zip) C#

**Beta 1 English examples**

Google Talk look and feel 
   A simple form using transparencies and curved corners.
   ![](Examples Archive_Down.png) [GoogleStyle.zip](Examples Archive_GoogleStyle.zip) C#