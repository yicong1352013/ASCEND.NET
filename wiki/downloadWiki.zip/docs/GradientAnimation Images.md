![](GradientAnimation Images_GradientAnimation.png)

![](GradientAnimation Images_GaradientAnimation2.png) ![](GradientAnimation Images_GradientAnimationDesign.png)