{rss:url=http://scorn.wordpress.com/rss2/}
{rss:url=http://www.feedster.com/search/type/rss/"Ascend.NET" Windows Forms Controls}
{rss:url=http://blogs.developpeur.org/sebmafate/rss.aspx?Tags=Ascend.Net&AndTags=1}