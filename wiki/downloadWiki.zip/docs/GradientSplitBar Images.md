![](GradientSplitBar Images_SplitBar21.png)

![](GradientSplitBar Images_SplitBarGlassHorizontal.png)

![](GradientSplitBar Images_SplitBar22.png) ![](GradientSplitBar Images_GradientSplitBarGlassVertical.png) ![](GradientSplitBar Images_GradientSplitBarDesign2.png)