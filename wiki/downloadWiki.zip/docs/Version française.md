![](Version française_LogoLarge.png)

### **Bienvenue**

Ascend.NET est une bibliothèque de contrôles Windows Forms écrite en C# pour Visual Studio 2005 et .net 2.0.
Le but est de proposer des contrôles flexibles et faciles d'utilisation pour une utilisation massive.

**Highlights**
![](Version française_Line.png)  
![](Version française_SmallSquare.png) **[Help us determine the controls that would best benefit the community.](http://www.codeplex.com/Project/ListThreads.aspx?ProjectName=ASCENDNET&ForumId=1003)**
![](Version française_SmallSquare.png) **[Version 1.5 planning and specifications.](Version-1.5-planning-and-specifications.)**
![](Version française_SmallSquare.png) **[Prévisions sur la version 2.0.](Prévisions-sur-la-version-2.0.)**
![](Version française_SmallSquare.png) **[Exemples](Exemples)**
![](Version française_SmallSquare.png) **Le projet est en cours de localisation en français, allemand et russe.**

Les langages actuellement disponibles sont l'anglais et le chinois (simplifié).
La version 1 contient les contrôles suivant :

![](Version française_GradientLinePreview.png) **GradientLine**

Un contrôle affichant une ligne supportant les modes : unie, dégradé et _glass_.  Les couleurs, le sens et le type de dégradé sont configurables.
   ![](Version française_SmallArrow.png) [GradientLine Images](GradientLine-Images)

![](Version française_GradientPanelPreview.png) **GradientPanel** 

Voici un panel supportant les modes de couleurs solide, gradient et _glass_. Les couleurs, le sens, le pourcentage de transition, la luminance et le mode de dégradé sont configurables. Les bordures sont aussi configurables et il est possible d'arrondir les angles.
   ![](Version française_SmallArrow.png) [GradientPanel Images](GradientPanel-Images)

![](Version française_GradientCaptionPreview.png) **GradientCaption**

Un libellé qui supporte les modes de couleurs solide, gradient et _glass_. Les couleurs, le sens, le pourcentage de transition, la luminance et le mode de dégradé sont configurables. Les bordures sont aussi configurables et il est possible d'arrondir les angles. Supporte l'alignement du texte et de l'image indépendamment. Au contraire du contrôle Label du framework .net, si l'image et le texte sont alignés du même coté, ils ne se chevauche pas.
   ![](Version française_SmallArrow.png) [GradientCaption Images](GradientCaption-Images)

![](Version française_GradientSplitbarPreview.png) **GradientSplitBar** 

Barre de séparation supportant les modes de couleurs solide, gradient et _glass_. Les couleurs, le sens, le pourcentage de transition, la luminance et le mode de dégradé sont configurables. 
   ![](Version française_SmallArrow.png) [GradientSplitBar Images](GradientSplitBar-Images)

![](Version française_GradientNavigationButtonPreview.png) **GradientNavigationButton**

Bouton de navigation qui supporte les modes de couleurs solide, gradient et _glass_. Le sens, le pourcentage de transition, la luminance et le mode de dégradé sont configurables. Les couleur sont personnalisables pour chaque état du bouton. Les bordures sont aussi configurables et il est possible d'arrondir les angles. Supporte l'alignement du texte et de l'image indépendamment. Au contraire du contrôle Label du framework .net, si l'image et le texte sont alignés du même coté, ils ne se chevauche pas. 
   ![](Version française_SmallArrow.png) [GradientNavigationButton Images](GradientNavigationButton-Images)

![](Version française_GradientAnimationPreview.png) **GradientAnimation** 

Contrôle affichant un dégradé animé. Les couleurs, bordures et type de dégradé sont paramétrables.
   ![](Version française_SmallArrow.png) [GradientAnimation Images](GradientAnimation-Images)

![](Version française_GradientNavigationPanePreview.png) **NavigationPane**

Contrôle de navigation supportant les modes de couleurs solide, gradient et _glass_. Les couleurs, textes et alignements d'images sont configurables pour toutes les parties du contrôle. L'utilisateur final peut choisir d'afficher ou de masquer et de trier les boutons.
   ![](Version française_SmallArrow.png) [NavigationPane Images](NavigationPane-Images)


**La beta 4 est dès à présent disponible et supporte les dégradés à la mode Office 2007 !**

![](Version française_GradientNavigationButtonCurve.png) ![](Version française_GradientNavigationButtonCurve2.png)

Si vous êtes intéressés, nous vous invitons à rejoindre ce projet. Rendez-vous dans le forum "Project Management" dans la section "Discussions" et parlez nous de ce que vous aimeriez faire. Si vous ne souhaitez pas prendre part aux développements, nous avons aussi besoin de testeurs, de rédacteurs pour les  fichiers d'aide et de personnes pour rédiger des exemples simples. Moins de temps les développeurs passent à faire ces choses et plus nous avons le temps de développer des fonctionnalités et des outils sympa.