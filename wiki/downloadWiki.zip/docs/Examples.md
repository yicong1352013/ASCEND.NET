Downloads on this page are user requested and Ascend Project developer initiated examples. They are not what we would consider best practices or production ready code.

**If you have an example using the Ascend controls please add a post in users forum and we will add it to the examples.**

**RTM Production 1.0.0.6 English examples**

Google Talk look and feel 
   A simple form using transparencies and curved corners.
   ![](Examples_Down.png) [GoogleStyleRTM1.0.0.6.zip](Examples_GoogleStyleRTM1.0.0.6.zip) C#

Outlook 2003 look and feel
   A form using the NavigationPane and GradientCaption controls to give a Outlook 2003 look.
   ![](Examples_Down.png) [OutlookExampleRTM1.0.0.6.zip](Examples_OutlookExampleRTM1.0.0.6.zip) C#

Dynamically adding navigation pane panels to the NavigationPane control (coming soon)
   How to add navigation pane panels to the NavigationPane at run time.
   ![](Examples_Down.png) [DynamicNavigationPaneRTM1.0.0.6.zip](Examples_DynamicNavigationPaneRTM1.0.0.6.zip) C#

Ribbon bar panel look and feel (coming soon)
   How to use the GradientPanel and GradientNavigationButton controls to approximate a Office 2007 ribbon bar item.

A logon dialog using the GradientAnimation control
   A logon dialog using the GradientAnimation control with ApplicationContext and a BackgroundWorker.
   ![](Examples_Down.png) [AnimatedLogonRTM1.0.0.6.zip](Examples_AnimatedLogonRTM1.0.0.6.zip) C#

Curved corners and back colors (coming soon)
   Curved corners dos and don’ts.

Different glass appearances with the GradientPanel (coming soon)
   Using the GradientPanel glass properties to get different looks.

Scrolling and gradient backgrounds
   A simple form with a gradient background that scrolls the controls but not the gradient.
   ![](Examples_Down.png) [GradientBackgroundAndScrollRTM1.0.0.6.zip](Examples_GradientBackgroundAndScrollRTM1.0.0.6.zip) C#

**RC 1 English examples**

Google Talk look and feel 
   A simple form using transparencies and curved corners.
   ![](Examples_Down.png) [GoogleStyleRC1.zip](Examples_GoogleStyleRC1.zip) C#

Outlook 2003 look and feel
   A form using the NavigationPane and GradientCaption controls to give a Outlook 2003 look.
   ![](Examples_Down.png) [OutlookExampleRC1.zip](Examples_OutlookExampleRC1.zip) C#

Dynamically adding navigation pane panels to the NavigationPane control (coming soon)
   How to add navigation pane panels to the NavigationPane at run time.
   ![](Examples_Down.png) [DynamicNavigationPaneRC1.zip](Examples_DynamicNavigationPaneRC1.zip) C#

A logon dialog using the GradientAnimation control
   A logon dialog using the GradientAnimation control with ApplicationContext and a BackgroundWorker.
   ![](Examples_Down.png) [AnimatedLogonRC1.zip](Examples_AnimatedLogonRC1.zip) C#

Scrolling and gradient backgrounds
   A simple form with a gradient background that scrolls the controls but not the gradient.
   ![](Examples_Down.png) [GradientBackgroundAndScrollRC1.zip](Examples_GradientBackgroundAndScrollRC1.zip) C#

**Beta 4 English examples**

Google Talk look and feel 
   A simple form using transparencies and curved corners.
   ![](Examples_Down.png) [GoogleStyleBeta4.zip](Examples_GoogleStyleBeta4.zip) C#

Outlook 2003 look and feel
   A form using the NavigationPane and GradientCaption controls to give a Outlook 2003 look.
   ![](Examples_Down.png) [OutlookExampleBeta4.zip](Examples_OutlookExampleBeta4.zip) C#

[Examples Archive](Examples-Archive)