**GradientPanel**

![](Images_GradientPanel.png)

![](Images_GradientPanel2.png)

**GradientCaption**

![](Images_GradientCaption.png)

![](Images_GradientCaption2.png)

**GradientSplitBar**

![](Images_GradientSplitBar.png)

**GradientNavigationButton**

![](Images_GradientNavigationButton.png)

![](Images_GradientNavigationButton2.png)

![](Images_GradientNavigationButton3.png)

**GradientAnimation**

![](Images_GradientAnimation.png)

**NavigationPane**

![](Images_NavigationPane.png)