[News Feeds](News-Feeds)
[Version française](Version-française) | [Simplified Chinese](Simplified-Chinese)

### **Welcome**

The Ascend.NET controls are a collection of Windows Forms controls written in C# targeting Visual Studio 2005 and .NET 2.0. 
The intent is to provide controls that are flexible but easy to use that will hold up well under heavy usage. 

**Highlights**
![](Home_Line.png)  
![](Home_SmallSquare.png) **[Help us determine the controls that would best benefit the community.](http://www.codeplex.com/Project/ListThreads.aspx?ProjectName=ASCENDNET&ForumId=1003)**
![](Home_SmallSquare.png) **[Version 1.5 planning and specifications.](Version-1.5-planning-and-specifications.)**
![](Home_SmallSquare.png) **[Version 2.0 planning.](Version-2.0-planning.)**
![](Home_SmallSquare.png) **[Examples](Examples)**  ![](Home_New.png)
![](Home_SmallSquare.png) **[Project tools list.](Project-tools-list.)**
![](Home_SmallSquare.png) **Brazilian Portuguese, French, German, Italian, Spanish and Turkish language versions of the controls are also now in the works.**
![](Home_SmallSquare.png) **English RTM Production 1.0.0.6 is now available.**

The controls are currently available in English and Chinese (simplified). 
Version 1 has the following controls:

![](Home_GradientLinePreview.png) **GradientLine**

A line control that supports solid, gradient and glass modes. The colors, direction and gradient modes are customizable. 
   ![](Home_SmallArrow.png) [GradientLine Images](GradientLine-Images)

![](Home_GradientPanelPreview.png) **GradientPanel** 

A panel control that supports solid, gradient and glass modes. The colors, direction, highlight transition percent, luminance and gradient modes are customizable. The borders are also completely customizable and includes curved corners.
   ![](Home_SmallArrow.png) [GradientPanel Images](GradientPanel-Images)

![](Home_GradientCaptionPreview.png) **GradientCaption**

A caption control that supports solid, gradient and glass modes. The colors, direction, highlight transition percent, luminance and gradient modes are customizable. The borders are also completely customizable and includes curved corners. Supports independent text and image alignment. Unlike the .Net label control if the image and text are aligned to the same side the image and text will not overlap.
   ![](Home_SmallArrow.png) [GradientCaption Images](GradientCaption-Images)

![](Home_GradientSplitbarPreview.png) **GradientSplitBar** 

A split bar like control that supports solid, gradient and glass modes. The colors, direction, highlight transition percent, luminance and gradient modes are customizable. 
   ![](Home_SmallArrow.png) [GradientSplitBar Images](GradientSplitBar-Images)

![](Home_GradientNavigationButtonPreview.png) **GradientNavigationButton**

A navigation button control that supports solid, gradient and glass modes. The highlight transition percent, luminance and gradient modes are customizable. The colors are customizable for each button state. The borders are also completely customizable and includes curved corners. Supports independent text and image alignment. Unlike the .net label control if the image and text are aligned to the same side the image and text will not overlap. Both mouse and tab focus highlighting are supported.
   ![](Home_SmallArrow.png) [GradientNavigationButton Images](GradientNavigationButton-Images)

![](Home_GradientAnimationPreview.png) **GradientAnimation** 

An animation control that supports gradient mode. The colors, borders and gradient modes are customizable.
   ![](Home_SmallArrow.png) [GradientAnimation Images](GradientAnimation-Images)

![](Home_GradientNavigationPanePreview.png) **NavigationPane**

A navigation control that supports solid, gradient and glass modes. The colors, text and image alignment are customizable for all parts of the control. End user  button visibility and order customization is also supported.
   ![](Home_SmallArrow.png) [NavigationPane Images](NavigationPane-Images)


**RTM 1.0.0.6 is available and supports Office 2007 gradient look and feel!**

![](Home_GradientNavigationButtonCurve.png) ![](Home_GradientNavigationButtonCurve2.png)

If you are interested we invite you to join this project. Just post what you would like to help with in the Project Management Forum in the discussions tab. Even if you don’t see yourself working in the control code we need structured testers, help file and simple example developers. The less time the control developers spend in these areas the more cool tools and features we can develop.