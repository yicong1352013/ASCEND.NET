![](Simplified Chinese_ChineseInfo.png)

![](Simplified Chinese_Title.png)

![](Simplified Chinese_Welcome.png)
![](Simplified Chinese_WelcomeDescription.png)

**Highlights**
![](Simplified Chinese_Line.png)

![](Simplified Chinese_Highlights1.png) [**](http://www.codeplex.com/Project/ListThreads.aspx?ProjectName=ASCENDNET&ForumId=1003)
![](Simplified Chinese_Highlights2.png) [**](http://www.codeplex.com/Wiki/View.aspx?ProjectName=ASCENDNET&title=Version%201.5%20planning%20and%20specifications.)
![](Simplified Chinese_Highlights3.png) [**](http://www.codeplex.com/Wiki/View.aspx?ProjectName=ASCENDNET&title=Version%202.0%20planning.)
![](Simplified Chinese_Highlights4.png) [**](http://www.codeplex.com/Wiki/View.aspx?ProjectNameASCENDNET&titleExamples)
![](Simplified Chinese_Highlights5.png)

![](Simplified Chinese_Para1.png)

![](Simplified Chinese_Para2.png)


![](Simplified Chinese_GradientLinePreview.png) **GradientLine**
![](Simplified Chinese_GradientLine.png)

![](Simplified Chinese_GradientLinePictures.png) [**](http://www.codeplex.com/Wiki/View.aspx?ProjectName=ASCENDNET&title=GradientLine%20Images)

![](Simplified Chinese_GradientPanelPreview.png) **GradientPanel**
![](Simplified Chinese_GradientPanel.png)

![](Simplified Chinese_GradientPanelPictures.png) [**](http://www.codeplex.com/Wiki/View.aspx?ProjectName=ASCENDNET&title=GradientPanel%20Images)

![](Simplified Chinese_GradientCaptionPreview.png) **GradientCaption**
![](Simplified Chinese_GradientCaption.png)

![](Simplified Chinese_GradientCaptionPictures.png) [**](http://www.codeplex.com/Wiki/View.aspx?ProjectName=ASCENDNET&title=GradientCaption%20Images)

![](Simplified Chinese_GradientSplitBarPreview.png) **GradientSplitBar**
![](Simplified Chinese_GradientSplitBar.png)

![](Simplified Chinese_GradientSplitBarPictures.png) [**](http://www.codeplex.com/Wiki/View.aspx?ProjectName=ASCENDNET&title=GradientSplitBar%20Images)

![](Simplified Chinese_GradientNavigationButtonPreview.png) **GradientNavigationButton**
![](Simplified Chinese_GradientNavigationButton.png)

![](Simplified Chinese_GradientNavigationButtonPictures.png) [**](http://www.codeplex.com/Wiki/View.aspx?ProjectName=ASCENDNET&title=GradientNavigationButton%20Images)

![](Simplified Chinese_GradientAnimationPreview.png) **GradientAnimation**
![](Simplified Chinese_GradientAnimation.png)

![](Simplified Chinese_GradientAnimationPictures.png) [**](http://www.codeplex.com/Wiki/View.aspx?ProjectName=ASCENDNET&title=GradientAnimation%20Images)

![](Simplified Chinese_GradientNavigationPanePreview.png) **NavigationPane**
![](Simplified Chinese_GradientNavigationPane.png)

![](Simplified Chinese_GradientNavigationPanePictures.png) [**](http://www.codeplex.com/Wiki/View.aspx?ProjectName=ASCENDNET&title=NavigationPane%20Images)

![](Simplified Chinese_NewVersionHighlights.png)

![](Simplified Chinese_GradientNavigationButtonCurve.png) ![](Simplified Chinese_GradientNavigationButtonCurve2.png)

![](Simplified Chinese_JoinUs.png)