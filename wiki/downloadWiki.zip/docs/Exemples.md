Les téléchargements présents sur cette page sont des demandes d'utilisateurs et des exemples simples développés par les membres du projet. Ils ne sont pas ce que nous considérons comme les bonnes pratiques ou prêt pour la production.

**Si vous avez des exemples d'utilisations des contrôles Ascend, merci d'ajouter un message dans le forum utilisateurs et nous l'ajouterons ici.**

**Exemple anglais de la beta1**

Google Talk look and feel [GoogleStyle.zip](Exemples_GoogleStyle.zip)

**Exemple anglais de la beta2**

Google Talk look and feel [GoogleStyleBeta2.zip](Exemples_GoogleStyleBeta2.zip)

**Exemple anglais de la beta3**

Google Talk look and feel [GoogleStyleBeta3.zip](Exemples_GoogleStyleBeta3.zip)

**Exemple anglais de la beta4**

Google Talk look and feel [GoogleStyleBeta4.zip](Exemples_GoogleStyleBeta4.zip)
Outlook 2003 look and feel [OutlookExampleBeta4.zip](Exemples_OutlookExampleBeta4.zip)
Ribbon bar panel look and feel (à venir)