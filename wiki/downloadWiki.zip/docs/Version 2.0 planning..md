Version 2.0 will include:

**Tabbed MDI**
**RibbonBar**