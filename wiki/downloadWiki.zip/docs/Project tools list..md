A list of the tools used in the development of this project. All tool with the exception of Visual Studio are Open/Shared source. Some tools are required to compile the project if you have downloaded the source. 

**Paint.Net [http://www.getpaint.net/](http://www.getpaint.net/)**
IMHO the best .Net based application available right now.

**Sandcastle [https://blogs.msdn.com/sandcastle/](https://blogs.msdn.com/sandcastle/)**
Used for help file generation. Version 1.5 will be the first release of Ascend.Net to use this tool.

**Sandcastle Help File Builder [http://www.codeplex.com/Wiki/View.aspx?ProjectName=SHFB](http://www.codeplex.com/Wiki/View.aspx?ProjectName=SHFB)**
Makes Sandcastle a lot easier to use.

**Wix [http://wix.sourceforge.net/](http://wix.sourceforge.net/)**
Used to create the install MSI. Version 1.5 will be the first release of Ascend.Net to use this tool. **Version 3 of this tool is required to compile the project source.**

**Wix ProjectAggregator [http://wix.sourceforge.net/](http://wix.sourceforge.net/)**
Used with Wix to compile the install in Visual Studio. Version 1.5 will be the first release of Ascend.Net to use this tool. **This tool is required to compile the project source.**

**Visual Studio 2005 [http://msdn.microsoft.com/vstudio/](http://msdn.microsoft.com/vstudio/)**
The IDE used for development. Sorry, the Express version will not compile the solution. Other .Net 2.0 development platforms may work but are not tested.
