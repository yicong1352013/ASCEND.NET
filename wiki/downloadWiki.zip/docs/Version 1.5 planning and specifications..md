Version 1.5 will focus on:

**Aqua render mode**
![](Version 1.5 planning and specifications._AquaConcept.png)
A more glossy render than the current glass render. All GDI+ no images. The real challenge is performance. I need to get it down to 2 gradient passes.

**Status**: construction phase

**Gradient fade animation**
![](Version 1.5 planning and specifications._ButtonNoHighlight.png) ![](Version 1.5 planning and specifications._ButtonWithHighlight.png)
The Office 2007 gradient buttons remove their gradient colors with a fade. This can be done with the alpha setting and a timer. 

**Status**: design phase

**Themes on complex controls**
**Outlook 2007 style minimize of NavigationPane**
![](Version 1.5 planning and specifications._NavigationPaneCollapse.png)

**Status**: design phase

**ExplorerPane**
![](Version 1.5 planning and specifications._ExplorerBar.png) ![](Version 1.5 planning and specifications._ExplorerBar1.png)
I think we should create a stacked type control and a single stand alone control. I want to avoid the system rendering of the controls. It will make the control too heavy and I really think Microsoft is moving away from this model in their new applications. The controls should be container controls so that any other controls can be contained.

**Status**: design phase

**GradientSplitContainer**
![](Version 1.5 planning and specifications._GradientSplitContainer.png)
A split container control that allows gradient backgrounds and bar. The control will support all of the functionality of the .Net framework split container. The backgrounds and borders of the panels will be customizable with the standard gradient panel options. The split bar may be rendered with a gradient split bar.

**Status**: construction phase

**GradientSplitter**
![](Version 1.5 planning and specifications._GradientSplitBarGlassVertical.png)
Sorry, I should have made the current GradientSplitBar control a real splitter in version 1. I use the existing control in larger controls but it will be more useful as an actual splitter.

**Status**: near beta

**GradientTab**
![](Version 1.5 planning and specifications._GradientTab.png)
A tab control that allows gradient tabs. The control will support most of the functionality of the .Net framework tab. The ability to hide tabs will also be supported. I will not support system render directly. This would make the control too heavy and I think it is the reason for some of the shortcomings of the existing tab control. I may support the general look of the system tab. Some shape manipulation of the tab will be supported.

**Status**: construction phase