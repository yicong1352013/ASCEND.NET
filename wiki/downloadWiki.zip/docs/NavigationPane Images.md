![](NavigationPane Images_NavigationPaneFlat.png) ![](NavigationPane Images_NavigationPaneGradient.png) ![](NavigationPane Images_NavigationPaneGlass.png) 

![](NavigationPane Images_NavigationPaneDesign2.png)

![](NavigationPane Images_NavigationPaneDesign3.png)