/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Provides methods used to paint common Windows controls and their elements.
    /// </summary>
    public sealed class PaintControl
    {
        /// <summary>
        /// Creates a halftone hatch brush.
        /// </summary>
        /// <returns>Handle to the brush.</returns>
        public static IntPtr CreateHalftoneHBRUSH()
        {
            short[] numberArray = new short[8];

            for (int i = 0; i < 8; i++)
            {
                numberArray[i] = (short)(0x5555 << ((i & 1) & 0x1f));

            }

            IntPtr brushHandle;

            IntPtr bitmapHandle = SafeNativeMethods.CreateBitmap(8, 8, 1, 1, numberArray);
            try
            {
                NativeMethods.LOGBRUSH logbrush = new NativeMethods.LOGBRUSH();
                logbrush.lbColor = ColorTranslator.ToWin32(Color.Black);
                logbrush.lbStyle = 3;
                logbrush.lbHatch = bitmapHandle;
                
                brushHandle = SafeNativeMethods.CreateBrushIndirect(logbrush);

            }
            catch
            {
                throw;

            }
            finally
            {
                SafeNativeMethods.DeleteObject(new HandleRef(null, bitmapHandle));

            }

            return brushHandle;

        }

    }

}
