/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Provides data for GradientSplitterMoving and the GradientSplitterMoved events.
    /// </summary>
    [ComVisible(true)]
    public class GradientSplitterEventArgs : EventArgs
    {
        private int _splitterX;
        private int _splitterY;
        private readonly int _x;
        private readonly int _y;

        /// <summary>
        /// Initializes an instance of the GradientSplitterEventArgs class with the specified coordinates of the mouse pointer and the coordinates of the upper-left corner of the GradientSplitter control.
        /// </summary>
        /// <param name="x">The x-coordinate of the mouse pointer (in client coordinates).</param>
        /// <param name="y">The y-coordinate of the mouse pointer (in client coordinates).</param>
        /// <param name="splitX">The x-coordinate of the upper-left corner of the GradientSplitter (in client coordinates).</param>
        /// <param name="splitY">The y-coordinate of the upper-left corner of the GradientSplitter (in client coordinates).</param>
        public GradientSplitterEventArgs(int x, int y, int splitX, int splitY)
        {
            this._x = x;
            this._y = y;
            this._splitterX = splitX;
            this._splitterY = splitY;

        }


        /// <summary>
        /// Gets or sets the x-coordinate of the upper-left corner of the GradientSplitter (in client coordinates).
        /// </summary>
        /// <returns>
        /// The x-coordinate of the upper-left corner of the control.
        /// </returns>
        public int SplitX
        {
            get
            {
                return this._splitterX;

            }

            set
            {
                this._splitterX = value;

            }

        }

        /// <summary>
        /// Gets or sets the y-coordinate of the upper-left corner of the GradientSplitter (in client coordinates).
        /// </summary>
        /// <returns>
        /// The y-coordinate of the upper-left corner of the control.
        /// </returns>
        public int SplitY
        {
            get
            {
                return this._splitterY;

            }

            set
            {
                this._splitterY = value;

            }

        }

        /// <summary>
        /// Gets the x-coordinate of the mouse pointer (in client coordinates).
        /// </summary>
        /// <returns>
        /// The x-coordinate of the mouse pointer.
        /// </returns>
        public int X
        {
            get
            {
                return this._x;

            }

        }

        /// <summary>
        /// Gets the y-coordinate of the mouse pointer (in client coordinates).
        /// </summary>
        /// <returns>
        /// The y-coordinate of the mouse pointer.
        /// </returns>
        public int Y
        {
            get
            {
                return this._y;

            }

        }

    }

}
