/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Provides data for GradientSplitter cancelable events.
    /// </summary>
    public class GradientSplitterCancelEventArgs : CancelEventArgs
    {
        private readonly int _mouseCursorX;
        private readonly int _mouseCursorY;
        private int _splitX;
        private int _splitY;

        /// <summary>
        /// Initializes a new instance of the GradientSplitterCancelEventArgs class with the specified coordinates of the mouse pointer and the upper left corner of the GradientSplitter.
        /// </summary>
        /// <param name="mouseCursorX">The X coordinate of the mouse pointer in client coordinates.</param>
        /// <param name="mouseCursorY">The Y coordinate of the mouse pointer in client coordinates.</param>
        /// <param name="splitX">The X coordinate of the upper left corner of the GradientSplitter in client coordinates.</param>
        /// <param name="splitY">The Y coordinate of the upper left corner of the GradientSplitter in client coordinates.</param>
        public GradientSplitterCancelEventArgs(int mouseCursorX, int mouseCursorY, int splitX, int splitY) : base(false)
        {
            this._mouseCursorX = mouseCursorX;
            this._mouseCursorY = mouseCursorY;
            this._splitX = splitX;
            this._splitY = splitY;

        }

        /// <summary>
        /// Gets the X coordinate of the mouse pointer in client coordinates.
        /// </summary>
        /// <returns>
        /// An integer representing the X coordinate of the mouse pointer in client coordinates.
        /// </returns>
        public int MouseCursorX
        {
            get
            {
                return this._mouseCursorX;

            }

        }

        /// <summary>
        /// Gets the Y coordinate of the mouse pointer in client coordinates.
        /// </summary>
        /// <returns>
        /// An integer representing the Y coordinate of the mouse pointer in client coordinates.
        /// </returns>
        public int MouseCursorY
        {
            get
            {
                return this._mouseCursorY;

            }

        }

        /// <summary>
        /// Gets or sets the X coordinate of the upper left corner of the GradientSplitter in client coordinates.
        /// </summary>
        /// <returns>
        /// An integer representing the X coordinate of the upper left corner of the GradientSplitter.
        /// </returns>
        public int SplitX
        {
            get
            {
                return this._splitX;

            }

            set
            {
                this._splitX = value;

            }

        }

        /// <summary>
        /// Gets or sets the Y coordinate of the upper left corner of the GradientSplitter in client coordinates.
        /// </summary>
        /// <returns>
        /// An integer representing the Y coordinate of the upper left corner of the GradientSplitter.
        /// </returns>
        public int SplitY
        {
            get
            {
                return this._splitY;

            }

            set
            {
                this._splitY = value;

            }

        }

    }

}
