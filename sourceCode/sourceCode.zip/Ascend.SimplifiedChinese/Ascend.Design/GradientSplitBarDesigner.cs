/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Text;
using System.Windows.Forms.Design;
using Ascend.Resources;

namespace Ascend.Windows.Forms.Design
{
    /// <summary>
    /// Extends the design mode behavior of the ControlDesigner.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ControlDesigner provides a base class for designers of components that derive from Control. In addition to the methods and functionality inherited from the ComponentDesigner class, ControlDesigner provides additional methods to support extending and altering the behavior of an associated Control at design time.
    /// </para>
    /// <para>
    /// You can associate a designer with a type using a DesignerAttribute. For an overview of customizing design time behavior.
    /// </para>
    /// </remarks>
    public class GradientSplitBarDesigner : ControlDesigner
    {
        private DesignerActionListCollection _actionLists;

        /// <summary>
        /// Gets the design-time action lists supported by the component associated with the designer.
        /// </summary>
        /// <value>
        /// The design-time action lists supported by the component associated with the designer. 
        /// </value>
        public override DesignerActionListCollection ActionLists
        {
            get
            {
                if (this._actionLists == null)
                {
                    this._actionLists = new DesignerActionListCollection();
                    this._actionLists.Add(new GradientSplitBarActionList((GradientSplitBar)Control));

                }

                return this._actionLists;

            }

        }

        /// <summary>
        /// Allows a designer to change or remove items from the set of properties that it exposes through a TypeDescriptor. 
        /// </summary>
        /// <param name="properties">The properties for the class of the component.</param>
        protected override void PostFilterProperties(System.Collections.IDictionary properties)
        {
            properties.Remove("AutoSize");
            properties.Remove("BackColor");
            properties.Remove("BackgroundImage");
            properties.Remove("BackgroundImageLayout");
            properties.Remove("Font");
            properties.Remove("ForeColor");
            properties.Remove("RightToLeft");
            properties.Remove("Text");
            properties.Remove("WatermarkAlpha");
            properties.Remove("WatermarkImageAlign");
            properties.Remove("WatermarkImage");

        }

        /// <summary>
        /// Allows a designer to change or remove items from the set of events that it exposes through a TypeDescriptor.
        /// </summary>
        /// <param name="events">The events for the class of the component.</param>
        protected override void PostFilterEvents(System.Collections.IDictionary events)
        {
            events.Remove("AutoSizeChanged");
            events.Remove("BackColorChanged");
            events.Remove("BackgroundImageChanged");
            events.Remove("BackgroundImageLayoutChanged");
            events.Remove("FontChanged");
            events.Remove("ForeColorChanged");
            events.Remove("RightToLeftChanged");
            events.Remove("TextChanged");
            events.Remove("WatermarkAlphaChanged");
            events.Remove("WatermarkImageAlignChanged");
            events.Remove("WatermarkImageChanged");

        }

    }

}
