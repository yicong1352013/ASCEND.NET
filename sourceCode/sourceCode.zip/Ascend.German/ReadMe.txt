New compile rules:

There are no longer any compile rules. The solution will no compile like any normal solution. 
Thanks


