/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;
using System;
using System.Collections.Generic;
using System.Drawing.Design;
using System.Text;
using System.Reflection;
using System.Runtime.InteropServices;

using MsVsShell = Microsoft.VisualStudio.Shell;

namespace Ascend.ToolboxControlInstaller
{
    /// <summary>
    /// This package provides code for adding ToolboxItems to the Visual Studio 2005 toolbox.
    /// </summary>
    [MsVsShell.ProvideLoadKey("standard", "1.0", "\"Ascend.NET\" Windows Forms Controls", "Ascend.Net Project", 152)]
    [MsVsShell.DefaultRegistryRoot(@"Software\Microsoft\VisualStudio\8.0")]
    [Guid("D6832E72-5699-4bc2-A21D-931E54C94EEF")]
    [MsVsShell.PackageRegistration(UseManagedResourcesOnly = true)]
    public class PackageToolbox : MsVsShell.Package
    {
        private string _ascendAssemblyPath = "C:\\Program Files\\Ascend.NET Project\\Ascend.NET Windows Forms Controls\\version 1.0.0.5\\Ascend.Windows.Forms.dll";

        /// <summary>
        /// Gets or sets the path to the Ascend assebmly to install.
        /// </summary>
        public string AscendAssemblyPath
        {
            get
            {
                return this._ascendAssemblyPath;

            }

            set
            {
                this._ascendAssemblyPath = value;

            }

        }

        /// <summary>
        /// Inializes a new instance of the PackageToolbox class.
        /// </summary>
        public PackageToolbox()
        {
            this.ToolboxInitialized += new EventHandler(this.PackageToolbox_ToolboxInitialized);
            this.ToolboxUpgraded += new EventHandler(this.PackageToolbox_ToolboxUpgraded);
  
        }

        /// <summary>
        /// This method is called when the "counter" is incremented.  This tell Visual Studio that items may have changed and need to be reinstalled.
        /// </summary>
        void PackageToolbox_ToolboxUpgraded(object sender, EventArgs e)
        {
            this.RemoveToolboxItems();
            this.InstallToolboxItems();

        }

        /// <summary>
        /// This method will add items to the toolbox.
        /// </summary>
        void PackageToolbox_ToolboxInitialized(object sender, EventArgs e)
        {
            this.InstallToolboxItems();

        }

        /// <summary>
        /// Removes tool box items
        /// </summary>
        void RemoveToolboxItems()
        {
            AssemblyName assemblyName = AssemblyName.GetAssemblyName(this._ascendAssemblyPath);

            IToolboxService tbxService = (IToolboxService)GetService(typeof(IToolboxService));

            foreach (ToolboxItem item in ToolboxService.GetToolboxItems(assemblyName))
            {
                tbxService.RemoveToolboxItem(item, "Ascend.Net");

            }

        }

        /// <summary>
        /// Installs toolbox items
        /// </summary>
        void InstallToolboxItems()
        {
            AssemblyName assemblyName = AssemblyName.GetAssemblyName(this._ascendAssemblyPath);

            IToolboxService tbxService = (IToolboxService)GetService(typeof(IToolboxService));

            foreach (ToolboxItem item in ToolboxService.GetToolboxItems(assemblyName))
            {
                tbxService.AddToolboxItem(item, "Ascend.Net");

            }

        }

    }

}
