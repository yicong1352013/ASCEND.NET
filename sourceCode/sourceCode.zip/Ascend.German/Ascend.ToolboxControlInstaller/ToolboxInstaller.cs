using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;

namespace Ascend.ToolboxControlInstaller
{
    [RunInstaller(true)]
    public partial class ToolboxInstaller : Installer
    {
        public ToolboxInstaller()
        {
            InitializeComponent();

        }

    }

}