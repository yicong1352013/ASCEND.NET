/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// NavigationPane options dialog.
    /// </summary>
    public partial class NavigationPaneOptions : Form
    {
        private NavigationPane _parentNavigationPane;
        private ArrayList _displayOrder = null;
        private ArrayList _displayOrderCopy = null;
        private ArrayList _displayOrderVisible = null;
        private bool _hasChange;

        /// <summary>
        /// Gets or sets the parent NavigationPane.
        /// </summary>
        public NavigationPane ParentNavigationPane
        {
            get
            {
                return this._parentNavigationPane;

            }

            set
            {
                this._parentNavigationPane = value;

            }

        }

        #region BuildDisplayOrder
        /// <summary>
        ///  Build new DisplayOrder for NavigationPane option
        /// </summary>
        /// <param name="value"></param>
        internal void BuildDisplayOrder(ArrayList value)
        {
           
            this._displayOrder = value;
            this._displayOrderCopy = new ArrayList(this._displayOrder);
            this._displayOrderVisible = new ArrayList();

            int index;

            for (int i = 0; i < this._displayOrderCopy.Count; i++)
            {
                index = this._parentNavigationPane.NavigationPages.IndexOf((string)this._displayOrderCopy[i]);

                if (index > -1)
                {
                    this._displayOrderVisible.Add(this._parentNavigationPane.NavigationPages[index].ButtonVisible);
                }
                else
                {
                    this._displayOrderVisible.Add(false);
                }
            }
        }
        #endregion BuildDisplayOrder


        /// <summary>
        /// Gets the display order.
        /// </summary>
        public ArrayList DisplayOrder
        {
            get
            {
                return this._displayOrder;

            }

        }

        /// <summary>
        /// Gets if the options dialog has changes.
        /// </summary>
        public bool HasChanges
        {
            get
            {
                return this._hasChange;

            }

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneOptions class.
        /// </summary>
        public NavigationPaneOptions()
        {
            InitializeComponent();

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();

        }

        private void NavigationPaneOptions_Load(object sender, EventArgs e)
        {
            this.LoadListBox();

        }

        private void LoadListBox()
        {
            int index = -1;

            this.checkedListBoxButtons.ItemCheck -= new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBoxButtons_ItemCheck);
            try
            {
                this.checkedListBoxButtons.Items.Clear();

                if (this._parentNavigationPane != null && _parentNavigationPane.NavigationPages != null && this._displayOrderCopy != null)
                {
                    for (int i = 0; i < this._displayOrderCopy.Count; i++)
                    {
                        index = this._parentNavigationPane.NavigationPages.IndexOf((string)this._displayOrderCopy[i]);

                        if (index > -1)
                        {
                            this.checkedListBoxButtons.Items.Add(this._parentNavigationPane.NavigationPages[index].Text, (bool)this._displayOrderVisible[i]);

                        }

                    }

                }

            }
            catch
            {
                throw;

            }
            finally
            {
                this.checkedListBoxButtons.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBoxButtons_ItemCheck);

            }

        }

        private void checkedListBoxButtons_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.checkedListBoxButtons.SelectedIndex > -1)
            {
                if (this.checkedListBoxButtons.SelectedIndex < (this.checkedListBoxButtons.Items.Count - 1))
                {
                    this.btnMoveDown.Enabled = true;

                }
                else
                {
                    this.btnMoveDown.Enabled = false;

                }


                if (this.checkedListBoxButtons.SelectedIndex > 0)
                {
                    this.btnMoveUp.Enabled = true;

                }
                else
                {
                    this.btnMoveUp.Enabled = false;

                }

            }
            else
            {
                this.btnMoveDown.Enabled = false;
                this.btnMoveUp.Enabled = false;

            }

        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (this._hasChange)
            {                
                int index;

                for (int i = 0; i < this._displayOrderCopy.Count; i++)
                {
                    index = this._parentNavigationPane.NavigationPages.IndexOf(this._displayOrderCopy[i].ToString());

                    if (index > -1)
                    {
                        this._parentNavigationPane.NavigationPages[index].ButtonVisible = (bool)this._displayOrderVisible[i];

                    }

                }

                this._displayOrder = new ArrayList(this._displayOrderCopy);

            }

            this.DialogResult = DialogResult.OK;
            this.Close();

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            this._parentNavigationPane.Reset();

            this._displayOrderCopy = new ArrayList(this._displayOrder);

            this.LoadListBox();

            this._hasChange = false;

        }

        private void btnMoveDown_Click(object sender, EventArgs e)
        {
            if ((this.checkedListBoxButtons.SelectedIndex > -1) && (this.checkedListBoxButtons.SelectedIndex < (this.checkedListBoxButtons.Items.Count - 1)))
            {
                int index = this.checkedListBoxButtons.SelectedIndex;

                string displayValue = this._displayOrderCopy[index].ToString();
                bool displayVisible = (bool)this._displayOrderVisible[index];

                this._displayOrderCopy.RemoveAt(index);
                this._displayOrderCopy.Insert((index + 1), displayValue);

                this._displayOrderVisible.RemoveAt(index);
                this._displayOrderVisible.Insert((index + 1), displayVisible);

                this._hasChange = true;

                this.LoadListBox();

                this.checkedListBoxButtons.SelectedIndex = (index + 1);

            }

        }

        private void checkedListBoxButtons_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            this._hasChange = true;

            if (e.NewValue == CheckState.Checked)
            {
                this._displayOrderVisible[e.Index] = true;

            }
            else
            {
                this._displayOrderVisible[e.Index] = false;

            }

        }

        private void btnMoveUp_Click(object sender, EventArgs e)
        {
            if ((this.checkedListBoxButtons.SelectedIndex > -1) && (this.checkedListBoxButtons.SelectedIndex > 0))
            {
                int index = this.checkedListBoxButtons.SelectedIndex;

                string displayValue = this._displayOrderCopy[index].ToString();
                bool displayVisible = (bool)this._displayOrderVisible[index];

                this._displayOrderCopy.RemoveAt(index);
                this._displayOrderCopy.Insert((index - 1), displayValue);

                this._displayOrderVisible.RemoveAt(index);
                this._displayOrderVisible.Insert((index - 1), displayVisible);

                this._hasChange = true;

                this.LoadListBox();

                this.checkedListBoxButtons.SelectedIndex = (index - 1);

            }

        }

    }

}