
8/20/2006: Beta 4 version 1.0.0.4

To install the tools just run Ascend.Install.msi and follow the prompts. Visual Studio should be closed while installing.

If you have been using an earlier version keep in mind that you will need to update your project references to point to the Ascend assemblies version 1.0.0.4 . The install will leave the older version(s) to keep your projects from breaking.

There are no known breaking changes between beta 3 and this release.

Please let me know of any problems you may have at http://www.codeplex.com/Project/ListForums.aspx?ProjectName=ASCENDNET . I hate tools that cause me extra work because of bugs and I don�t want to be in that group but we all know how hard it is to write the �perfect� application. If you just want to tell me how good the tools are I would take that also. <smile>

Thanks,
Ascend.Net Team
