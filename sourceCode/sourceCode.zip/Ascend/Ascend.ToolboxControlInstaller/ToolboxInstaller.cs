/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Windows.Forms;
using System.Diagnostics;

namespace Ascend.ToolboxControlInstaller
{
    [RunInstaller(true)]
    public partial class ToolboxInstaller : Installer
    {
        private string _installPath = string.Empty;

        public ToolboxInstaller()
        {
            InitializeComponent();
            this.AfterInstall +=new InstallEventHandler(this.ToolboxInstaller_AfterInstall);            

        }

        private void ToolboxInstaller_AfterInstall(object sender, InstallEventArgs e)
        {
            this._installPath = this.Context.Parameters["BinDir"];            
            //PackageToolbox packageToolbox = new PackageToolbox(this._installPath);            
            
        }

    }

}