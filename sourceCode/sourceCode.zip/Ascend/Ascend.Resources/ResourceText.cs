/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Globalization;
using System.Threading;

namespace Ascend.Resources
{
    /// <summary>
    /// Specifies the text of the passed value.
    /// </summary>
    public static class ResourceText
    {
        /// <summary>
        /// Looks up the localized text of the specified value. 
        /// </summary>
        public static string GetLocalizedString(string value)
        {
            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;

            System.Resources.ResourceManager resourceManager;

            //switch(cultureInfo.Name.ToUpper())
            //{
            //    case "EN-US":
            //        resourceManager = new System.Resources.ResourceManager("Ascend.Resources.DefaultResource", Assembly.GetExecutingAssembly());
            //        break;

            //    case "EN-GB":
            //        resourceManager = new System.Resources.ResourceManager("Ascend.Resources.DefaultResource.en-GB", Assembly.GetExecutingAssembly());
            //        break;

            //    default:
                    resourceManager = new System.Resources.ResourceManager("Ascend.Resources.DefaultResource", Assembly.GetExecutingAssembly());
            //        break;

            //}

            return resourceManager.GetString(value, cultureInfo);

        }

    }

}
