﻿/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/


using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.Design;

namespace Ascend.Windows.Forms.Design
{
    /// <summary>
    /// 
    /// </summary>
    public class GradientSplitContainerActionList : DesignerActionList
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="gradientSplitContainer"></param>
        public GradientSplitContainerActionList(GradientSplitContainer gradientSplitContainer) : base(gradientSplitContainer)
        {
        }

    }
}
