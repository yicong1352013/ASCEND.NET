/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.Design;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;
using Ascend.Resources;

namespace Ascend.Windows.Forms.Design
{
    /// <summary>
    /// Provides the base class for types that define a list of items used to create a DesignerActionPanel.
    /// </summary>
    public class GradientTabActionList : DesignerActionList
    {
        private GradientTab _gradientTab;

        /// <summary>
        /// Initializes a new instance of the GradientTabActionList class.
        /// </summary>
        /// <param name="gradientTab">A GradientTab component.</param>
        public GradientTabActionList(GradientTab gradientTab) : base(gradientTab)
        {
            this._gradientTab = gradientTab;

        }

        /// <summary>
        /// Specifies if the control is anti-aliased when drawn.
        /// </summary>
        public bool AntiAlias
        {
            get
            {
                return this._gradientTab.AntiAlias;

            }

            set
            {
                this.GetPropertyByName("AntiAlias").SetValue(this._gradientTab, value);

            }

        }

        /// <summary>
        /// Specifies the position and manner in which a control is docked.
        /// </summary>
        /// <remarks>
        /// <para>
        /// When a control is docked to an edge of its container, it is always positioned flush against that edge when the container is resized. If more than one control is docked to an edge, the controls appear side by side according to their z-order; controls higher in the z-order are positioned farther from the container's edge.
        /// </para>
        /// <para>
        /// If Left, Right, Top, or Bottom is selected, the specified and opposite edges of the control are resized to the size of the containing control's corresponding edges. If Fill is selected, all four sides of the control are resized to match the containing control's edges.
        /// </para>
        /// </remarks>
        /// <value>
        /// <para>
        /// System.Windows.Forms.DockStyle
        /// </para>
        /// <para>
        /// This property is read/write.
        /// </para>
        /// </value>
        public DockStyle Dock
        {
            get
            {
                return this._gradientTab.Dock;

            }

            set
            {
                this.GetPropertyByName("Dock").SetValue(this._gradientTab, value);

            }

        }

        /// <summary>
        /// The font associated with the control.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Font . The base font to be inherited by child controls.
        /// </para>
        /// <para>
        /// This property is read/write.
        /// </para>
        /// </value>
        public Font Font
        {
            get
            {
                return this._gradientTab.Font;

            }

            set
            {
                this.GetPropertyByName("Font").SetValue(this._gradientTab, value);

            }

        }

        /// <summary>
        /// Gets or sets the name of the control.
        /// </summary>
        /// <value>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public string Name
        {
            get
            {
                return this._gradientTab.Name;

            }

            set
            {
                this.GetPropertyByName("Name").SetValue(this._gradientTab, value);

            }

        }

        /// <summary>
        /// Gets or sets the painting style applied to the background in a control.
        /// </summary>
        /// <value>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public RenderMode RenderMode
        {
            get
            {
                return this._gradientTab.RenderMode;

            }

            set
            {
                this.GetPropertyByName("RenderMode").SetValue(this._gradientTab, value);

            }

        }

        /// <summary>
        /// Returns a property descriptor for the passed property name.
        /// </summary>
        /// <param name="propertyName">The property name.</param>
        /// <returns>The property descriptor.</returns>
        private PropertyDescriptor GetPropertyByName(string propertyName)
        {
            PropertyDescriptor propertyDescriptor;

            propertyDescriptor = TypeDescriptor.GetProperties(this._gradientTab)[propertyName];

            if (propertyDescriptor == null)
            {
                throw new ArgumentException(ResourceText.GetLocalizedString("NPPropertyNotFoundExceptionText"));

            }
            else
            {
                return propertyDescriptor;

            }

        }

        /// <summary>
        /// Adds a new gradient tab page
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private void OnAdd()
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                GradientTab control = (GradientTab)base.Component;
                IDesignerHost host = (IDesignerHost)this.GetService(typeof(IDesignerHost));
                if (host == null)
                {
                    return;

                }

                DesignerTransaction transaction = null;
                try
                {
                    try
                    {
                        transaction = host.CreateTransaction(ResourceText.GetLocalizedString("GradientTabAddVerbText"));

                    }
                    catch (CheckoutException exception)
                    {
                        if (exception != CheckoutException.Canceled)
                        {
                            throw;

                        }

                        return;

                    }

                    MemberDescriptor memberDescriptor = TypeDescriptor.GetProperties(control)["Controls"];
                    GradientTabPage gradientTabPage = (GradientTabPage)host.CreateComponent(typeof(GradientTabPage));

                    string text = null;
                    PropertyDescriptor propertyDescriptor = TypeDescriptor.GetProperties(gradientTabPage)["Name"];
                    if ((propertyDescriptor != null) && (propertyDescriptor.PropertyType == typeof(string)))
                    {
                        text = (string)propertyDescriptor.GetValue(gradientTabPage);

                    }

                    if (text != null)
                    {
                        PropertyDescriptor propertyDescriptorText = TypeDescriptor.GetProperties(gradientTabPage)["Text"];
                        if (propertyDescriptorText != null)
                        {
                            propertyDescriptorText.SetValue(gradientTabPage, text);

                        }

                        PropertyDescriptor propertyDescriptorKey = TypeDescriptor.GetProperties(gradientTabPage)["Key"];
                        if (propertyDescriptorKey != null)
                        {
                            propertyDescriptorKey.SetValue(gradientTabPage, text);

                        }

                    }

                    PropertyDescriptor propertyDescriptorTextAlign = TypeDescriptor.GetProperties(gradientTabPage)["TextAlign"];
                    if (propertyDescriptorTextAlign != null)
                    {
                        propertyDescriptorTextAlign.SetValue(gradientTabPage, control.TabTextAlign);

                    }

                    PropertyDescriptor propertyDescriptorImageAlign = TypeDescriptor.GetProperties(gradientTabPage)["ImageAlign"];
                    if (propertyDescriptorImageAlign != null)
                    {
                        propertyDescriptorImageAlign.SetValue(gradientTabPage, control.TabImageAlign);

                    }

                    PropertyDescriptor propertyDescriptorTabForeColor = TypeDescriptor.GetProperties(gradientTabPage)["TabForeColor"];
                    if (propertyDescriptorTabForeColor != null)
                    {
                        propertyDescriptorTabForeColor.SetValue(gradientTabPage, control.TabForeColor);

                    }

                    PropertyDescriptor propertyDescriptorGradientHighColor = TypeDescriptor.GetProperties(gradientTabPage)["GradientHighColor"];
                    if (propertyDescriptorGradientHighColor != null)
                    {
                        propertyDescriptorGradientHighColor.SetValue(gradientTabPage, control.TabGradientHighColor);

                    }

                    PropertyDescriptor propertyDescriptorGradientLowColor = TypeDescriptor.GetProperties(gradientTabPage)["GradientLowColor"];
                    if (propertyDescriptorGradientLowColor != null)
                    {
                        propertyDescriptorGradientLowColor.SetValue(gradientTabPage, control.TabGradientLowColor);

                    }

                    PropertyDescriptor propertyDescriptorActiveGradientHighColor = TypeDescriptor.GetProperties(gradientTabPage)["ActiveGradientHighColor"];
                    if (propertyDescriptorActiveGradientHighColor != null)
                    {
                        propertyDescriptorActiveGradientHighColor.SetValue(gradientTabPage, control.TabActiveGradientHighColor);

                    }

                    PropertyDescriptor propertyDescriptorActiveGradientLowColor = TypeDescriptor.GetProperties(gradientTabPage)["ActiveGradientLowColor"];
                    if (propertyDescriptorActiveGradientLowColor != null)
                    {
                        propertyDescriptorActiveGradientLowColor.SetValue(gradientTabPage, control.TabActiveGradientLowColor);

                    }

                    PropertyDescriptor propertyDescriptorHighlightGradientHighColor = TypeDescriptor.GetProperties(gradientTabPage)["HighlightGradientHighColor"];
                    if (propertyDescriptorHighlightGradientHighColor != null)
                    {
                        propertyDescriptorHighlightGradientHighColor.SetValue(gradientTabPage, control.TabHighlightGradientHighColor);

                    }

                    PropertyDescriptor propertyDescriptorHighlightGradientLowColor = TypeDescriptor.GetProperties(gradientTabPage)["HighlightGradientLowColor"];
                    if (propertyDescriptorHighlightGradientLowColor != null)
                    {
                        propertyDescriptorHighlightGradientLowColor.SetValue(gradientTabPage, control.TabHighlightGradientLowColor);

                    }

                    PropertyDescriptor propertyDescriptorPaneTabFont = TypeDescriptor.GetProperties(gradientTabPage)["TabFont"];
                    if (propertyDescriptorPaneTabFont != null)
                    {
                        propertyDescriptorPaneTabFont.SetValue(gradientTabPage, new Font(control.Font.FontFamily, 8.25f));

                    }

                    PropertyDescriptor propertyDescriptorTabFont = TypeDescriptor.GetProperties(control)["TabFont"];
                    if (propertyDescriptorTabFont != null)
                    {
                        propertyDescriptorTabFont.SetValue(control, new Font(control.Font.FontFamily, 8.25f));

                    }

                    if (control.GradientTabPages != null)
                    {
                        control.GradientTabPages.Add(gradientTabPage);

                    }

                }
                catch
                {
                    throw;

                }
                finally
                {
                    if (transaction != null)
                    {
                        transaction.Commit();

                    }

                }

            }
            catch
            {
                throw;

            }
            finally
            {
                Cursor.Current = Cursors.Default;

            }

        }

        /// <summary>
        /// Removes a gradient tab page
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private void OnRemove()
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                if (this._gradientTab.GradientTabPages.Count == 0)
                {
                    return;

                }

                GradientTabPage page = this._gradientTab.SelectedGradientTabPage;
                IDesignerHost host = (IDesignerHost)this.GetService(typeof(IDesignerHost));
                if (host == null)
                {
                    return;

                }

                DesignerTransaction transaction = null;
                try
                {
                    try
                    {
                        transaction = host.CreateTransaction(ResourceText.GetLocalizedString("GradientTabRemoveVerbText"));

                    }
                    catch (CheckoutException exception)
                    {
                        if (exception != CheckoutException.Canceled)
                        {
                            throw;

                        }

                        return;

                    }

                    this._gradientTab.GradientTabPages.Remove(page);
                    host.DestroyComponent(page);

                }
                catch
                {
                    throw;

                }
                finally
                {
                    if (transaction != null)
                    {
                        transaction.Commit();

                    }

                }

            }
            catch
            {
                throw;

            }
            finally
            {
                Cursor.Current = Cursors.Default;

            }

        }

        /// <summary>
        /// Returns the collection of DesignerActionItem objects contained in the list. 
        /// </summary>
        /// <returns>A DesignerActionItem array that contains the items in this list.</returns>
        public override DesignerActionItemCollection GetSortedActionItems()
        {
            DesignerActionItemCollection items = new DesignerActionItemCollection();

            items.Add(new DesignerActionPropertyItem("Name", ResourceText.GetLocalizedString("ActionListDisplayNameName"), "Design", ResourceText.GetLocalizedString("NameDescription")));

            items.Add(new DesignerActionHeaderItem(ResourceText.GetLocalizedString("ActionListAppearanceCategory"), "Appearance"));
            items.Add(new DesignerActionTextItem(ResourceText.GetLocalizedString("ActionListAppearanceTextItem"), "Appearance"));
            items.Add(new DesignerActionPropertyItem("AntiAlias", ResourceText.GetLocalizedString("ActionListDisplayNameAntiAlias"), "Appearance", ResourceText.GetLocalizedString("AntiAliasDescription")));
            items.Add(new DesignerActionPropertyItem("RenderMode", ResourceText.GetLocalizedString("ActionListDisplayNameRenderMode"), "Appearance", ResourceText.GetLocalizedString("RenderModeDescription")));
            items.Add(new DesignerActionPropertyItem("Font", ResourceText.GetLocalizedString("ActionListDisplayNameFont"), "Appearance", ResourceText.GetLocalizedString("FontDescription")));

            items.Add(new DesignerActionHeaderItem(ResourceText.GetLocalizedString("ActionListLayoutCategory"), "Layout"));
            items.Add(new DesignerActionTextItem(ResourceText.GetLocalizedString("ActionListLayoutTextItem"), "Layout"));
            items.Add(new DesignerActionPropertyItem("Dock", ResourceText.GetLocalizedString("ActionListDisplayNameDock"), "Layout", ResourceText.GetLocalizedString("DockedDescription")));

            items.Add(new DesignerActionMethodItem(this, "OnAdd", ResourceText.GetLocalizedString("GradientTabAddVerbText"), "Actions", ResourceText.GetLocalizedString("GradientTabAddVerbText"), false));
            items.Add(new DesignerActionMethodItem(this, "OnRemove", ResourceText.GetLocalizedString("GradientTabRemoveVerbText"), "Actions", ResourceText.GetLocalizedString("GradientTabRemoveVerbText"), false));

            return items;

        }

    }

}
