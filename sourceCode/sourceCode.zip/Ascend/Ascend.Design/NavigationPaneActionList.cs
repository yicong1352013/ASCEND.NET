/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using Ascend.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ascend.Windows.Forms.Design
{
    /// <summary>
    /// Provides the base class for types that define a list of items used to create a DesignerActionPanel.
    /// </summary>
    public class NavigationPaneActionList : DesignerActionList
    {
        private NavigationPane _navigationPane;

        /// <summary>
        /// Initializes a new instance of the NavigationPaneActionList class.
        /// </summary>
        /// <param name="navigationPane">A NavigationPane component.</param>
        public NavigationPaneActionList(NavigationPane navigationPane) : base(navigationPane)
        {
            this._navigationPane = navigationPane;

        }

        /// <summary>
        /// Specifies if the control is anti-aliased when drawn.
        /// </summary>
        public bool AntiAlias
        {
            get
            {
                return this._navigationPane.AntiAlias;

            }

            set
            {
                this.GetPropertyByName("AntiAlias").SetValue(this._navigationPane, value);

            }

        }

        /// <summary>
        /// Specifies the position and manner in which a control is docked.
        /// </summary>
        /// <remarks>
        /// <para>
        /// When a control is docked to an edge of its container, it is always positioned flush against that edge when the container is resized. If more than one control is docked to an edge, the controls appear side by side according to their z-order; controls higher in the z-order are positioned farther from the container's edge.
        /// </para>
        /// <para>
        /// If Left, Right, Top, or Bottom is selected, the specified and opposite edges of the control are resized to the size of the containing control's corresponding edges. If Fill is selected, all four sides of the control are resized to match the containing control's edges.
        /// </para>
        /// </remarks>
        /// <value>
        /// <para>
        /// System.Windows.Forms.DockStyle
        /// </para>
        /// <para>
        /// This property is read/write.
        /// </para>
        /// </value>
        public DockStyle Dock
        {
            get
            {
                return this._navigationPane.Dock;

            }

            set
            {
                this.GetPropertyByName("Dock").SetValue(this._navigationPane, value);

            }

        }

        /// <summary>
        /// The font associated with the control.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Font . The base font to be inherited by child controls.
        /// </para>
        /// <para>
        /// This property is read/write.
        /// </para>
        /// </value>
        public Font Font
        {
            get
            {
                return this._navigationPane.Font;

            }

            set
            {
                this.GetPropertyByName("Font").SetValue(this._navigationPane, value);

            }

        }

        /// <summary>
        /// Gets or sets the name of the control.
        /// </summary>
        /// <value>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public string Name
        {
            get
            {
                return this._navigationPane.Name;

            }

            set
            {
                this.GetPropertyByName("Name").SetValue(this._navigationPane, value);

            }

        }

        /// <summary>
        /// Gets or sets the painting style applied to the background in a control.
        /// </summary>
        /// <value>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public RenderMode RenderMode
        {
            get
            {
                return this._navigationPane.RenderMode;

            }

            set
            {
                this.GetPropertyByName("RenderMode").SetValue(this._navigationPane, value);

            }

        }

        /// <summary>
        /// Returns a property descriptor for the passed property name.
        /// </summary>
        /// <param name="propertyName">The property name.</param>
        /// <returns>The property descriptor.</returns>
        private PropertyDescriptor GetPropertyByName(string propertyName)
        {
            PropertyDescriptor propertyDescriptor;

            propertyDescriptor = TypeDescriptor.GetProperties(this._navigationPane)[propertyName];

            if (propertyDescriptor == null)
            {
                throw new ArgumentException(ResourceText.GetLocalizedString("NPPropertyNotFoundExceptionText"));

            }
            else
            {
                return propertyDescriptor;

            }

        }

        /// <summary>
        /// Adds a new navigation pane page
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private void OnAdd()
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                IDesignerHost host = (IDesignerHost)this.GetService(typeof(IDesignerHost));
                if (host == null)
                {
                    return;

                }

                DesignerTransaction transaction = null;
                try
                {
                    try
                    {
                        transaction = host.CreateTransaction(ResourceText.GetLocalizedString("NPAddVerbText"));

                    }
                    catch (CheckoutException exception)
                    {
                        if (exception != CheckoutException.Canceled)
                        {
                            throw;

                        }

                        return;

                    }

                    NavigationPanePage navigationPanePage = (NavigationPanePage)host.CreateComponent(typeof(NavigationPanePage));

                    string text = null;
                    PropertyDescriptor propertyDescriptor = TypeDescriptor.GetProperties(navigationPanePage)["Name"];
                    if ((propertyDescriptor != null) && (propertyDescriptor.PropertyType == typeof(string)))
                    {
                        text = (string)propertyDescriptor.GetValue(navigationPanePage);

                    }

                    if (text != null)
                    {
                        PropertyDescriptor propertyDescriptorText = TypeDescriptor.GetProperties(navigationPanePage)["Text"];
                        if (propertyDescriptorText != null)
                        {
                            propertyDescriptorText.SetValue(navigationPanePage, text);

                        }

                    }

                    if (this._navigationPane.NavigationPages != null)
                    {
                        this._navigationPane.NavigationPages.Add(navigationPanePage);
                        this._navigationPane.SelectedIndex = this._navigationPane.NavigationPages.Count - 1;

                    }

                }
                catch
                {
                    throw;

                }
                finally
                {
                    if (transaction != null)
                    {
                        transaction.Commit();

                    }

                }

            }
            catch
            {
                throw;

            }
            finally
            {
                Cursor.Current = Cursors.Default;

            }

        }

        /// <summary>
        /// Removes a navigation pane page
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private void OnRemove()
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                if (this._navigationPane.NavigationPages.Count == 0)
                {
                    return;

                }

                NavigationPanePage page = this._navigationPane.SelectedNavigationPage;
                IDesignerHost host = (IDesignerHost)this.GetService(typeof(IDesignerHost));
                if (host == null)
                {
                    return;

                }

                DesignerTransaction transaction = null;
                try
                {
                    try
                    {
                        transaction = host.CreateTransaction(ResourceText.GetLocalizedString("NPRemoveVerbText"));

                    }
                    catch (CheckoutException exception)
                    {
                        if (exception != CheckoutException.Canceled)
                        {
                            throw;

                        }

                        return;

                    }

                    this._navigationPane.NavigationPages.Remove(page);
                    host.DestroyComponent(page);

                }
                catch
                {
                    throw;

                }
                finally
                {
                    if (transaction != null)
                    {
                        transaction.Commit();

                    }

                }

            }
            catch
            {
                throw;

            }
            finally
            {
                Cursor.Current = Cursors.Default;

            }

        }

        /// <summary>
        /// Returns the collection of DesignerActionItem objects contained in the list. 
        /// </summary>
        /// <returns>A DesignerActionItem array that contains the items in this list.</returns>
        public override DesignerActionItemCollection GetSortedActionItems()
        {
            DesignerActionItemCollection items = new DesignerActionItemCollection();

            items.Add(new DesignerActionPropertyItem("Name", ResourceText.GetLocalizedString("ActionListDisplayNameName"), "Design", ResourceText.GetLocalizedString("NameDescription")));

            items.Add(new DesignerActionHeaderItem(ResourceText.GetLocalizedString("ActionListAppearanceCategory"), "Appearance"));
            items.Add(new DesignerActionTextItem(ResourceText.GetLocalizedString("ActionListAppearanceTextItem"), "Appearance"));
            items.Add(new DesignerActionPropertyItem("AntiAlias", ResourceText.GetLocalizedString("ActionListDisplayNameAntiAlias"), "Appearance", ResourceText.GetLocalizedString("AntiAliasDescription")));
            items.Add(new DesignerActionPropertyItem("RenderMode", ResourceText.GetLocalizedString("ActionListDisplayNameRenderMode"), "Appearance", ResourceText.GetLocalizedString("RenderModeDescription")));
            items.Add(new DesignerActionPropertyItem("Font", ResourceText.GetLocalizedString("ActionListDisplayNameFont"), "Appearance", ResourceText.GetLocalizedString("FontDescription")));

            items.Add(new DesignerActionHeaderItem(ResourceText.GetLocalizedString("ActionListLayoutCategory"), "Layout"));
            items.Add(new DesignerActionTextItem(ResourceText.GetLocalizedString("ActionListLayoutTextItem"), "Layout"));
            items.Add(new DesignerActionPropertyItem("Dock", ResourceText.GetLocalizedString("ActionListDisplayNameDock"), "Layout", ResourceText.GetLocalizedString("DockedDescription")));

            items.Add(new DesignerActionMethodItem(this, "OnAdd", ResourceText.GetLocalizedString("NPAddVerbText"), "Actions", ResourceText.GetLocalizedString("NPAddVerbDescription"), false));
            items.Add(new DesignerActionMethodItem(this, "OnRemove", ResourceText.GetLocalizedString("NPRemoveVerbText"), "Actions", ResourceText.GetLocalizedString("NPRemoveVerbDescription"), false));

            return items;

        }

    }

}
