/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.ComponentModel;
using Ascend.Resources;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.ComponentModel.Design;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Represents a Windows form gradient line.
    /// </summary>
    [ToolboxBitmap(typeof(GradientLine), "GradientLine.ico")]
#if GENERAL_RELEASE
    [Designer(typeof(Ascend.Windows.Forms.Design.GradientLineDesigner), typeof(IDesigner))]
#else
    [Designer("Ascend.Windows.Forms.Design.GradientLineDesigner, Ascend.Design.v1.5, Culture=neutral, PublicKeyToken=5123e2ac4258b06a", typeof(IDesigner))]
#endif
    [DesignerCategory("Form")]
    [ResourceDescriptionAttribute("GradientLineDescription")]
    public class GradientLine : System.Windows.Forms.Control
    {
        private IGradientRender _gradientRender;
        private bool _disposed;
        private Color _gradientHighColor;
        private Color _gradientLowColor;

        /// <summary>
        /// Occurs when the Alpha property changes.
        /// </summary>
        [ResourceDescriptionAttribute("AlphaChangedDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameAlphaChanged")]
        public event EventHandler AlphaChanged;

        /// <summary>
        /// Occurs when the AntiAlias property changes.
        /// </summary>
        [ResourceDescriptionAttribute("AntiAliasChangedDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameAntiAliasChanged")]
        public event EventHandler AntiAliasChanged;

        /// <summary>
        /// Occurs when the GradientLowColor property changes.
        /// </summary>
        [ResourceDescriptionAttribute("GradientLowColorChangedDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameGradientLowColorChanged")]
        public event EventHandler GradientLowColorChanged;

        /// <summary>
        /// Occurs when the GradientHighColor property changes.
        /// </summary>
        [ResourceDescriptionAttribute("GradientHighColorChangedDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameGradientHighColorChanged")]
        public event EventHandler GradientHighColorChanged;

        /// <summary>
        /// Occurs when the GradientMode property changes.
        /// </summary>
        [ResourceDescriptionAttribute("GradientModeChangedDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameGradientModeChanged")]
        public event EventHandler GradientModeChanged;

        /// <summary>
        /// Gets or sets the alpha (transparancy) level (0 - 255) of the fill of the control.
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("AlphaDescription"), ResourceDisplayName("DisplayNameAlpha"), DefaultValue(255)]
        public int Alpha
        {
            get
            {
                return this._gradientRender.Alpha;

            }

            set
            {
                if (value == this._gradientRender.Alpha)
                {
                    return;

                }

                this._gradientRender.Alpha = value;

                base.Invalidate();               

                this.OnAlphaChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Specifies the rendering hint for the control.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Boolean . Specifies if the rendering should use antialiasing.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("AntiAliasDescription"), ResourceDisplayName("DisplayNameAntiAlias"), DefaultValueAttribute(false)]
        public bool AntiAlias
        {
            get
            {
                return this._gradientRender.AntiAlias;

            }

            set
            {
                if (value == this._gradientRender.AntiAlias)
                {
                    return;

                }

                this._gradientRender.AntiAlias = value;

                base.Invalidate();

                this.OnAntiAliasChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientHighColorDescription"), ResourceDisplayName("DisplayNameGradientHighColor"), DefaultValueAttribute(typeof(Color), "Window")]
        public Color GradientHighColor
        {
            get
            {
                return this._gradientHighColor;

            }

            set
            {
                if ((this.RightToLeft == RightToLeft.Yes) && (value == this._gradientRender.GradientHighColor))
                {
                    return;

                }
                else if (!(this.RightToLeft == RightToLeft.Yes) && (value == this._gradientRender.GradientLowColor))
                {
                    return;

                }

                if (this.RightToLeft == RightToLeft.Yes)
                {
                    this._gradientRender.GradientHighColor = value;

                }
                else
                {
                    this._gradientRender.GradientLowColor = value;

                }

                this._gradientHighColor = value;

                base.Invalidate();

                this.OnGradientHighColorChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientLowColorDescription"), ResourceDisplayName("DisplayNameGradientLowColor"), DefaultValueAttribute(typeof(Color), "ActiveCaption")]
        public Color GradientLowColor
        {
            get
            {
                return this._gradientLowColor;

            }

            set
            {
                if ((this.RightToLeft == RightToLeft.Yes) && (value == this._gradientRender.GradientLowColor))
                {
                    return;

                }
                else if (!(this.RightToLeft == RightToLeft.Yes) && (value == this._gradientRender.GradientHighColor))
                {
                    return;

                }

                if (this.RightToLeft == RightToLeft.Yes)
                {
                    this._gradientRender.GradientLowColor = value;

                }
                else
                {
                    this._gradientRender.GradientHighColor = value;

                }

                this._gradientLowColor = value;

                base.Invalidate();

                this.OnGradientLowColorChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Specifies the direction of a linear gradient.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Drawing2D.LinearGradientMode . Specifies the direction of a linear gradient.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientModeDescription"), ResourceDisplayName("DisplayNameGradientMode"), DefaultValue(LinearGradientMode.Horizontal)]
        public LinearGradientMode GradientMode
        {
            get
            {
                return this._gradientRender.GradientMode;

            }

            set
            {
                if (value == this._gradientRender.GradientMode)
                {
                    return;

                }

                this._gradientRender.GradientMode = value;

                base.Invalidate();

                this.OnGradientModeChanged(new EventArgs());

            }

        }

        /// <summary>
        /// The render class.
        /// </summary>
        protected IGradientRender GradientRender
        {
            get
            {
                return this._gradientRender;

            }

            set
            {
                this._gradientRender = value;

            }

        }

        /// <summary>
        /// Gets or sets how bright the high color will be starting at the highlight transition point.
        /// </summary>
        /// <remarks>
        /// 1.15 by default.
        /// </remarks>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighColorLuminanceDescription"), ResourceDisplayName("DisplayNameHighColorLuminance"), DefaultValue(typeof(float), "1.15")]
        public float HighColorLuminance
        {
            get
            {
                return ((GradientBackgroundRender)this._gradientRender).HighColorLuminance;

            }

            set
            {
                if (value == ((GradientBackgroundRender)this._gradientRender).HighColorLuminance)
                {
                    return;

                }

                ((GradientBackgroundRender)this._gradientRender).HighColorLuminance = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the highlight transition percent.
        /// </summary>
        /// <remarks>
        /// .45 by default.
        /// The location by percent of the control where the color will transition from high to low color.
        /// This value is only used in glass render mode.
        /// </remarks>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightTransitionPercentDescription"), ResourceDisplayName("DisplayNameHighlightTransitionPercent"), DefaultValueAttribute(typeof(float), ".45")]
        public float HighlightTransitionPercent
        {
            get
            {
                return ((GradientBackgroundRender)this._gradientRender).HighlightTransitionPercent;

            }

            set
            {
                if (value == ((GradientBackgroundRender)this._gradientRender).HighlightTransitionPercent)
                {
                    return;

                }

                ((GradientBackgroundRender)this._gradientRender).HighlightTransitionPercent = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets how bright the low color will be furthest from the highlight transition point.
        /// </summary>
        /// <remarks>
        /// 1.2 by default.
        /// </remarks>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("LowColorLuminanceDescription"), ResourceDisplayName("DisplayNameLowColorLuminance"), DefaultValue(typeof(float), "1.2")]
        public float LowColorLuminance
        {
            get
            {
                return ((GradientBackgroundRender)this._gradientRender).LowColorLuminance;

            }

            set
            {
                if (value == ((GradientBackgroundRender)this._gradientRender).LowColorLuminance)
                {
                    return;

                }

                ((GradientBackgroundRender)this._gradientRender).LowColorLuminance = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Specifies the painting style applied to the background in a control.
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("RenderModeDescription"), ResourceDisplayName("DisplayNameRenderMode"), DefaultValueAttribute(typeof(RenderMode), "Gradient")]
        public RenderMode RenderMode
        {
            get
            {
                return this._gradientRender.RenderMode;

            }

            set
            {
                if (value == this._gradientRender.RenderMode)
                {
                    return;

                }

                this._gradientRender.RenderMode = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets a value indicating whether the user can give the focus to this control using the TAB key. 
        /// </summary>
        /// <value>
        /// true if the user can give the focus to the control using the TAB key; otherwise, false. The default is true.
        /// </value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("TabStopDescription"), DefaultValueAttribute(false)]
        public new bool TabStop
        {
            get
            {
                return base.TabStop;

            }

            set
            {
                base.TabStop = value;

            }

        }

        /// <summary>
        /// Initializes a new instance of the GradientLine class.
        /// </summary>
        public GradientLine() : base()
        {
            this.TabStop = false;

            base.SetStyle(ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.Selectable, true);
            base.BackColor = Color.FromArgb(0, SystemColors.Control);

            this.InitializeRender();

        }

        /// <summary>
        /// Initializes the class used for rendering. 
        /// Rendering class must be based on IGradientReder.
        /// </summary>
        protected virtual void InitializeRender()
        {
            this._gradientRender = new GradientBackgroundRender();
            this._gradientRender.GradientHighColor = SystemColors.ActiveCaption;
            this._gradientHighColor = SystemColors.Window;
            this._gradientRender.GradientLowColor = SystemColors.Window;
            this._gradientLowColor = SystemColors.ActiveCaption;
            this._gradientRender.GradientMode = LinearGradientMode.Horizontal;

        }

        /// <summary>
        /// Gets the default size of the control.
        /// </summary>
        /// <value>
        /// The default Size of the control.
        /// </value>
        protected override Size DefaultSize
        {
            get
            {
                return new Size(151, 4);

            }

        }

        /// <summary>
        /// Raises the Paint event.
        /// </summary>
        /// <param name="e">A System.Windows.Forms.PaintEventArgs that contains the event data.</param>
        /// <remarks>
        /// <para>
        /// Raising an event invokes the event handler through a delegate. For more information, Raising an Event.
        /// </para>
        /// <para>
        /// The OnPaint method also allows derived classes to handle the event without attaching a delegate. This is the preferred technique for handling the event in a derived class.
        /// </para>
        /// <para>
        /// Note for Inheritors:
        /// When overriding OnPaint in a derived class, be sure to call the base class's OnPaint method so that registered delegates receive the event.
        /// </para>
        /// </remarks>
        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            if (!this.Disposing)
            {
                base.OnPaint(e);

                Rectangle rectangle = new Rectangle(0, 0, this.Width, this.Height);
                this._gradientRender.DisplayRectangle = rectangle;

                this._gradientRender.Render(e);

            }

        }

        /// <summary>
        /// Raises the SizeChanged event.
        /// </summary>
        /// <param name="e">An System.EventArgs that contains the event data.</param>
        protected override void OnSizeChanged(System.EventArgs e)
        {
            base.OnSizeChanged(e);

            this.Invalidate();

        }

        /// <summary>
        /// Releases the unmanaged resources used by the GradientPanel and optionally releases the managed resources.
        /// </summary>
        /// <param name="disposing">true to release both managed and unmanaged resources; false to release only unmanaged resources.</param>
        protected override void Dispose(System.Boolean disposing)
        {
            try
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        ((GradientBackgroundRender)this._gradientRender).Dispose();

                    }

                }

                this._disposed = true;

            }
            catch
            {
                throw;

            }
            finally
            {
                base.Dispose(disposing);

            }

        }

        /// <summary>
        /// Fires the event indicating that the gradient panel has been resized. Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.onResize() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">An System.EventArgs that contains the event data.</param>
        protected override void OnResize(System.EventArgs e)
        {
            base.OnResize(e);

            base.Invalidate();

        }

        /// <summary>
        /// Fires the event indicating that the control gradient high color has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnGradientHighColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnGradientHighColorChanged(EventArgs e)
        {
            if (this.GradientHighColorChanged != null)
            {
                this.GradientHighColorChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that the control gradient low color has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnGradientLowColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnGradientLowColorChanged(EventArgs e)
        {
            if (this.GradientLowColorChanged != null)
            {
                this.GradientLowColorChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that the control antialias has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnAntiAliasChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnAntiAliasChanged(EventArgs e)
        {
            if (this.AntiAliasChanged != null)
            {
                this.AntiAliasChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that the control GradientMode has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnGradientModeChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnGradientModeChanged(EventArgs e)
        {
            if (this.GradientModeChanged != null)
            {
                this.GradientModeChanged(this, e);

            }

        }

        /// <summary>
        /// Fired when the background is painted.
        /// </summary>
        /// <param name="pevent">Paint event arguments.</param>
        protected override void OnPaintBackground(System.Windows.Forms.PaintEventArgs pevent)
        {
            base.OnPaintBackground(pevent);

        }

        /// <summary>
        /// Fires the event indicating that the control Alpha property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnAlphaChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnAlphaChanged(System.EventArgs e)
        {
            if (this.AlphaChanged != null)
            {
                this.AlphaChanged(this, e);

            }

        }

        /// <summary>
        /// Raises the SystemColorsChanged event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        protected override void OnSystemColorsChanged(System.EventArgs e)
        {
            this._gradientRender.ResetColors();

            base.OnSystemColorsChanged(e);

            base.Invalidate();

        }

        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        protected override void OnRightToLeftChanged(System.EventArgs e)
        {
            if (this.RightToLeft == RightToLeft.Yes)
            {
                this._gradientRender.GradientHighColor = this._gradientHighColor;
                this._gradientRender.GradientLowColor = this._gradientLowColor;

            }
            else
            {
                this._gradientRender.GradientHighColor = this._gradientLowColor;
                this._gradientRender.GradientLowColor = this._gradientHighColor;

            }

            this._gradientRender.ResetColors();

            base.OnRightToLeftChanged(e);

            base.Invalidate();
            
        }

    }

}
