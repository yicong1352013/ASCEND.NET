/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using Ascend.Resources;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.ComponentModel.Design;
using System.Globalization;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Represents a gradient tab control with associated panels.
    /// </summary>
    [ToolboxBitmap(typeof(GradientTab), "GradientTab.ico")]
    [ResourceDescriptionAttribute("GradientTabDescription")]
    [DefaultEvent("SelectedIndexChanged")]
    [DefaultProperty("GradientTabPages")]
#if GENERAL_RELEASE
    [Designer(typeof(Ascend.Windows.Forms.Design.GradientTabDesigner), typeof(IDesigner))]
#else
    [Designer("Ascend.Windows.Forms.Design.GradientTabDesigner, Ascend.Design.v1.5, Culture=neutral, PublicKeyToken=5123e2ac4258b06a", typeof(IDesigner))]
#endif
    [DesignerCategory("Form")]
    public class GradientTab : System.Windows.Forms.ScrollableControl
    {
        private GradientTabRender _render;
        private GradientTabPageCollection _gradientTabPageCollection;
        private int _activeGradientTabPageIndex;
        private ToolTip _toolTip;
        private System.Windows.Forms.ContextMenuStrip _contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem _showMoreButtonsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _showFewerButtonsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _navigationPaneOptionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _addOrRemoveButtonsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator _mainDivider;
        private int _visibleTabCount;
        private int _maxVisibleTabCount;
        private ImageList _imageList;
        private bool _displayOptionsMenuItem;
        private bool _disposed;
        private bool _displayAddOrRemoveMenuItem = true;
        private bool _resetDisplayOrder;
        private string _currentDisplayOrderName;
        private GradientTabTabProperty _tabProperty;
        private bool _blockMouseMove;
        private bool _initialPaint = true;
        private string _initialFontName;
        private bool _showToolTips;
        private bool _hotTrack;
        private int _toolTipIndex;

        /// <summary>
        /// Occurs when the AntiAlias property changes.
        /// </summary>
        [ResourceDescriptionAttribute("AntiAliasChangedDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameAntiAliasChanged")]
        public event EventHandler AntiAliasChanged;

        /// <summary>
        /// Occurs when the Border property changes.
        /// </summary>
        [ResourceDescriptionAttribute("BorderChangedDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameBorderChanged")]
        public event EventHandler BorderChanged;

        /// <summary>
        /// Occurs when the BorderColor property changes.
        /// </summary>
        [ResourceDescriptionAttribute("BorderColorChangedDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameBorderColorChanged")]
        public event EventHandler BorderColorChanged;

        /// <summary>
        /// Occurs when a NavigationPanePage is deselected.
        /// </summary>
        [ResourceDescriptionAttribute("DeselectedDescription"), ResourceCategoryAttribute("ActionCategory"), ResourceDisplayName("DisplayNameDeselected")]
        public event EventHandler<GradientTabEventArgs> Deselected;

        /// <summary>
        /// Occurs before a NavigationPanePage is deselected, enabling a handler to cancel the NavigationPanePage change. 
        /// </summary>
        [ResourceDescriptionAttribute("DeselectingDescription"), ResourceCategoryAttribute("ActionCategory"), ResourceDisplayName("DisplayNameDeselecting")]
        public event EventHandler<GradientTabCancelEventArgs> Deselecting;

        /// <summary>
        /// Raised when the active navigation button index changes.
        /// </summary>
        [ResourceDescriptionAttribute("SelectedIndexChangedDescription"), ResourceCategoryAttribute("BehaviorCategory"), ResourceDisplayName("DisplayNameSelectedIndexChanged")]
        public event EventHandler SelectedIndexChanged;

        /// <summary>
        /// Occurs before a NavigationPanePage is selected, enabling a handler to cancel the NavigationPanePage change. 
        /// </summary>
        [ResourceDescriptionAttribute("SelectingDescription"), ResourceCategoryAttribute("ActionCategory"), ResourceDisplayName("DisplayNameSelecting")]
        public event EventHandler<GradientTabCancelEventArgs> Selecting;

        /// <summary>
        /// Occurs when a NavigationPanePage is selected.
        /// </summary>
        [ResourceDescriptionAttribute("SelectedDescription"), ResourceCategoryAttribute("ActionCategory"), ResourceDisplayName("DisplayNameSelected")]
        public event EventHandler<GradientTabEventArgs> Selected;

        /// <summary>
        /// Gets or sets the area of the control (for example, along the top) where the tabs are aligned.
        /// </summary>
        /// <remarks>
        /// When the Alignment property is set to Left or Right, the Multiline property is automatically set to true.
        /// </remarks>
        /// <value>One of the GradientTabAlignment values. The default is Top.</value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("AlignmentDescription"), ResourceDisplayName("DisplayNameAlignment"), DefaultValueAttribute(GradientTabAlignment.Top)]
        public GradientTabAlignment Alignment
        {
            get
            {
                return this._render.Alignment;

            }

            set
            {
                if (value == this._render.Alignment)
                {
                    return;

                }

                this._render.Alignment = value;

                this.SizePages();

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets if the add or remove menum item is visible on the control.
        /// </summary>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("AllowAddOrRemoveDescription"), ResourceDisplayName("DisplayNameAllowAddOrRemove"), DefaultValueAttribute(true)]
        public bool AllowAddOrRemove
        {
            get
            {
                return this._displayAddOrRemoveMenuItem;

            }

            set
            {
                if (this._displayAddOrRemoveMenuItem == value)
                {
                    return;

                }

                this._displayAddOrRemoveMenuItem = value;
                this._addOrRemoveButtonsToolStripMenuItem.Visible = this._displayAddOrRemoveMenuItem;

            }

        }

        /// <summary>
        /// Gets or sets if the options menum item is visible on the control.
        /// </summary>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("AllowOptionsDescription"), ResourceDisplayName("DisplayNameAllowOptions"), DefaultValueAttribute(true)]
        public bool AllowOptions
        {
            get
            {
                return this._displayOptionsMenuItem;

            }

            set
            {
                if (this._displayOptionsMenuItem == value)
                {
                    return;

                }

                this._displayOptionsMenuItem = value;
                this._navigationPaneOptionsToolStripMenuItem.Visible = this._displayOptionsMenuItem;

            }

        }

        /// <summary>
        /// Specifies the rendering hint for the control.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Boolean . Specifies if the rendering should use antialiasing.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("AntiAliasDescription"), ResourceDisplayName("DisplayNameAntiAlias"), DefaultValueAttribute(false)]
        public bool AntiAlias
        {
            get
            {
                return this._render.AntiAlias;

            }

            set
            {
                if (value == this._render.AntiAlias)
                {
                    return;

                }

                this._render.AntiAlias = value;

                base.Invalidate();

                this.OnAntiAliasChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets or sets the background color for the control.
        /// </summary>
        /// <value>A Color that represents the background color of the control. Transparent by default.</value>
        [DefaultValueAttribute(typeof(Color), "Transparent")]
        public override System.Drawing.Color BackColor
        {
            get
            {
                return base.BackColor;

            }

            set
            {
                base.BackColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the border for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// Border. An object of type Border representing the control's border width characteristics.
        /// </para>
        /// 	<para>
        /// This property is read/write.
        /// </para>
        /// </value>
        /// <remarks>
        /// For containers such as GradientPanel and GradientCaption, the Border property gets or sets their respective border widths inside the DisplayRectangle.
        /// </remarks>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("BorderDescription"), ResourceDisplayName("DisplayNameBorder"), DefaultValueAttribute(typeof(Border), "1, 1, 1, 1")]
        public Border Border
        {
            get
            {
                return this._render.Border;

            }

            set
            {
                if (value == this._render.Border)
                {
                    return;

                }

                this._render.Border = value;

                base.Invalidate();

                this.OnBorderChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets or sets the border color(s) for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// BorderColor. An object of type Border representing the control's border color characteristics.
        /// </para>
        /// 	<para>
        /// This property is read/write.
        /// </para>
        /// </value>
        /// <remarks>
        /// For containers such as GradientPanel and GradientCaption, the BorderColor property gets or sets their respective border colors inside the DisplayRectangle.
        /// </remarks>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("BorderColorDescription"), ResourceDisplayName("DisplayNameBorderColor"), DefaultValueAttribute(typeof(BorderColor), "Left=Color [ControlDarkDark],Top=Color [ControlDarkDark],Right=Color [ControlDarkDark],Bottom=Color [ControlDarkDark]")]
        public BorderColor BorderColor
        {
            get
            {
                return this._render.BorderColor;

            }

            set
            {
                if (value == this._render.BorderColor)
                {
                    return;

                }

                this._render.BorderColor = value;

                base.Invalidate();

                this.OnBorderColorChanged(EventArgs.Empty);

            }

        }

        /// <summary>
        /// Gets or sets the tab properties.
        /// </summary>
        [DesignOnlyAttribute(true), EditorBrowsableAttribute(EditorBrowsableState.Never), ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TabDescription"), ResourceDisplayName("DisplayNameTab")]
        public GradientTabTabProperty Tab
        {
            get
            {
                return this._tabProperty;

            }

            set
            {
                this._tabProperty = value;

            }

        }

        /// <summary>
        /// Determines if the Tab property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeTab()
        {
            return ((this._render.TabHeight != 18) || (this._render.TabWidth != 58) || (this._render.TabGradientHighColor != SystemColors.ButtonHighlight) || (this._render.TabGradientLowColor != SystemColors.GradientActiveCaption) || (this._render.TabBorderColor != SystemColors.ControlDarkDark) || (this._render.TabForeColor != SystemColors.ControlText) || (this._render.TabHighlightGradientHighColor != Color.White) || (this._render.TabHighlightGradientLowColor != Color.FromArgb(255, 165, 78)) || (this._render.TabActiveGradientHighColor != Color.FromArgb(255, 225, 155)) || (this._render.TabActiveGradientLowColor != Color.FromArgb(255, 165, 78)) || (this._render.TabTextAlign != ContentAlignment.MiddleLeft) || (this._render.TabImageAlign != ContentAlignment.MiddleLeft));

        }

        /// <summary>
        /// Resets the tab to default values.
        /// </summary>
        public void ResetTab()
        {
            this.TabGradientHighColor = SystemColors.ButtonHighlight;
            this.TabGradientLowColor = SystemColors.GradientActiveCaption;
            this.TabBorderColor = SystemColors.ControlDarkDark;
            this.TabForeColor = SystemColors.ControlText;
            this.TabHighlightGradientHighColor = Color.White;
            this.TabHighlightGradientLowColor = Color.FromArgb(255, 165, 78);
            this.TabActiveGradientHighColor = Color.FromArgb(255, 225, 155);
            this.TabActiveGradientLowColor = Color.FromArgb(255, 165, 78);
            this.TabTextAlign = ContentAlignment.MiddleLeft;
            this.TabImageAlign = ContentAlignment.MiddleLeft;

            base.Invalidate();

        }

        /// <summary>
        /// Gets or set the tab active gradient high color.
        /// </summary>
        [Browsable(false)]
        public Color TabActiveGradientHighColor
        {
            get
            {
                return this._render.TabActiveGradientHighColor;

            }

            set
            {
                if (this._render.TabActiveGradientHighColor == value)
                {
                    return;

                }

                Color oldColor = this._render.TabActiveGradientHighColor;

                this._render.TabActiveGradientHighColor = value;

                this.SetDefaultTabActiveGradientHighColor(oldColor, value);

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or set button active gradient low color.
        /// </summary>
        [Browsable(false)]
        public Color TabActiveGradientLowColor
        {
            get
            {
                return this._render.TabActiveGradientLowColor;

            }

            set
            {
                if (this._render.TabActiveGradientLowColor == value)
                {
                    return;

                }

                Color oldColor = this._render.TabActiveGradientLowColor;

                this._render.TabActiveGradientLowColor = value;

                this.SetDefaultTabActiveGradientLowColor(oldColor, value);

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the tab border color on the control.
        /// </summary>
        [Browsable(false)]
        public Color TabBorderColor
        {
            get
            {
                return this._render.TabBorderColor;

            }

            set
            {
                if (this._render.TabBorderColor == value)
                {
                    return;

                }

                this._render.TabBorderColor = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the forecolor associated with the tabs.
        /// </summary>
        [Browsable(false)]
        public Color TabForeColor
        {
            get
            {
                return this._render.TabForeColor;

            }

            set
            {
                if (this._render.TabForeColor == value)
                {
                    return;

                }

                Color oldColor = this._render.TabForeColor;

                this._render.TabForeColor = value;

                this.SetDefaultTabForeColor(oldColor, value);

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the font associated with the tabs.
        /// </summary>
        [Browsable(false)]
        public Font TabFont
        {
            get
            {
                return this._render.TabFont;

            }

            set
            {
                if (value == null)
                {
                    return;

                }

                if (this._render.TabFont == value)
                {
                    return;

                }

                this._render.TabFont = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Determines if the TabFont property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>always true</returns>
        public bool ShouldSerializeTabFont()
        {
            return true;

        }

        /// <summary>
        /// Gets or sets the tab gradient high color on the control.
        /// </summary>
        [Browsable(false)]
        public Color TabGradientHighColor
        {
            get
            {
                return this._render.TabGradientHighColor;

            }

            set
            {
                if (this._render.TabGradientHighColor == value)
                {
                    return;

                }

                Color oldColor = this._render.TabGradientHighColor;

                this._render.TabGradientHighColor = value;

                this.SetDefaultTabGradientHighColor(oldColor, value);

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the tab gradient low color.
        /// </summary>
        [Browsable(false)]
        public Color TabGradientLowColor
        {
            get
            {
                return this._render.TabGradientLowColor;

            }

            set
            {
                if (this._render.TabGradientLowColor == value)
                {
                    return;

                }

                Color oldColor = this._render.TabGradientLowColor;

                this._render.TabGradientLowColor = value;

                this.SetDefaultTabGradientLowColor(oldColor, value);

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the tab height on the control.
        /// </summary>
        [Browsable(false)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TabHeightDescription"), ResourceDisplayName("DisplayNameTabHeight"), DefaultValueAttribute(18)]
        public int TabHeight
        {
            get
            {
                return this._render.TabHeight;

            }

            set
            {
                if (this._render.TabHeight == value)
                {
                    return;

                }

                this._render.TabHeight = value;

                this.SizePages();

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the tab when it is moused over.
        /// </summary>
        [Browsable(false)]
        public Color TabHighlightGradientHighColor
        {
            get
            {
                return this._render.TabHighlightGradientHighColor;

            }

            set
            {
                if (this._render.TabHighlightGradientHighColor == value)
                {
                    return;

                }

                Color oldColor = this._render.TabHighlightGradientHighColor;

                this._render.TabHighlightGradientHighColor = value;

                this.SetDefaultTabHighlightGradientHighColor(oldColor, value);

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the tab when it is moused over.
        /// </summary>
        [Browsable(false)]
        public Color TabHighlightGradientLowColor
        {
            get
            {
                return this._render.TabHighlightGradientLowColor;

            }

            set
            {
                if (this._render.TabHighlightGradientLowColor == value)
                {
                    return;

                }

                Color oldColor = this._render.TabHighlightGradientLowColor;

                this._render.TabHighlightGradientLowColor = value;

                this.SetDefaultTabHighlightGradientLowColor(oldColor, value);

                base.Invalidate();

            }

        }

        /// <summary>
        /// The ContentAlignment associated with the tab's image.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.ContentAlignment . The ContentAlignment associated with the tab's image.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [Browsable(false)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ImageAlignmentDescription"), ResourceDisplayName("DisplayNameImageAlign"), DefaultValueAttribute(ContentAlignment.MiddleLeft)]
        public ContentAlignment TabImageAlign
        {
            get
            {
                return this._render.TabImageAlign;

            }

            set
            {
                if (this._render.TabImageAlign == value)
                {
                    return;

                }

                ContentAlignment oldAlignment = this._render.TabImageAlign;

                this._render.TabImageAlign = value;

                this.SetDefaultTabImageAlign(oldAlignment, value);

                base.Invalidate();

            }

        }

        /// <summary>
        /// The ContentAlignment associated with the tab's text.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.ContentAlignment . The ContentAlignment associated with the tab's text.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [Browsable(false)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TextAlignmentDescription"), ResourceDisplayName("DisplayNameTextAlign"), DefaultValueAttribute(ContentAlignment.MiddleLeft)]
        public ContentAlignment TabTextAlign
        {
            get
            {
                return this._render.TabTextAlign;

            }

            set
            {
                if (this._render.TabTextAlign == value)
                {
                    return;

                }

                ContentAlignment oldAlignment = this._render.TabTextAlign;

                this._render.TabTextAlign = value;

                this.SetDefaultTabTextAlign(oldAlignment, value);

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the tab width on the control.
        /// </summary>
        [Browsable(false)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TabWidthDescription"), ResourceDisplayName("DisplayNameTabWidth"), DefaultValueAttribute(58)]
        public int TabWidth
        {
            get
            {
                return this._render.TabWidth;

            }

            set
            {
                if (this._render.TabWidth == value)
                {
                    return;

                }

                this._render.TabWidth = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets the internal spacing, in pixels, of the contents of a control. 
        /// </summary>
        /// <value>A Padding that represents the internal spacing of the contents of a control.</value>
        protected override System.Windows.Forms.Padding DefaultPadding
        {
            get
            {
                return new Padding(3, 2, 3, 3);

            }

        }

        /// <summary>
        /// Gets the default initial size of the control.
        /// </summary>
        protected override Size DefaultSize
        {
            get
            {
                return new Size(200, 100);

            }

        }

        /// <summary>
        /// Gets the NavigationPanePage rectangle.
        /// </summary>
        /// <remarks>
        /// The property is read only.
        /// </remarks>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Rectangle GradientTabPageRectangle
        {
            get
            {
                int leftTab = 0;
                int rightTab = 0;
                int topTab = 0;
                int bottomTab = 0;

                switch (this.Alignment)
                {
                    case GradientTabAlignment.Bottom:
                        bottomTab = this.TabHeight;
                        break;

                    case GradientTabAlignment.Left:
                        leftTab = this.TabHeight;
                        break;

                    case GradientTabAlignment.Right:
                        rightTab = this.TabHeight;
                        break;

                    default:
                        topTab = this.TabHeight;
                        break;

                }

                int left = (this.Border.Left + this.Padding.Left + leftTab);
                int right = (this.Border.Right + this.Padding.Right + rightTab);
                int top = (this.Border.Top + this.Padding.Top + topTab);
                int bottom = (this.Border.Bottom + this.Padding.Bottom + bottomTab);

                return new Rectangle(left, top, (this.Width - (left + right)), (this.Height - (top + bottom)));

            }

        }

        /// <summary>
        /// A collection of pages used in the gradient tab.
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradienTabPageCollectionDescription"), ResourceDisplayName("DisplayNameGradientTabPages"), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public GradientTabPageCollection GradientTabPages
        {
            get
            {
                return this._gradientTabPageCollection;

            }

        }

        /// <summary>
        /// Gets or sets a value indicating whether the control's tabs change in appearance when the mouse passes over them.
        /// </summary>
        /// <value>true if the tabs change in appearance when the mouse passes over them; otherwise, false. The default is false.</value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("HotTrackDescription"), ResourceDisplayName("DisplayNameHotTrack"), DefaultValueAttribute(false)]
        public bool HotTrack
        {
            get
            {
                return this._hotTrack;

            }

            set
            {
                this._hotTrack = value;

            }

        }

        /// <summary>
        /// Represents the currently active navigation page.
        /// </summary>
        /// <value>
        /// </value>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public GradientTabPage SelectedGradientTabPage
        {
            get
            {
                int index = this._gradientTabPageCollection.IndexOf(this._render.DisplayOrder[this._activeGradientTabPageIndex].ToString());

                return this._gradientTabPageCollection[index];

            }

            set
            {
                if (value != null)
                {
                    if (this._gradientTabPageCollection.Contains(value))
                    {
                        if (this._render.DisplayOrder.Contains(value.Name))
                        {
                            this.SelectedIndex = this._render.DisplayOrder.IndexOf(value.Name);

                        }

                    }

                }

            }

        }

        /// <summary>
        /// Represents the index of the currently active navigation button.
        /// </summary>
        [SettingsBindableAttribute(true)]
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int SelectedIndex
        {
            get
            {
                return this._activeGradientTabPageIndex;

            }

            set
            {
                if (value == this._activeGradientTabPageIndex)
                {
                    return;

                }

                int oldIndex = this._activeGradientTabPageIndex;

                GradientTabPage oldPage = null;
                string oldKey = string.Empty;

                if (oldIndex > -1)
                {
                    oldPage = this._gradientTabPageCollection[oldIndex];
                    oldKey = this._gradientTabPageCollection[oldIndex].Key;

                }

                GradientTabCancelEventArgs navigationPaneCancelEventArgsDeselecting = new GradientTabCancelEventArgs(oldPage, oldIndex, oldKey, false, GradientTabAction.Deselecting);
                this.OnDeselecting(navigationPaneCancelEventArgsDeselecting);

                if (!navigationPaneCancelEventArgsDeselecting.Cancel)
                {
                    GradientTabCancelEventArgs navigationPaneCancelEventArgsSecting = new GradientTabCancelEventArgs(oldPage, oldIndex, oldKey, false, GradientTabAction.Selecting);
                    this.OnSelecting(navigationPaneCancelEventArgsSecting);

                    if (!navigationPaneCancelEventArgsSecting.Cancel)
                    {
                        this._activeGradientTabPageIndex = value;

                        if ((value > -1) && (value < this._gradientTabPageCollection.Count) && (value < this._render.DisplayOrder.Count))
                        {
                            if (oldIndex > -1) this.OnDeselected(new GradientTabEventArgs(oldPage, oldIndex, oldKey, GradientTabAction.Deselected));

                            this._currentDisplayOrderName = this._render.DisplayOrder[value].ToString();

                            if (this._render.DisplayOrder.Contains(this._currentDisplayOrderName))
                            {
                                this._render.ActiveIndex = this._render.DisplayOrder.IndexOf(this._currentDisplayOrderName);

                            }

                            int index = this._gradientTabPageCollection.IndexOf(this._currentDisplayOrderName);

                            this._render.ActiveIndex = value;

                            this._gradientTabPageCollection[index].BringToFront();

                            base.Invalidate();

                            this.OnSelectedIndexChanged(new EventArgs());

                            this._gradientTabPageCollection[index].Focus();
                            this._gradientTabPageCollection[index].Select();

                            if (this.DesignMode)
                            {
                                this.Focus();
                                this.Select();

                            }

                            this.OnSelected(new GradientTabEventArgs(this._gradientTabPageCollection[index], index, this._gradientTabPageCollection[index].Key, GradientTabAction.Selected));

                        }

                    }

                }

            }

        }

        /// <summary>
        /// Gets or sets a value indicating whether a tab's ToolTip is shown when the mouse passes over the tab.
        /// </summary>
        /// <remarks>
        /// To create a ToolTip for a tab, set the ToolTipText property of the GradientTabPage
        /// </remarks>
        /// <value>true if ToolTips are shown for the tabs that have them; otherwise, false. The default is false.</value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("ShowToolTipsDescription"), ResourceDisplayName("DisplayNameShowToolTips"), DefaultValueAttribute(false)]
        public bool ShowToolTips
        {
            get
            {
                return this._showToolTips;

            }

            set
            {
                this._showToolTips = value;

            }

        }

        /// <summary>
        /// Gets or sets the way that the control's tabs are sized. 
        /// </summary>
        /// <value>
        /// One of the GradientTabSizeMode values. The default is Normal.
        /// </value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("SizeModeDescription"), ResourceDisplayName("DisplayNameSizeMode"), DefaultValueAttribute(GradientTabSizeMode.Normal)]
        public GradientTabSizeMode SizeMode
        {
            get
            {
                return this._render.SizeMode;

            }

            set
            {
                if (this._render.SizeMode == value)
                {
                    return;

                }

                this._render.SizeMode = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the text associated with this control.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never), Browsable(false), Bindable(false)]
        public override string Text
        {
            get
            {
                return base.Text;

            }

            set
            {
                base.Text = value;

            }

        }

        /// <summary>
        /// Gets the internal renderer.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never), Browsable(false), Bindable(false)]
        public GradientTabRender Render
        {
            get
            {
                return this._render;

            }

        }

        /// <summary>
        /// Specifies the painting style applied to the background in a control.
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("RenderModeDescription"), ResourceDisplayName("DisplayNameRenderMode"), DefaultValueAttribute(typeof(RenderMode), "Gradient")]
        public RenderMode RenderMode
        {
            get
            {
                return this._render.RenderMode;

            }

            set
            {
                if (value == this._render.RenderMode)
                {
                    return;

                }

                this._render.RenderMode = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Gets or sets the ImageList that contains the Images displayed on the control. 
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ImageListDescription"), ResourceDisplayName("DisplayNameImageList"), DefaultValueAttribute(typeof(ImageList), "(none)")]
        public ImageList ImageList
        {
            get
            {
                return this._imageList;

            }

            set
            {
                if (this._imageList != value)
                {
                    this._imageList = value;

                    for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
                    {
                        this._gradientTabPageCollection[i].ImageList = value;

                    }

                    base.Invalidate();

                }

            }

        }

        /// <summary>
        /// Gets or sets a value indicating whether more than one row of tabs can be displayed. 
        /// </summary>
        /// <remarks>
        /// If Multiline is false, only one row of tabs is displayed, even if all the tabs do not fit in the available space. In that case, however, arrows are displayed that enable the user to navigate to the undisplayed tabs.
        /// If the Multiline property is changed to false while the Alignment property is set to Left or Right, the Alignment property is automatically reset to Top.
        /// </remarks>
        /// <value>true if more than one row of tabs can be displayed; otherwise, false. The default is false.</value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("MultilineDescription"), ResourceDisplayName("DisplayNameMultiline"), DefaultValueAttribute(false)]
        public bool Multiline
        {
            get
            {
                return this._render.Multiline;

            }

            set
            {
                if (this._render.Multiline != value)
                {
                    this._render.Multiline = value;

                    base.Invalidate();

                }

            }

        }

        /// <summary>
        /// Gets or sets a value indicating whether this control should redraw its surface using a secondary buffer to reduce or prevent flicker.
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never), Browsable(false), Bindable(false)]
        protected override bool DoubleBuffered
        {
            get
            {
                return base.DoubleBuffered;

            }

            set
            {
                base.DoubleBuffered = value;

            }

        }

        /// <summary>
        /// Gets or sets the color of the body of the control.
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ControlColorDescription"), ResourceDisplayName("DisplayNameControlColor"), DefaultValueAttribute(typeof(Color), "ControlLightLight")]
        public Color ControlColor
        {
            get
            {
                return this._render.ControlColor;

            }

            set
            {
                if (value == this._render.ControlColor)
                {
                    return;

                }

                this._render.ControlColor = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// 
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Never), Browsable(false), Bindable(false)]
        public override System.Windows.Forms.Cursor Cursor
        {
            get
            {
                return base.Cursor;

            }

            set
            {
                base.Cursor = value;

            }

        }

        /// <summary>
        /// Gets the number of tab pages in the gradient tab pane. 
        /// </summary>
        /// <value>
        /// The number of tab pages in the gradient tab pane. 
        /// </value>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int GradientTabPageCount
        {
            get
            {
                int count = 0;

                for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
                {
                    if (this._gradientTabPageCollection[i].Visible) count++;

                }

                return count;

            }

        }

        /// <summary>
        /// Gets or sets the current count of the visible tabs.
        /// </summary>
        /// <remarks>
        /// Between 0 and the total number of tabs.
        /// </remarks>
        [ResourceDescriptionAttribute("VisibleTabCountDescription"), ResourceDisplayName("DisplayNameVisibleTabCount")]
        [SettingsBindableAttribute(true)]
        [Browsable(false)]
        public int VisibleTabCount
        {
            get
            {
                return this._visibleTabCount;

            }

            set
            {
                if (this._visibleTabCount != value)
                {
                    if (value < 0) value = 0;
                    if (value > this._maxVisibleTabCount) value = this._maxVisibleTabCount;

                    this._visibleTabCount = value;

                    this._render.DisplayTabCount = this._visibleTabCount;

                    base.Invalidate();

                    this.SizePages();

                    this.DetermineTabMenuState();

                }

            }

        }

        /// <summary>
        /// Determines if the VisibleTabCount property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>always true</returns>
        public bool ShouldSerializeVisibleTabCount()
        {
            return true;

        }

        /// <summary>
        /// Gets or sets a value that determines whether to use the compatible text rendering engine (GDI+) or not (GDI). 
        /// </summary>
        /// <value>
        /// true if the compatible text rendering engine (GDI+) is used; otherwise, false. 
        /// </value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("UseCompatibleTextRenderingDescription"), ResourceDisplayName("DisplayNameUseCompatibleTextRendering"), DefaultValueAttribute(false)]
        public bool UseCompatibleTextRendering
        {
            get
            {
                return this._render.UseCompatibleTextRendering;

            }

            set
            {
                if (value == this._render.UseCompatibleTextRendering)
                {
                    return;

                }

                this._render.UseCompatibleTextRendering = value;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Initializes a new instance of the GradientTab class.
        /// </summary>
        public GradientTab() : base()
        {
            base.SetStyle(ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.Selectable, true);
            base.BackColor = Color.Transparent;

            this._render = new GradientTabRender(this);

            this._gradientTabPageCollection = new GradientTabPageCollection(this);

            this._tabProperty = new GradientTabTabProperty(this, 18, 58, SystemColors.ButtonHighlight, SystemColors.GradientActiveCaption, SystemColors.ControlDarkDark, Color.White, Color.FromArgb(255, 165, 78), Color.FromArgb(255, 225, 155), Color.FromArgb(255, 165, 78), SystemColors.ControlText, ContentAlignment.MiddleLeft);

            this._activeGradientTabPageIndex = -1;

            this._toolTip = new ToolTip();
            this._toolTip.SetToolTip(this, string.Empty);

            this._displayOptionsMenuItem = true;

            this._contextMenuStrip = new System.Windows.Forms.ContextMenuStrip();
            this._contextMenuStrip.Closed += new ToolStripDropDownClosedEventHandler(this.ContextMenuStrip_Closed);

            this._showMoreButtonsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._showMoreButtonsToolStripMenuItem.Click += new EventHandler(this.ShowMoreButtonsToolStripMenuItem_Click);
            this._showMoreButtonsToolStripMenuItem.Enabled = false;
            this._showMoreButtonsToolStripMenuItem.ShowShortcutKeys = true;

            this._showFewerButtonsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._showFewerButtonsToolStripMenuItem.Click += new EventHandler(this.ShowFewerButtonsToolStripMenuItem_Click);
            this._showFewerButtonsToolStripMenuItem.Enabled = true;
            this._showFewerButtonsToolStripMenuItem.ShowShortcutKeys = true;

            this._navigationPaneOptionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._navigationPaneOptionsToolStripMenuItem.Click += new EventHandler(this.NavigationPaneOptionsToolStripMenuItem_Click);
            this._navigationPaneOptionsToolStripMenuItem.Enabled = true;
            this._navigationPaneOptionsToolStripMenuItem.ShowShortcutKeys = true;

            this._addOrRemoveButtonsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._addOrRemoveButtonsToolStripMenuItem.ShowShortcutKeys = true;

            this._mainDivider = new ToolStripSeparator();

            this._contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._showMoreButtonsToolStripMenuItem,
            this._showFewerButtonsToolStripMenuItem,
            this._addOrRemoveButtonsToolStripMenuItem,
            this._mainDivider,
            this._navigationPaneOptionsToolStripMenuItem});

            this._showMoreButtonsToolStripMenuItem.Text = ResourceText.GetLocalizedString("NPMenuShowMoreButtonsText");
            this._showMoreButtonsToolStripMenuItem.Image = Properties.Resources.MenuViewPanNorth.ToBitmap();
            this._showFewerButtonsToolStripMenuItem.Text = ResourceText.GetLocalizedString("NPMenuShowFewerButtonsText");
            this._showFewerButtonsToolStripMenuItem.Image = Properties.Resources.MenuViewPanSouth.ToBitmap();
            this._navigationPaneOptionsToolStripMenuItem.Text = ResourceText.GetLocalizedString("NPMenuOptionsText");
            this._addOrRemoveButtonsToolStripMenuItem.Text = ResourceText.GetLocalizedString("NPMenuAddRemoveButtonsText");

            this._render.TabFont = new Font(this.Font.FontFamily, this.TabFont.Size, this.TabFont.Style);

        }

        /// <summary>
        /// Clears all pages and settings from the control.
        /// </summary>
        /// <remarks>
        /// This method is used internally and cannot be called by your code.
        /// </remarks>
        internal void ClearPages()
        {
            this.Controls.Clear();
            this.VisibleTabCount = 0;
            this._maxVisibleTabCount = 0;
            this.Render.DisplayOrder.Clear();
            this.SelectedIndex = -1;

        }

        /// <summary>
        /// Raises the Paint event.
        /// </summary>
        /// <param name="e">A System.Windows.Forms.PaintEventArgs that contains the event data.</param>
        /// <remarks>
        /// <para>
        /// Raising an event invokes the event handler through a delegate. For more information, Raising an Event.
        /// </para>
        /// <para>
        /// The OnPaint method also allows derived classes to handle the event without attaching a delegate. This is the preferred technique for handling the event in a derived class.
        /// </para>
        /// <para>
        /// Note for Inheritors:
        /// When overriding OnPaint in a derived class, be sure to call the base class's OnPaint method so that registered delegates receive the event.
        /// </para>
        /// </remarks>
        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            if (!this.Disposing)
            {
                if (this._initialPaint)
                {
                    this._initialPaint = false;

                    this.SizePages();

                }

                base.OnPaint(e);

                if (this._render.DisplayOrder.Count >= 1 && String.IsNullOrEmpty(this._render.DisplayOrder[0].ToString()))
                {
                    this.Reset();

                }

                if (this._activeGradientTabPageIndex == -1)
                {
                    if (this._gradientTabPageCollection.Count > 0)
                    {
                        this._activeGradientTabPageIndex = 0;
                        this._gradientTabPageCollection[0].BringToFront();

                    }

                }

                Rectangle modifiedRectangle = new Rectangle(0, 0, (this.Width - 1), (this.Height - 1));
                this._render.DisplayRectangle = modifiedRectangle;

                this._render.Render(e);

            }

        }

        /// <summary>
        /// Fires the event indicating that the control Border has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnBorderChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnBorderChanged(EventArgs e)
        {
            if (this.BorderChanged != null)
            {
                this.BorderChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that the control BorderColor has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnBorderColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnBorderColorChanged(EventArgs e)
        {
            if (this.BorderColorChanged != null)
            {
                this.BorderColorChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that the control antialias has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnAntiAliasChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnAntiAliasChanged(EventArgs e)
        {
            if (this.AntiAliasChanged != null)
            {
                this.AntiAliasChanged(this, e);

            }

        }

        /// <param name="e">A System.Windows.Forms.MouseEventArgs that contains the event data.</param>
        protected override void OnMouseMove(System.Windows.Forms.MouseEventArgs e)
        {
            try
            {
                bool shouldHighlightTab = true;

                if (this._render.HasTabOverflow)
                {
                    if (this._render.LeftArrowButtonRectangle.Contains(e.X, e.Y))
                    {
                        shouldHighlightTab = false;
                        if (!this._render.IsLeftArrowButtonHighlighted)
                        {
                            this._render.IsLeftArrowButtonHighlighted = true;
                            this._render.HighlightIndex = -1;

                            base.Invalidate();

                        }

                    }
                    else if (this._render.RightArrowButtonRectangle.Contains(e.X, e.Y))
                    {
                        shouldHighlightTab = false;
                        if (!this._render.IsRightArrowButtonHighlighted)
                        {
                            this._render.IsRightArrowButtonHighlighted = true;
                            this._render.HighlightIndex = -1;

                            base.Invalidate();

                        }

                    }
                    else
                    {
                        this._render.IsLeftArrowButtonHighlighted = false;

                    }

                }

                if (this._hotTrack || this._showToolTips)
                {
                    int tabIndex = -1;

                    if (shouldHighlightTab)
                    {
                        for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
                        {
                            if (this._gradientTabPageCollection[i].TabRectangle.Contains(e.X, e.Y))
                            {
                                if (this._render.DisplayOrder.Contains(this._gradientTabPageCollection[i].Name))
                                {
                                    tabIndex = this._render.DisplayOrder.IndexOf(this._gradientTabPageCollection[i].Name);

                                }

                                if (this._render.HighlightIndex != tabIndex)
                                {
                                    if (this._hotTrack)
                                    {
                                        this._render.HighlightIndex = tabIndex;

                                    }

                                    base.Invalidate();

                                }

                                if (!this.DesignMode)
                                {
                                    if (this._toolTipIndex != tabIndex)
                                    {
                                        this._toolTipIndex = tabIndex;

                                        if (this._showToolTips)
                                        {
                                            if (!String.IsNullOrEmpty(this._gradientTabPageCollection[i].ToolTipText))
                                            {
                                                this._toolTip.SetToolTip(this, this._gradientTabPageCollection[i].ToolTipText);

                                            }
                                            else
                                            {
                                                this._toolTip.RemoveAll();
                                                this._toolTip.Hide(this);

                                            }

                                        }

                                    }

                                }

                                return;

                            }

                        }

                    }

                    this._toolTip.RemoveAll();

                    if (this._toolTip.Active)
                    {
                        this._toolTip.Hide(this);

                    }

                    if (this._render.HighlightIndex != -1)
                    {
                        this._render.HighlightIndex = -1;

                        base.Invalidate();

                    }

                }

            }
            catch
            {
                throw;

            }
            finally
            {
                base.OnMouseMove(e);

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="page">The GradientTabPage that is being added.</param>
        internal void PageAdded(GradientTabPage page)
        {
            if (!this.Controls.Contains(page))
            {
                this.Controls.Add(page);
                page.ImageIndexChanged += new EventHandler(this.OnPageChanged);
                page.TextChanged += new EventHandler(this.OnPageChanged);
                page.ImageList = this._imageList;
                page.TabFont = this.TabFont;

            }

            if (page.TabVisible)
            {
                this._visibleTabCount++;
                this._maxVisibleTabCount++;

                this._render.DisplayTabCount = this._visibleTabCount;

            }

            if (!DesignMode)
            {
                this._render.DisplayOrder.Add(page.Name);

            }
            else
            {
                if (!this._render.DisplayOrder.Contains(page.Name))
                {
                    this._render.DisplayOrder.Add(page.Name);

                }
                else
                {
                    int index = this._render.DisplayOrder.IndexOf(page.Name);

                    if (index > -1) this._render.DisplayOrder.RemoveAt(index);

                    this._render.DisplayOrder.Add(page.Name);

                }

                if (string.IsNullOrEmpty(page.Text))
                {
                    page.Text = page.Name;

                }

            }

            base.Invalidate();

        }

        /// <summary>
        /// Sizes the navigation pages to the available space.
        /// </summary>
        private void SizePages()
        {
            if (this.Visible)
            {
                this.SizePages(this.GradientTabPageRectangle);

            }

        }

        /// <summary>
        /// Sizes the navigation pages to the available space.
        /// </summary>
        /// <param name="rectangle">The bounds of the navigation pane page</param>
        private void SizePages(Rectangle rectangle)
        {
            if (this.Visible)
            {
                for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
                {
                    this._gradientTabPageCollection[i].Bounds = rectangle;

                }

            }

        }

        ///<summary>
        /// Raises the MouseLeave event.
        /// </summary>
        /// <param name="e">An System.EventArgs that contains the event data.</param>
        protected override void OnMouseLeave(System.EventArgs e)
        {
            base.OnMouseLeave(e);

            this.Cursor = Cursors.Default;

            if (this._render.IsLeftArrowButtonHighlighted)
            {
                this._render.IsLeftArrowButtonHighlighted = false;
                this._render.HighlightIndex = -1;

                base.Invalidate();

            }
            else if (!this._render.IsRightArrowButtonHighlighted)
                {
                    this._render.IsRightArrowButtonHighlighted = false;
                    this._render.HighlightIndex = -1;

                    base.Invalidate();

            }
            else if (this._render.HighlightIndex != -1)
            {
                this._render.HighlightIndex = -1;

                base.Invalidate();

            }

        }

        /// <summary>
        /// Raises the MouseClick event.
        /// </summary>
        /// <param name="e">An System.EventArgs that contains the event data.</param>
        protected override void OnMouseClick(System.Windows.Forms.MouseEventArgs e)
        {
            base.OnMouseClick(e);

            if (e.Button == MouseButtons.Left)
            {
                bool shouldCheckTab = true;

                if (this._render.HasTabOverflow)
                {
                    if (this._render.LeftArrowButtonRectangle.Contains(e.X, e.Y))
                    {
                        shouldCheckTab = false;

                        if (this._render.IsLeftArrowButtonEnabled)
                        {
                            this._render.IsLeftArrowButtonActive = true;

                            this.MoveTabsLeft();

                            base.Invalidate();

                        }

                    }
                    else if (this._render.RightArrowButtonRectangle.Contains(e.X, e.Y))
                    {
                        shouldCheckTab = false;

                        if (this._render.IsRightArrowButtonEnabled)
                        {
                            this._render.IsRightArrowButtonActive = true;

                            this.MoveTabsRight();

                            base.Invalidate();

                        }

                    }
                    else
                    {
                        this._render.IsLeftArrowButtonActive = false;

                    }

                }

                if (shouldCheckTab)
                {
                    int actualIndex = 0;

                    for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
                    {
                        if (this._gradientTabPageCollection[i].TabRectangle.Contains(e.X, e.Y))
                        {
                            if (this._gradientTabPageCollection[i].Enabled)
                            {
                                this.SelectedGradientTabPage = this._gradientTabPageCollection[i];

                            }
                            break;

                        }

                        actualIndex++;

                    }

                }

            }

        }

        private void MoveTabsRight()
        {
            if (this._render.StartingTabIndexOffset < (this._gradientTabPageCollection.VisibleCount - 1))
            {
                this._render.StartingTabIndexOffset++;
                base.Invalidate();

            }
            else
            {
                this._render.StartingTabIndexOffset = (this._gradientTabPageCollection.VisibleCount - 1);

            }

        }

        private void MoveTabsLeft()
        {
            if (this._render.StartingTabIndexOffset > 0)
            {
                this._render.StartingTabIndexOffset--;
                base.Invalidate();

            }

        }

        /// <summary>
        /// Raises the Resize event. 
        /// </summary>
        /// <param name="e">An System.EventArgs that contains the event data.</param>
        protected override void OnResize(System.EventArgs e)
        {
            base.OnResize(e);

            base.Invalidate();

            this.SizePages();

        }

        /// <summary>
        /// Raises the Selecting event.
        /// </summary>
        /// <param name="e">A NavigationPaneCancelEventArgs that contains the event data.</param>
        /// <remarks>
        /// Raising an event invokes the event handler through a delegate.
        /// The OnSelecting method also enables derived classes to handle the event without attaching a delegate. This is the preferred technique for handling the event in a derived class.
        /// Notes to Inheritors When overriding OnSelecting in a derived class, be sure to call the base class's OnSelecting method so that registered delegates receive the event. 
        /// </remarks>
        protected virtual void OnSelecting(GradientTabCancelEventArgs e)
        {
            if (this.Selecting != null)
            {
                this.Selecting(this, e);

            }

        }

        /// <summary>
        /// Raises the Selected event.
        /// </summary>
        /// <param name="e">A NavigationPaneEventArgs that contains the event data.</param>
        protected virtual void OnSelected(GradientTabEventArgs e)
        {
            if (this.Selected != null)
            {
                this.Selected(this, e);

            }

        }

        /// <summary>
        /// Raises the SelectedIndexChanged event.
        /// </summary>
        /// <param name="e">An System.EventArgs that contains the event data.</param>
        private void OnSelectedIndexChanged(EventArgs e)
        {
            if (this.SelectedIndexChanged != null)
            {
                this.SelectedIndexChanged(this, e);

            }

        }

        /// <summary>
        /// Called when a page is removed by an external class.
        /// </summary>
        /// <param name="page">The NavigationPanePage the is being removed.</param>
        internal void PageRemoved(GradientTabPage page)
        {
            page.ImageIndexChanged -= new EventHandler(this.OnPageChanged);
            page.TextChanged -= new EventHandler(this.OnPageChanged);

            if ((this._activeGradientTabPageIndex >= (this._gradientTabPageCollection.Count - 1)) && (this._gradientTabPageCollection.Count > 0))
            {
                this._activeGradientTabPageIndex = 0;

            }

            if (page.TabVisible)
            {
                this._maxVisibleTabCount--;
                this.VisibleTabCount = (this.VisibleTabCount - 1);

                this._render.DisplayTabCount = this._visibleTabCount;

            }

            if (this._render.DisplayOrder.Contains(page.Name)) this._render.DisplayOrder.Remove(page.Name);
            this._render.DisplayTabCount = this._visibleTabCount;

            if (!this.DesignMode)
            {
                if (this.Controls.Contains(page))
                {
                    this.Controls.Remove(page);

                }

            }

            base.Invalidate();

        }

        private void ContextMenuStrip_Closed(object sender, ToolStripDropDownClosedEventArgs e)
        {
            //this._render.ConfigureFooterHighlight = false;

        }

        /// <param name="e">A System.Windows.Forms.MouseEventArgs that contains the event data.</param>
        protected override void OnMouseUp(System.Windows.Forms.MouseEventArgs e)
        {
            if (this._render.IsLeftArrowButtonActive)
            {
                this._render.IsLeftArrowButtonActive = false;
                base.Invalidate();

            }
            else if (this._render.IsRightArrowButtonActive)
            {
                this._render.IsRightArrowButtonActive = false;
                base.Invalidate();

            }

            base.OnMouseUp(e);

        }

        /// <summary>
        /// Shows less tabs on the gradient tab.
        /// </summary>
        public void LessTabs()
        {
            if (this._visibleTabCount > 0)
            {
                this.VisibleTabCount = (this._visibleTabCount - 1);

            }

        }

        /// <summary>
        /// Shows more tabs on the gradient tab.
        /// </summary>
        public void MoreTabs()
        {
            if (this._visibleTabCount < this._maxVisibleTabCount)
            {
                this.VisibleTabCount = (this._visibleTabCount + 1);

            }

        }

        /// <summary>
        /// Makes the GradientTabPage following the GradientTabPage with the specified key the current GradientTabPage. 
        /// </summary>
        /// <param name="key">The key in the GradientTabPages collection of the GradientTabPage to deselect.</param>
        /// <remarks>
        /// Use this method to programmatically deselect a particular GradientTabPage in a GradientTab. If there are at least two GradientTabPages in the control, the GradientTabPage following the specified GradientTabPage becomes the current GradientTabPage. If the specified GradientTabPage is the last GradientTabPage in the control, the first GradientTabPage becomes the current GradientTabPage.
        /// </remarks>
        public void DeselectGradientTabPage(string key)
        {
            int pageIndex = this._gradientTabPageCollection.IndexOf(key);

            if (pageIndex != -1)
            {
                this.DeselectGradientTabPage(pageIndex);

            }

        }


        /// <summary>
        /// Makes the GradientTabPage following the specified GradientTabPage as the current GradientTabPage. 
        /// </summary>
        /// <param name="page">The GradientTabPage to be deselected from GradientTabPages collection</param>
        /// <remarks>
        /// Use this method to programmatically deselect a particular GradientTabPage in a GradientTab. If there are at least two GradientTabPages in the control, the GradientTabPage following the specified GradientTabPage becomes the current GradientTabPage. If the specified GradientTabPage is the last GradientTabPage in the control, the first GradientTabPage becomes the current GradientTabPage.
        /// </remarks>       
        public void DeselectGradientTabPage(GradientTabPage page)
        {
            int pageIndex = this._gradientTabPageCollection.IndexOf(page);

            if (pageIndex != -1)
            {
                this.DeselectGradientTabPage(pageIndex);
            }

        }

        /// <summary>
        /// Makes the GradientTabPage following the GradientTabPage with the specified index the current GradientTabPage. 
        /// </summary>
        /// <param name="index">The index in the GradientTabPages collection of the GradientTabPage to deselect.</param>
        /// <remarks>
        /// Use this method to programmatically deselect a particular GradientTabPage in a GradientTab. If there are at least two GradientTabPages in the control, the GradientTabPage following the specified GradientTabPage becomes the current GradientTabPage. If the specified GradientTabPage is the last GradientTabPage in the control, the first GradientTabPage becomes the current GradientTabPage.
        /// </remarks>
        public void DeselectGradientTabPage(int index)
        {

            GradientTabPage gradientTabPage = this.GetGradientTabPage(index);

            if (this.SelectedGradientTabPage == gradientTabPage)
            {
                if ((0 <= index) && (index < (this.GradientTabPages.Count - 1)))
                {
                    this.SelectedIndex = ++index;

                }
                else
                {
                    this.SelectedIndex = 0;

                }

            }

        }

        private void DetermineTabMenuState()
        {
            if (!this.DesignMode)
            {
                if (this._maxVisibleTabCount != 0)
                {
                    if (this._visibleTabCount == this._maxVisibleTabCount)
                    {
                        this._showMoreButtonsToolStripMenuItem.Enabled = false;

                    }
                    else
                    {
                        this._showMoreButtonsToolStripMenuItem.Enabled = true;

                    }

                    if (this._visibleTabCount == 0)
                    {
                        this._showFewerButtonsToolStripMenuItem.Enabled = false;

                    }
                    else
                    {
                        this._showFewerButtonsToolStripMenuItem.Enabled = true;

                    }

                }
                else
                {
                    this._showMoreButtonsToolStripMenuItem.Enabled = false;
                    this._showFewerButtonsToolStripMenuItem.Enabled = false;

                }

                if ((this._gradientTabPageCollection != null) && (this._gradientTabPageCollection.Count > 0))
                {
                    this._navigationPaneOptionsToolStripMenuItem.Enabled = true;
                    this._addOrRemoveButtonsToolStripMenuItem.Enabled = true;

                    if (this._displayOptionsMenuItem)
                    {
                        this._mainDivider.Visible = true;
                        this._navigationPaneOptionsToolStripMenuItem.Visible = true;

                    }
                    else
                    {
                        this._mainDivider.Visible = false;
                        this._navigationPaneOptionsToolStripMenuItem.Visible = false;

                    }

                    if ((this._gradientTabPageCollection.Count != this._addOrRemoveButtonsToolStripMenuItem.DropDownItems.Count) || this._resetDisplayOrder)
                    {
                        this._resetDisplayOrder = false;

                        if (this._addOrRemoveButtonsToolStripMenuItem.HasDropDownItems) this._addOrRemoveButtonsToolStripMenuItem.DropDownItems.Clear();

                        for (int i = 0; i < this._contextMenuStrip.Items.Count; i++)
                        {
                            string name = this._contextMenuStrip.Items[i].Name;

                            if ((name != this._addOrRemoveButtonsToolStripMenuItem.Name) && (name != this._showMoreButtonsToolStripMenuItem.Name) && (name != this._showFewerButtonsToolStripMenuItem.Name) && (name != this._navigationPaneOptionsToolStripMenuItem.Name) && (name != this._mainDivider.Name))
                            {
                                this._contextMenuStrip.Items.Remove(this._contextMenuStrip.Items[i]);

                            }

                        }

                        ToolStripMenuItem buttonMenuItem;
                        ToolStripMenuItem buttonMenuItemMinimized;
                        int index;

                        for (int i = 0; i < this._render.DisplayOrder.Count; i++)
                        {
                            index = this._gradientTabPageCollection.IndexOf(this._render.DisplayOrder[i].ToString());

                            if (index > -1)
                            {
                                buttonMenuItem = new ToolStripMenuItem(this._gradientTabPageCollection[index].Text, this._gradientTabPageCollection[index].Image, this.AddRemoveMenuItem_Click);

                                if (this._gradientTabPageCollection[index].Visible)
                                {
                                    buttonMenuItem.Checked = true;

                                }

                                this._addOrRemoveButtonsToolStripMenuItem.DropDownItems.Add(buttonMenuItem);

                                buttonMenuItemMinimized = new ToolStripMenuItem(this._gradientTabPageCollection[index].Text, this._gradientTabPageCollection[index].Image, this.MinimizedMenuItem_Click, "MenuItemMinimized" + this._gradientTabPageCollection[index].Text);
                                buttonMenuItemMinimized.Visible = false;
                                buttonMenuItemMinimized.Checked = false;
                                buttonMenuItemMinimized.Tag = this._render.DisplayOrder[i].ToString();

                                this._contextMenuStrip.Items.Add(buttonMenuItemMinimized);

                            }

                        }

                    }
                    else
                    {
                        int index;

                        for (int i = 0; i < this._render.DisplayOrder.Count; i++)
                        {
                            index = this._gradientTabPageCollection.IndexOf(this._render.DisplayOrder[i].ToString());

                            if (index > -1)
                            {
                                this._addOrRemoveButtonsToolStripMenuItem.DropDownItems[i].Text = this._gradientTabPageCollection[index].Text;

                                if (this._gradientTabPageCollection[index].TabVisible)
                                {
                                    ((ToolStripMenuItem)this._addOrRemoveButtonsToolStripMenuItem.DropDownItems[i]).Checked = true;

                                }
                                else
                                {
                                    ((ToolStripMenuItem)this._addOrRemoveButtonsToolStripMenuItem.DropDownItems[i]).Checked = false;

                                }

                                ((ToolStripMenuItem)this._addOrRemoveButtonsToolStripMenuItem.DropDownItems[i]).Visible = this._gradientTabPageCollection[index].Visible;

                            }

                        }

                    }

                    int indexMinimized;
                    ToolStripItem minimizedItem;

                    for (int i = 0; i < this._render.DisplayOrder.Count; i++)
                    {
                        indexMinimized = this._gradientTabPageCollection.IndexOf(this._render.DisplayOrder[i].ToString());

                        if (indexMinimized > -1)
                        {
                            minimizedItem = this._contextMenuStrip.Items["MenuItemMinimized" + this._gradientTabPageCollection[indexMinimized].Text];

                            ToolStripMenuItem toolStripMenuItem = minimizedItem as ToolStripMenuItem;

                            if (toolStripMenuItem != null)
                            {
                                //if (!this._gradientTabPageCollection[indexMinimized].ButtonMinimizedVisible)
                                //{
                                    this._mainDivider.Visible = true;
                                    minimizedItem.Visible = true;

                                    if (toolStripMenuItem != null)
                                    {
                                        if (i == this._activeGradientTabPageIndex)
                                        {
                                            toolStripMenuItem.Checked = true;

                                        }
                                        else
                                        {
                                            toolStripMenuItem.Checked = false;

                                        }

                                    }

                                //}
                                //else
                                //{
                                 //   minimizedItem.Visible = false;

                                 //   if (toolStripMenuItem != null)
                                 //   {
                                 //       toolStripMenuItem.Checked = false;

                                 //   }

                                //}

                            }

                        }

                    }

                }
                else
                {
                    this._navigationPaneOptionsToolStripMenuItem.Enabled = false;
                    this._addOrRemoveButtonsToolStripMenuItem.Enabled = false;
                    this._mainDivider.Visible = false;

                }

            }

        }

        private void ShowMoreButtonsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.MoreTabs();

        }

        private void ShowFewerButtonsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LessTabs();

        }

        private void MinimizedMenuItem_Click(object sender, EventArgs e)
        {
            int index;

            index = this._render.DisplayOrder.IndexOf(((ToolStripMenuItem)sender).Tag.ToString());

            this.SelectedIndex = index;

        }

        private void AddRemoveMenuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem toolStripMenuItem = sender as ToolStripMenuItem;

            toolStripMenuItem.Checked = !toolStripMenuItem.Checked;

            GradientTabPage navigationPanePage = this.FindPage(toolStripMenuItem.Text);

            if (navigationPanePage != null)
            {
                if (navigationPanePage.TabVisible != toolStripMenuItem.Checked)
                {
                    if (toolStripMenuItem.Checked)
                    {
                        this.ShowTab(navigationPanePage.Key);

                    }
                    else
                    {
                        this.HideTab(navigationPanePage.Key);

                    }

                    base.Invalidate();

                }

            }

        }

        private void NavigationPaneOptionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //NavigationPaneOptions navigationPaneOptions = new NavigationPaneOptions();
            //try
            //{
            //    navigationPaneOptions.ParentNavigationPane = this;
            //    navigationPaneOptions.Font = this.Font;
            //    navigationPaneOptions.BuildDisplayOrder(this._render.DisplayOrder);


            //    DialogResult dialogResult = navigationPaneOptions.ShowDialog();

            //    if (dialogResult == DialogResult.OK)
            //    {
            //        if (navigationPaneOptions.HasChanges)
            //        {
            //            if (this._navigationPageCollection != null && this._navigationPageCollection.Count > 0)
            //            {
            //                this._render.DisplayOrder.Clear();
            //                this._render.DisplayOrder.AddRange(navigationPaneOptions.DisplayOrder);

            //                int newIndex;

            //                if (!string.IsNullOrEmpty(this._currentDisplayOrderName))
            //                {
            //                    newIndex = this._render.DisplayOrder.IndexOf(this._currentDisplayOrderName);

            //                }
            //                else
            //                {
            //                    newIndex = this._render.DisplayOrder.IndexOf(this._navigationPageCollection[0].Name);

            //                }

            //                if (this.SelectedIndex != newIndex)
            //                {
            //                    this.SelectedIndex = newIndex;

            //                }
            //                else
            //                {
            //                    base.Invalidate();

            //                }

            //            }

            //        }

            //    }

            //}
            //catch
            //{
            //    throw;

            //}
            //finally
            //{
            //    navigationPaneOptions.Dispose();

            //}

        }

        private GradientTabPage FindPage(string text)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].Text == text)
                {
                    return this._gradientTabPageCollection[i];

                }

            }

            return null;

        }

        private GradientTabPage GetGradientTabPage(int index)
        {
            if ((index < 0) || (index >= this.GradientTabPageCount))
            {
                throw new ArgumentOutOfRangeException("index");

            }

            return this._gradientTabPageCollection[index];

        }


        private void OnPageChanged(object sender, EventArgs e)
        {
            base.Invalidate();

        }

        /// <summary>
        /// Releases the unmanaged resources used by the GradientTab and optionally releases the managed resources.
        /// </summary>
        /// <param name="disposing">true to release both managed and unmanaged resources; false to release only unmanaged resources.</param>
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        if (this._render != null) this._render.Dispose();
                        if (this._imageList != null) this._imageList = null;

                    }

                }

                this._disposed = true;

            }
            catch
            {
                throw;

            }
            finally
            {
                base.Dispose(disposing);

            }

        }

        /// <summary>
        /// Raises the ControlAdded event.
        /// </summary>
        /// <param name="e">A System.Windows.Forms.ControlEventArgs that contains the event data.</param>
        protected override void OnControlAdded(System.Windows.Forms.ControlEventArgs e)
        {
            base.OnControlAdded(e);

            if (e.Control is GradientTabPage)
            {
                GradientTabPage page = e.Control as GradientTabPage;

                if (page != null)
                {
                    Rectangle rectangle = this.GradientTabPageRectangle;

                    page.Bounds = rectangle;

                    this.SizePages(rectangle);

                    page.Focus();

                }

            }

        }

        /// <summary>
        /// Raises the Deselected event.
        /// </summary>
        /// <param name="e">A GradientTabEventArgs that contains the event data.</param>
        /// <remarks>
        /// Raising an event invokes the event handler through a delegate. For more information, see Raising an Event.
        /// The OnDeselected method also enables derived classes to handle the event without attaching a delegate. This is the preferred technique for handling the event in a derived class.
        /// Notes to Inheritors When overriding OnDeselected in a derived class, be sure to call the base class's OnDeselected method so that registered delegates receive the event. 
        /// </remarks>
        protected virtual void OnDeselected(GradientTabEventArgs e)
        {
            if (this.Deselected != null)
            {
                this.Deselected(this, e);

            }

        }

        /// <summary>
        /// Raises the Deselecting event.
        /// </summary>
        /// <param name="e">A GradientTabCancelEventArgs that contains the event data.</param>
        /// <remarks>
        /// Raising an event invokes the event handler through a delegate.
        /// The OnSelecting method also enables derived classes to handle the event without attaching a delegate. This is the preferred technique for handling the event in a derived class.
        /// Notes to Inheritors When overriding OnSelecting in a derived class, be sure to call the base class's OnDeselecting method so that registered delegates receive the event. 
        /// </remarks>
        protected virtual void OnDeselecting(GradientTabCancelEventArgs e)
        {
            if (this.Deselecting != null)
            {
                this.Deselecting(this, e);

            }

        }

        /// <summary>
        /// Raises the SystemColorsChanged event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        protected override void OnSystemColorsChanged(System.EventArgs e)
        {
            this._render.ResetColors();

            base.OnSystemColorsChanged(e);

        }

        /// <summary>
        /// Returns a String containing information about the control.
        /// </summary>
        /// <returns>A <see cref="T:System.String"></see> containing the name of the <see cref="T:System.ComponentModel.Component"></see>, if any, or null if the <see cref="T:System.ComponentModel.Component"></see> is unnamed.</returns>
        public override string ToString()
        {
            StringBuilder returnString = new StringBuilder(base.ToString());

            if (this.GradientTabPages != null)
            {
                returnString.Append(", GradientTabPages.Count: " + this.GradientTabPages.Count.ToString(CultureInfo.CurrentCulture));

                if (this.GradientTabPages.Count > 0)
                {
                    returnString.Append(", GradientTabPages[0]: " + this.GradientTabPages[0].ToString());

                }

            }

            return returnString.ToString();

        }

        /// <summary>
        /// Resets any user customization to original design.
        /// </summary>
        public void Reset()
        {
            this._render.DisplayOrder.Clear();

            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                this._render.DisplayOrder.Add(this._gradientTabPageCollection[i].Name);
                if (this._gradientTabPageCollection[i].Visible) this._gradientTabPageCollection[i].TabVisible = true;

            }

            base.Invalidate();

        }

        /// <summary>
        /// Makes the tab page with the specified index the current tab page.
        /// </summary>
        /// <remarks>Use this method to programmatically select a particular tab page in a GradientTab.</remarks>
        /// <param name="index">The index in the GradientTabPages collection of the tab page to select.</param>
        public void SelectGradientTabPage(int index)
        {
            this.SelectedIndex = index;

        }

        /// <summary>
        /// Makes the tab page with the specified key the current tab page.
        /// </summary>
        /// <remarks>Use this method to programmatically select a particular tab page in a GradientTab.</remarks>
        /// <param name="key">The key in the GradientTabPages collection of the tab page to select.</param>
        public void SelectGradientTabPage(string key)
        {
            int index = -1;

            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].Key == key)
                {
                    index = this._render.DisplayOrder.IndexOf(this._gradientTabPageCollection[i].Name);
                    break;

                }

            }

            if (index > -1) this.SelectedIndex = index;

        }

        /// <summary>
        /// Makes the tab page the current navigation page.
        /// </summary>
        /// <remarks>Use this method to programmatically select a particular tab page in a GradientTab.</remarks>
        /// <param name="page">The GradientTabPage in the GradientTabPages collection to select.</param>
        public void SelectGradientTabPage(GradientTabPage page)
        {
            if (page == null)
            {
                throw new ArgumentNullException("page");

            }

            this.SelectGradientTabPage(page.Key);

        }

        /// <summary>
        /// Disables the tab page with the specified key.
        /// </summary>
        /// <remarks>Use this method to programmatically disable a particular gradient tab page in a GradientTab.</remarks>
        /// <param name="key">The key in the GradientTabPages collection of the gradient tab page to disable.</param>
        public void DisableGradientTabPage(string key)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].Key == key)
                {
                    this._gradientTabPageCollection[i].Enabled = false;
                    break;

                }

            }

        }

        /// <summary>
        /// Enables the tab page with the specified key.
        /// </summary>
        /// <remarks>Use this method to programmatically enable a particular tab page in a GradientTab.</remarks>
        /// <param name="key">The key in the GradientTabPages collection of the tab page to enable.</param>
        public void EnableGradientTabPage(string key)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].Key == key)
                {
                    this._gradientTabPageCollection[i].Enabled = true;
                    break;

                }

            }

        }

        /// <summary>
        /// Shows the tab with the specified key.
        /// </summary>
        /// <param name="key">The key in the GradientTabPages collection of the gradient tab page to show.</param>
        public void ShowTab(string key)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].Key == key)
                {
                    if (!this._gradientTabPageCollection[i].TabVisible)
                    {
                        this._gradientTabPageCollection[i].TabVisible = true;
                        this.VisibleTabCount++;
                        this._maxVisibleTabCount++;

                        base.Invalidate();

                        this.DetermineTabMenuState();

                    }

                    break;

                }

            }

        }

        /// <summary>
        /// Hides the tab with the specified key.
        /// </summary>
        /// <param name="key">The key in the GradientTabPages collection of the gradient tab page to hide.</param>
        public void HideTab(string key)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].Key == key)
                {
                    if (this._gradientTabPageCollection[i].TabVisible && this._gradientTabPageCollection[i].Visible)
                    {
                        this._gradientTabPageCollection[i].TabVisible = false;
                        this.VisibleTabCount--;
                        this._maxVisibleTabCount--;

                        base.Invalidate();

                        this.DetermineTabMenuState();

                    }
                    break;

                }

            }

        }

        private void SetFontFamily(Font newFont)
        {
            if ((this.TabFont == null) || (this.TabFont.Name == this._initialFontName))
            {
                this.TabFont = new Font(newFont.FontFamily, this.TabFont.Size, this.TabFont.Style);

            }

            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].TabFont.Name == this._initialFontName)
                {
                    this._gradientTabPageCollection[i].TabFont = new Font(newFont.FontFamily, this._gradientTabPageCollection[i].TabFont.Size, this._gradientTabPageCollection[i].TabFont.Style);

                }

            }

        }

        /// <summary>
        /// Raises the RightToLeftChanged event. 
        /// </summary>
        /// <param name="e">An System.EventArgs that contains the event data.</param>
        protected override void OnRightToLeftChanged(System.EventArgs e)
        {
            base.OnRightToLeftChanged(e);

            if (this.RightToLeft == RightToLeft.Yes)
            {
                this._render.RightToLeft = true;

            }
            else
            {
                this._render.RightToLeft = false;

            }

        }

        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        protected override void OnFontChanged(System.EventArgs e)
        {
            this.SetFontFamily(this.Font);

            this._contextMenuStrip.Font = this.Font;

            this._initialFontName = this.Font.Name;

            base.OnFontChanged(e);

            this.SizePages();

        }

        private void SetDefaultTabTextAlign(ContentAlignment oldAlignment, ContentAlignment newAlignment)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].TextAlign == oldAlignment)
                {
                    this._gradientTabPageCollection[i].TextAlign = newAlignment;

                }

            }

        }

        private void SetDefaultTabImageAlign(ContentAlignment oldAlignment, ContentAlignment newAlignment)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].ImageAlign == oldAlignment)
                {
                    this._gradientTabPageCollection[i].ImageAlign = newAlignment;

                }

            }

        }

        private void SetDefaultTabForeColor(Color oldColor, Color newColor)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].TabForeColor == oldColor)
                {
                    this._gradientTabPageCollection[i].TabForeColor = newColor;

                }

            }

        }

        private void SetDefaultTabGradientHighColor(Color oldColor, Color newColor)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].GradientHighColor == oldColor)
                {
                    this._gradientTabPageCollection[i].GradientHighColor = newColor;

                }

            }

        }

        private void SetDefaultTabGradientLowColor(Color oldColor, Color newColor)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].GradientLowColor == oldColor)
                {
                    this._gradientTabPageCollection[i].GradientLowColor = newColor;

                }

            }

        }

        private void SetDefaultTabActiveGradientHighColor(Color oldColor, Color newColor)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].ActiveGradientHighColor == oldColor)
                {
                    this._gradientTabPageCollection[i].ActiveGradientHighColor = newColor;

                }

            }

        }

        private void SetDefaultTabActiveGradientLowColor(Color oldColor, Color newColor)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].ActiveGradientLowColor == oldColor)
                {
                    this._gradientTabPageCollection[i].ActiveGradientLowColor = newColor;

                }

            }

        }

        private void SetDefaultTabHighlightGradientHighColor(Color oldColor, Color newColor)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].HighlightGradientHighColor == oldColor)
                {
                    this._gradientTabPageCollection[i].HighlightGradientHighColor = newColor;

                }

            }

        }

        private void SetDefaultTabHighlightGradientLowColor(Color oldColor, Color newColor)
        {
            for (int i = 0; i < this._gradientTabPageCollection.Count; i++)
            {
                if (this._gradientTabPageCollection[i].HighlightGradientLowColor == oldColor)
                {
                    this._gradientTabPageCollection[i].HighlightGradientLowColor = newColor;

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="factor"></param>
        /// <param name="specified"></param>
        protected override void ScaleControl(System.Drawing.SizeF factor, System.Windows.Forms.BoundsSpecified specified)
        {
            base.ScaleControl(factor, specified);

            this.SizePages();

        }

        /// <summary>
        /// 
        /// </summary>
        protected override void InitLayout()
        {
            base.InitLayout();

            this._initialFontName = this.Font.Name;

        }

    }

}
