﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Default colors and font properties values for the NavigationPane control
    /// </summary>
	/// <remarks>This class was added as a patch courtesy of Loïc Gaudouen to offer
	/// more aesthetically appropriate default colors for the NavigationPane.</remarks>
    public static class NavigationPaneDefaults
    {
        public static Color BorderColor = Color.FromArgb(0, 45, 150);

        /// <summary>
        /// Default colors and font properties values for the NavigationPaneButton control
        /// </summary>
        public static class Button
        {
            public static Color BorderColor = NavigationPaneDefaults.BorderColor;

            public static Color GradientHighColor = Color.FromArgb(203, 225, 252);
            public static Color GradientLowColor = Color.FromArgb(125, 165, 224);
            public static Color HighlightGradientHighColor = Color.FromArgb(255, 255, 220);
            public static Color HighlightGradientLowColor = Color.FromArgb(247, 192, 91);
            public static Color ActiveGradientHighColor = Color.FromArgb(251, 230, 148);
            public static Color ActiveGradientLowColor = Color.FromArgb(238, 149, 29);

            public static Font Font = new Font("Arial", 8.25f, FontStyle.Bold);
        }

        /// <summary>
        /// Default colors properties values for the NavigationPaneButton control
        /// </summary>
        public static class Footer
        {
            public static Color BorderColor = NavigationPaneDefaults.BorderColor;

            public static Color GradientHighColor = NavigationPaneDefaults.Button.GradientHighColor;
            public static Color GradientLowColor = NavigationPaneDefaults.Button.GradientLowColor;
            public static Color HighlightGradientHighColor = NavigationPaneDefaults.Button.HighlightGradientHighColor;
            public static Color HighlightGradientLowColor = NavigationPaneDefaults.Button.HighlightGradientLowColor;
        }

        /// <summary>
        /// Default colors properties values for the NavigationPaneSplitbar control
        /// </summary>
        public static class Splitbar
        {
            public static Color BorderColor = NavigationPaneDefaults.BorderColor;

            public static Color GradientHighColor = Color.FromArgb(89, 135, 214);
            public static Color GradientLowColor = Color.FromArgb(14, 66, 156);
        }

        /// <summary>
        /// Default colors and font properties values for the NavigationPaneCaption control
        /// </summary>
        public static class Caption
        {
            public static Color BorderColor = NavigationPaneDefaults.BorderColor;

            public static Color GradientHighColor = Color.FromArgb(89, 135, 214);
            public static Color GradientLowColor = Color.FromArgb(3, 55, 147);

            public static Font Font = new Font("Arial", 12f, FontStyle.Bold);
        }
    }
}
