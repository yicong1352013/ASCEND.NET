/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Defines values representing NavigationPane events
    /// </summary>
    public enum NavigationPaneAction
    {
        /// <summary>
        /// Represents the Selecting event.
        /// </summary>
        Selecting,
        /// <summary>
        /// Represents the Selected event
        /// </summary>
        Selected,
        /// <summary>
        /// Represents the Deselecting event
        /// </summary>
        Deselecting,
        /// <summary>
        /// Represents the Deselected event
        /// </summary>
        Deselected

    }

    /// <summary>
    /// Provides data for the Selecting and Deselecting events of a NavigationPane control. 
    /// </summary>
    public class NavigationPaneCancelEventArgs : CancelEventArgs
    {
        private NavigationPaneAction _navigationPaneAction;
        private NavigationPanePage _navigationPanePage;
        private int _navigationPanePageIndex;
        private string _navigationPanePageKey;

        /// <summary>
        /// Gets a value indicating which event is occurring. 
        /// </summary>
        /// <value>
        /// One of the NavigationPaneAction values.
        /// </value>
        public NavigationPaneAction Action
        {
            get
            {
                return this._navigationPaneAction;

            }

        }

        /// <summary>
        /// Gets the zero-based index of the NavigationPanePage in the NavigationPanePages collection.
        /// </summary>
        /// <value>
        /// The zero-based index of the NavigationPanePage in the NavigationPanePages collection.
        /// </value>
        public int NavigationPanePageIndex
        {
            get
            {
                return this._navigationPanePageIndex;

            }

        }

        /// <summary>
        /// Gets the key of the NavigationPanePage in the NavigationPanePages collection.
        /// </summary>
        /// <value>
        /// The key of the NavigationPanePage in the NavigationPanePages collection.
        /// </value>
        public string NavigationPanePageKey
        {
            get 
            { 
                return this._navigationPanePageKey;
            
            }

        }

        /// <summary>
        /// Gets the NavigationPanePage the event is occurring for.
        /// </summary>
        /// <value>
        /// The NavigationPanePage the event is occurring for.
        /// </value>
        public NavigationPanePage NavigationPanePage
        {
            get 
            { 
                return this._navigationPanePage;
            
            }

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneCancelEventArgs class.
        /// </summary>
        /// <param name="navigationPanePage">The NavigationPanePage the event is occurring for.</param>
        /// <param name="navigationPanePageIndex">The zero-based index of NavigationPanePage in the NavigationPanePages collection.</param>
        /// <param name="navigationPanePageKey">The key of the NavigationPanePage in the NavigationPanePages collection.</param>
        /// <param name="cancel">true to cancel the NavigationPane change by default; otherwise, false.</param>
        /// <param name="action">One of the NavigationPaneAction values.</param>
        public NavigationPaneCancelEventArgs(NavigationPanePage navigationPanePage, int navigationPanePageIndex, string navigationPanePageKey, bool cancel, NavigationPaneAction action) : base(cancel)
        {
            this._navigationPanePage = navigationPanePage;
            this._navigationPanePageIndex = navigationPanePageIndex;
            this._navigationPanePageKey = navigationPanePageKey;
            this._navigationPaneAction = action;
   
        }

    }

}
