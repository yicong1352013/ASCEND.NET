/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Defines values representing GradientTab events
    /// </summary>
    public enum GradientTabAction
    {
        /// <summary>
        /// Represents the Selecting event.
        /// </summary>
        Selecting,
        /// <summary>
        /// Represents the Selected event
        /// </summary>
        Selected,
        /// <summary>
        /// Represents the Deselecting event
        /// </summary>
        Deselecting,
        /// <summary>
        /// Represents the Deselected event
        /// </summary>
        Deselected

    }

    /// <summary>
    /// Provides data for the Selecting and Deselecting events of a GradientTab control. 
    /// </summary>
    public class GradientTabCancelEventArgs : CancelEventArgs
    {
        private GradientTabAction _gradientTabAction;
        private GradientTabPage _gradientTabPage;
        private int _gradientTabPageIndex;
        private string _gradientTabPageKey;

        /// <summary>
        /// Gets a value indicating which event is occurring. 
        /// </summary>
        /// <value>
        /// One of the GradientTabAction values.
        /// </value>
        public GradientTabAction Action
        {
            get
            {
                return this._gradientTabAction;

            }

        }

        /// <summary>
        /// Gets the zero-based index of the GradientTabPage in the GradientTabPages collection.
        /// </summary>
        /// <value>
        /// The zero-based index of the GradientTabPage in the GradientTabPages collection.
        /// </value>
        public int GradientTabPageIndex
        {
            get
            {
                return this._gradientTabPageIndex;

            }

        }

        /// <summary>
        /// Gets the key of the GradientTabPage in the GradientTabPages collection.
        /// </summary>
        /// <value>
        /// The key of the GradientTabPage in the GradientTabPages collection.
        /// </value>
        public string GradientTabPageKey
        {
            get 
            { 
                return this._gradientTabPageKey;
            
            }

        }

        /// <summary>
        /// Gets the GradientTabPage the event is occurring for.
        /// </summary>
        /// <value>
        /// The GradientTabPage the event is occurring for.
        /// </value>
        public GradientTabPage GradientTabPage
        {
            get 
            { 
                return this._gradientTabPage;
            
            }

        }

        /// <summary>
        /// Initializes a new instance of the GradientTabCancelEventArgs class.
        /// </summary>
        /// <param name="gradientTabPage">The GradientTabPage the event is occurring for.</param>
        /// <param name="gradientTabPageIndex">The zero-based index of GradientTabPage in the GradientTabPages collection.</param>
        /// <param name="gradientTabPageKey">The key of the GradientTabPage in the GradientTabPages collection.</param>
        /// <param name="cancel">true to cancel the GradientTabPage change by default; otherwise, false.</param>
        /// <param name="action">One of the GradientTabAction values.</param>
        public GradientTabCancelEventArgs(GradientTabPage gradientTabPage, int gradientTabPageIndex, string gradientTabPageKey, bool cancel, GradientTabAction action) : base(cancel)
        {
            this._gradientTabPage = gradientTabPage;
            this._gradientTabPageIndex = gradientTabPageIndex;
            this._gradientTabPageKey = gradientTabPageKey;
            this._gradientTabAction = action;
   
        }

    }

}
