/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Native API method supporting class.
    /// </summary>
    internal static class NativeMethods
    {
        /// <summary>
        /// A null handle reference.
        /// </summary>
        public static HandleRef NullHandleRef;
        
        static NativeMethods()
        {
            NativeMethods.NullHandleRef = new HandleRef(null, IntPtr.Zero);

        }

        /// <summary>
        /// Returns the control that currently has focus
        /// </summary>
        /// <returns>The control that has focus; null if none or not a managed control</returns>
        public static Control GetFocusedControl()
        {
            Control focusedControl = null;

            IntPtr focusedHandle = UnsafeNativeMethods.GetFocus();

            if (focusedHandle != IntPtr.Zero)
            {
                focusedControl = Control.FromHandle(focusedHandle);

            }

            return focusedControl;

        } 
 

        /// <summary>
        /// Defines the style, color, and pattern of a physical brush.
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public class LOGBRUSH
        {
            public int lbStyle;
            public int lbColor;
            public IntPtr lbHatch;

            public LOGBRUSH()
            {
            }

        }

    }

}
