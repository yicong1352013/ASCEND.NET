/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Specifies how tabs in a gradient tab control are sized. 
    /// </summary>
    /// <remarks>
    /// This enumeration is used by members such as GradientTabControl.SizeMode.
    /// </remarks>
    public enum GradientTabSizeMode
    {
        /// <summary>
        /// The width of each tab is sized to accommodate what is displayed on the tab, and the size of tabs in a row are not adjusted to fill the entire width of the container control. 
        /// </summary>
        Normal,
        /// <summary>
        /// The width of each tab is sized so that each row of tabs fills the entire width of the container control. This is only applicable to tab controls with more than one row.
        /// </summary>
        FillToRight,
        /// <summary>
        /// All tabs in a control are the same width. 
        /// </summary>
        Fixed

    }

}
