/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// A class that inherits from TreeNode that lets you specify a ComboBox to be shown
    /// at the TreeNode's position
    /// </summary>
    [Serializable]
    public class DropDownTreeNode : TreeNode
    {
        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="T:DropDownTreeNode"/> class.
        /// </summary>
        public DropDownTreeNode()
            : base()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:DropDownTreeNode"/> class.
        /// </summary>
        /// <param name="text">The text to display.</param>
        public DropDownTreeNode(string text)
            : base(text)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:DropDownTreeNode"/> class.
        /// </summary>
        /// <param name="text">The text to display.</param>
        /// <param name="children">The children <see cref="T:System.Windows.Forms.TreeNodes" />.</param>
        public DropDownTreeNode(string text, TreeNode[] children)
            : base(text, children)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:DropDownTreeNode"/> class.
        /// </summary>
        /// <param name="serializationInfo">A <see cref="T:System.Runtime.Serialization.SerializationInfo"></see> containing the data to deserialize the class.</param>
        /// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext"></see> containing the source and destination of the serialized stream.</param>
        public DropDownTreeNode(SerializationInfo serializationInfo, StreamingContext context)
            : base(serializationInfo, context)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:DropDownTreeNode"/> class.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <param name="imageIndex">Index of the image.</param>
        /// <param name="selectedImageIndex">Index of the selected image.</param>
        public DropDownTreeNode(string text, int imageIndex, int selectedImageIndex)
            : base(text, imageIndex, selectedImageIndex)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:DropDownTreeNode"/> class.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <param name="imageIndex">Index of the image.</param>
        /// <param name="selectedImageIndex">Index of the selected image.</param>
        /// <param name="children">The children.</param>
        public DropDownTreeNode(string text, int imageIndex, int selectedImageIndex, TreeNode[] children)
            : base(text, imageIndex, selectedImageIndex, children)
        {
        }
        #endregion


        #region Property - ComboBox
        private ComboBox _comboBox = new ComboBox();
        /// <summary>
        /// Gets or sets the ComboBox.  Lets you access all of the properties of the internal ComboBox.
        /// </summary>
        /// <example>
        /// For example,
        /// <code>
        /// DropDownTreeNode node1 = new DropDownTreeNode("Some text");
        /// node1.ComboBox.Items.Add("Some text");
        /// node1.ComboBox.Items.Add("Some more text");
        /// </code>
        /// </example>
        /// <remarks>
        /// To maintain the correct internal state of the ComboBox, the DropDownStyle property of the ComboBox
        /// is set to ComboBoxStyle.DropDownList during both the get and set operations.
        /// </remarks>
        /// <value>The combo box.</value>
        public ComboBox ComboBox
        {
            get
            {
                this._comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
                return this._comboBox;
            }
            set
            {
                this._comboBox = value;
                this._comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            }
        }
        #endregion
    }
}
