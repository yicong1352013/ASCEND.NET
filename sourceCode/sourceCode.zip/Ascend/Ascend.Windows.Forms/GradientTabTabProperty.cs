/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.ComponentModel;
using Ascend.Resources;
using System.Security;
using System.Security.Permissions;
using System.Drawing.Design;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// User interface (UI) for representing and editing the values of objects of the supported data types in a tab.
    /// </summary>
    [TypeConverterAttribute(typeof(GradientTabTabConverter))]
    [System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name = "FullTrust")]
    public class GradientTabTabProperty : UITypeEditor
    {
        private GradientTab _gradientTab;

        /// <summary>
        /// Gets or sets the parent GradientTab.
        /// </summary>
        [Browsable(false)]
        public GradientTab GradientTab
        {
            get
            {
                return this._gradientTab;

            }

            set
            {
                this._gradientTab = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the tab when it is active.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the tab when it is active.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ActiveGradientHighColorDescription"), ResourceDisplayName("DisplayNameActiveGradientHighColor"), DefaultValueAttribute(typeof(Color), "255, 225, 155")]
        public Color ActiveGradientHighColor
        {
            get
            {
                return this._gradientTab.TabActiveGradientHighColor;

            }

            set
            {
                this._gradientTab.TabActiveGradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the tab when it is active.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the tab when it is active.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ActiveGradientLowColorDescription"), ResourceDisplayName("DisplayNameActiveGradientLowColor"), DefaultValueAttribute(typeof(Color), "255, 165, 78")]
        public Color ActiveGradientLowColor
        {
            get
            {
                return this._gradientTab.TabActiveGradientLowColor;

            }

            set
            {
                this._gradientTab.TabActiveGradientLowColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the border color of the tab.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("BorderColorDescription"), ResourceDisplayName("DisplayNameBorderColor"), DefaultValueAttribute(typeof(Color), "ControlDarkDark")]
        public Color BorderColor
        {
            get
            {
                return this._gradientTab.TabBorderColor;

            }

            set
            {
                this._gradientTab.TabBorderColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the font associated with the tab.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), Localizable(true), ResourceDescriptionAttribute("TabFontDescription"), ResourceDisplayName("DisplayNameTabFont")]
        public Font Font
        {
            get
            {
                return this._gradientTab.TabFont;

            }

            set
            {
                this._gradientTab.TabFont = value;

            }

        }

        /// <summary>
        /// Determines if the Font property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeFont()
        {
            if ((this._gradientTab.TabFont.Name != this._gradientTab.Font.Name) || (this._gradientTab.TabFont.Size != 8.25f) || (this._gradientTab.TabFont.Bold != true))
            {
                return true;

            }
            else
            {
                return false;

            }

        }

        /// <summary>
        /// Gets or sets the tab forecolor.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ForeColorDescription"), ResourceDisplayName("DisplayNameForeColor"), DefaultValueAttribute(typeof(Color), "ControlText")]
        public Color ForeColor
        {
            get
            {
                return this._gradientTab.TabForeColor;

            }

            set
            {
                this._gradientTab.TabForeColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the height of the tab.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TabHeightDescription"), ResourceDisplayName("DisplayNameTabHeight"), DefaultValueAttribute(18)]
        public int Height
        {
            get
            {
                return this._gradientTab.TabHeight;

            }

            set
            {
                this._gradientTab.TabHeight = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the tab when it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the tab when it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightGradientHighColorDescription"), ResourceDisplayName("DisplayNameHighlightGradientHighColor"), DefaultValueAttribute(typeof(Color), "White")]
        public Color HighlightGradientHighColor
        {
            get
            {
                return this._gradientTab.TabHighlightGradientHighColor;

            }

            set
            {
                this._gradientTab.TabHighlightGradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the tab when it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the tab when it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightGradientLowColorDescription"), ResourceDisplayName("DisplayNameHighlightGradientLowColor"), DefaultValueAttribute(typeof(Color), "255, 165, 78")]
        public Color HighlightGradientLowColor
        {
            get
            {
                return this._gradientTab.TabHighlightGradientLowColor;

            }

            set
            {
                this._gradientTab.TabHighlightGradientLowColor = value;

            }

        }

        /// <summary>
        /// The ContentAlignment associated with the tab image.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.ContentAlignment . The ContentAlignment associated with the tab image.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ImageAlignmentDescription"), ResourceDisplayName("DisplayNameImageAlign"), DefaultValueAttribute(ContentAlignment.MiddleLeft)]
        public ContentAlignment ImageAlign
        {
            get
            {
                return this._gradientTab.TabImageAlign;

            }

            set
            {
                this._gradientTab.TabImageAlign = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientHighColorDescription"), ResourceDisplayName("DisplayNameGradientHighColor"), DefaultValueAttribute(typeof(Color), "ButtonHighlight")]
        public Color GradientHighColor
        {
            get
            {
                return this._gradientTab.TabGradientHighColor;

            }

            set
            {
                this._gradientTab.TabGradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientLowColorDescription"), ResourceDisplayName("DisplayNameGradientLowColor"), DefaultValueAttribute(typeof(Color), "GradientActiveCaption")]
        public Color GradientLowColor
        {
            get
            {
                return this._gradientTab.TabGradientLowColor;

            }

            set
            {
                this._gradientTab.TabGradientLowColor = value;

            }

        }

        /// <summary>
        /// The ContentAlignment associated with the tab text.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.ContentAlignment . The ContentAlignment associated with the tab text.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TextAlignmentDescription"), ResourceDisplayName("DisplayNameTextAlign"), DefaultValueAttribute(ContentAlignment.MiddleLeft)]
        public ContentAlignment TextAlign
        {
            get
            {
                return this._gradientTab.TabTextAlign;

            }

            set
            {
                this._gradientTab.TabTextAlign = value;

            }

        }

        /// <summary>
        /// Gets or sets the width of the tab.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TabWidthDescription"), ResourceDisplayName("DisplayNameWidth"), DefaultValueAttribute(58)]
        public int Width
        {
            get
            {
                return this._gradientTab.TabWidth;

            }

            set
            {
                this._gradientTab.TabWidth = value;

            }

        }

        /// <summary>
        /// Gets a value indicating whether drop-down editors should be resizable by the user.
        /// </summary>
        [Browsable(false)]
        public override bool IsDropDownResizable
        {
            get
            {
                return false;

            }

        }

        /// <summary>
        /// Initializes a new instance of the GradientTabTabProperty class.
        /// </summary>
        /// <param name="gradientTab">The GradientTab control to add the property values to.</param>
        public GradientTabTabProperty(GradientTab gradientTab)
        {
            this._gradientTab = gradientTab;

        }

        /// <summary>
        /// Initializes a new instance of the GradientTabTabProperty class.
        /// </summary>
        /// <param name="gradientTab">The parent gradient tab control</param>
        /// <param name="height">The height of the tab.</param>
        /// <param name="width">The width of the tab.</param>
        /// <param name="gradientHighColor">The gradient high color of the tab.</param>
        /// <param name="gradientLowColor">The gradient low color of the tab.</param>
        /// <param name="borderColor">The bordercolor of the tab.</param>
        /// <param name="highlightGradientHighColor">The gradient high (lighter) color for the tab when it is moused over.</param>
        /// <param name="highlightGradientLowColor">The gradient low (darker) color for the tab when it is moused over.</param>
        /// <param name="activeGradientHighColor">The gradient high (lighter) color for the tab when it is active.</param>
        /// <param name="activeGradientLowColor">The gradient low (darker) color for the tab when it is active.</param>
        /// <param name="foreColor">The tab forecolor.</param>
        /// <param name="textAlignment">The alignment of the text of the tab.</param>
        public GradientTabTabProperty(GradientTab gradientTab, int height, int width, Color gradientHighColor, Color gradientLowColor, Color borderColor, Color highlightGradientHighColor, Color highlightGradientLowColor, Color activeGradientHighColor, Color activeGradientLowColor, Color foreColor, ContentAlignment textAlignment)
        {
            this._gradientTab = gradientTab;
            this.Height = height;
            this.Width = width;
            this.GradientHighColor = gradientHighColor;
            this.GradientLowColor = gradientLowColor;
            this.BorderColor = borderColor;
            this.HighlightGradientHighColor = highlightGradientHighColor;
            this.HighlightGradientLowColor = highlightGradientLowColor;
            this.ActiveGradientHighColor = activeGradientHighColor;
            this.ActiveGradientLowColor = activeGradientLowColor;
            this.ForeColor = foreColor;
            this.TextAlign = textAlignment;

        }

    }

}
