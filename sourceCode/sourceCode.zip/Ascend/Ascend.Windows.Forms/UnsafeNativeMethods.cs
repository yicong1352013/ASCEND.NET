/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Unsafe native method API calls.
    /// </summary>
    internal class UnsafeNativeMethods
    {
        /// <summary>
        /// User32.dll SetCapture method.
        /// </summary>
        /// <param name="hwnd"></param>
        /// <returns></returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern IntPtr SetCapture(HandleRef hwnd);

        /// <summary>
        /// User32.dll SetCapture method.
        /// </summary>
        /// <param name="hwnd"></param>
        /// <returns></returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern int SetFocus(HandleRef hwnd);

        /// <summary>
        /// User32.dll GetCapture method.
        /// </summary>
        /// <returns></returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern IntPtr GetCapture();

        /// <summary>
        /// User32.dll GetDCEx method. 
        /// Retrieves a handle to a display device context (DC) for the client area of a specified window.
        /// </summary>
        /// <param name="hWnd">Handle to the window whose DC is to be retrieved. If this value is NULL, GetDCEx retrieves the DC for the entire screen.</param>
        /// <param name="hrgnClip">Specifies a clipping region that may be combined with the visible region of the DC.</param>
        /// <param name="flags">Specifies how the DC is created.</param>
        /// <returns></returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern IntPtr GetDCEx(HandleRef hWnd, HandleRef hrgnClip, int flags);

        /// <summary>
        /// This function retrieves the handle to the keyboard focus window associated with the thread that called the function.
        /// </summary>
        /// <returns></returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern IntPtr GetFocus();

        /// <summary>
        /// User32.dll ReleaseDC method.
        /// </summary>
        /// <param name="hWnd"></param>
        /// <param name="hDC"></param>
        /// <returns></returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern int ReleaseDC(HandleRef hWnd, HandleRef hDC);

    }

}
