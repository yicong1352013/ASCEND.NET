/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.ComponentModel;
using Ascend.Resources;
using System.Security;
using System.Security.Permissions;
using System.Drawing.Design;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// User interface (UI) for representing and editing the values of objects of the supported data types in a button.
    /// </summary>
    [TypeConverterAttribute(typeof(NavigationPaneButtonConverter))]
    [System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name = "FullTrust")]
    public class NavigationPaneButtonProperty : UITypeEditor
    {
        private NavigationPane _navigationPane;

        /// <summary>
        /// Gets or sets the parent NavigationPane.
        /// </summary>
        [Browsable(false)]
        public NavigationPane NavigationPane
        {
            get
            {
                return this._navigationPane;

            }

            set
            {
                this._navigationPane = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the button when it is active.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the button when it is active.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ActiveGradientHighColorDescription"), ResourceDisplayName("DisplayNameActiveGradientHighColor"), DefaultValueAttribute(typeof(Color), "255, 225, 155")]
        public Color ActiveGradientHighColor
        {
            get
            {
                return this._navigationPane.ButtonActiveGradientHighColor;

            }

            set
            {
                this._navigationPane.ButtonActiveGradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the button when it is active.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the button when it is active.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ActiveGradientLowColorDescription"), ResourceDisplayName("DisplayNameActiveGradientLowColor"), DefaultValueAttribute(typeof(Color), "255, 165, 78")]
        public Color ActiveGradientLowColor
        {
            get
            {
                return this._navigationPane.ButtonActiveGradientLowColor;

            }

            set
            {
                this._navigationPane.ButtonActiveGradientLowColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the border color of the button.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("BorderColorDescription"), ResourceDisplayName("DisplayNameBorderColor"), DefaultValueAttribute(typeof(Color), "MenuHighlight")]
        public Color BorderColor
        {
            get
            {
                return this._navigationPane.ButtonBorderColor;

            }

            set
            {
                this._navigationPane.ButtonBorderColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the font associated with the caption.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), Localizable(true), ResourceDescriptionAttribute("ButtonFontDescription"), ResourceDisplayName("DisplayNameButtonFont")]
        public Font Font
        {
            get
            {
                return this._navigationPane.ButtonFont;

            }

            set
            {
                this._navigationPane.ButtonFont = value;

            }

        }

        /// <summary>
        /// Determines if the Font property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeFont()
        {
            if ((this._navigationPane.ButtonFont.Name != this._navigationPane.Font.Name) || (this._navigationPane.ButtonFont.Size != 8.25f) || (this._navigationPane.ButtonFont.Bold != true))
            {
                return true;

            }
            else
            {
                return false;

            }

        }

        /// <summary>
        /// Gets or sets the button forecolor.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ForeColorDescription"), ResourceDisplayName("DisplayNameForeColor"), DefaultValueAttribute(typeof(Color), "ControlText")]
        public Color ForeColor
        {
            get
            {
                return this._navigationPane.ButtonForeColor;

            }

            set
            {
                this._navigationPane.ButtonForeColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the height of the button.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ButtonHeightDescription"), ResourceDisplayName("DisplayNameButtonHeight"), DefaultValueAttribute(32)]
        public int Height
        {
            get
            {
                return this._navigationPane.ButtonHeight;

            }

            set
            {
                this._navigationPane.ButtonHeight = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the button when it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the button when it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightGradientHighColorDescription"), ResourceDisplayName("DisplayNameHighlightGradientHighColor"), DefaultValueAttribute(typeof(Color), "White")]
        public Color HighlightGradientHighColor
        {
            get
            {
                return this._navigationPane.ButtonHighlightGradientHighColor;

            }

            set
            {
                this._navigationPane.ButtonHighlightGradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the button when it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the button when it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightGradientLowColorDescription"), ResourceDisplayName("DisplayNameHighlightGradientLowColor"), DefaultValueAttribute(typeof(Color), "255, 165, 78")]
        public Color HighlightGradientLowColor
        {
            get
            {
                return this._navigationPane.ButtonHighlightGradientLowColor;

            }

            set
            {
                this._navigationPane.ButtonHighlightGradientLowColor = value;

            }

        }

        /// <summary>
        /// The ContentAlignment associated with the button image.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.ContentAlignment . The ContentAlignment associated with the button image.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ImageAlignmentDescription"), ResourceDisplayName("DisplayNameImageAlign"), DefaultValueAttribute(ContentAlignment.MiddleLeft)]
        public ContentAlignment ImageAlign
        {
            get
            {
                return this._navigationPane.ButtonImageAlign;

            }

            set
            {
                this._navigationPane.ButtonImageAlign = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientHighColorDescription"), ResourceDisplayName("DisplayNameGradientHighColor"), DefaultValueAttribute(typeof(Color), "ButtonHighlight")]
        public Color GradientHighColor
        {
            get
            {
                return this._navigationPane.ButtonGradientHighColor;

            }

            set
            {
                this._navigationPane.ButtonGradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientLowColorDescription"), ResourceDisplayName("DisplayNameGradientLowColor"), DefaultValueAttribute(typeof(Color), "GradientActiveCaption")]
        public Color GradientLowColor
        {
            get
            {
                return this._navigationPane.ButtonGradientLowColor;

            }

            set
            {
                this._navigationPane.ButtonGradientLowColor = value;

            }

        }

        /// <summary>
        /// The ContentAlignment associated with the button text.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.ContentAlignment . The ContentAlignment associated with the button text.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TextAlignmentDescription"), ResourceDisplayName("DisplayNameTextAlign"), DefaultValueAttribute(ContentAlignment.MiddleLeft)]
        public ContentAlignment TextAlign
        {
            get
            {
                return this._navigationPane.ButtonTextAlign;

            }

            set
            {
                this._navigationPane.ButtonTextAlign = value;

            }

        }

        /// <summary>
        /// Gets a value indicating whether drop-down editors should be resizable by the user.
        /// </summary>
        [Browsable(false)]
        public override bool IsDropDownResizable
        {
            get
            {
                return false;

            }

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneButtonProperty class.
        /// </summary>
        /// <param name="navigationPane">The NavigationPane control to add the property values to.</param>
        public NavigationPaneButtonProperty(NavigationPane navigationPane)
        {
            this._navigationPane = navigationPane;

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneButtonProperty class.
        /// </summary>
        /// <param name="navigationPane">The NavigationPane control to add the property values to.</param>
        /// <param name="height">The height of the button.</param>
        /// <param name="gradientHighColor">The gradient high color of the button.</param>
        /// <param name="gradientLowColor">The gradient low color of the button.</param>
        /// <param name="borderColor">The bordercolor of the button.</param>
        /// <param name="highlightGradientHighColor">The gradient high (lighter) color for the button when it is moused over.</param>
        /// <param name="highlightGradientLowColor">The gradient low (darker) color for the button when it is moused over.</param>
        /// <param name="activeGradientHighColor">The gradient high (lighter) color for the button when it is active.</param>
        /// <param name="activeGradientLowColor">The gradient low (darker) color for the button when it is active.</param>
        /// <param name="foreColor">The button forecolor.</param>
        /// <param name="textAlignment">The alignment of the text of the button.</param>
        public NavigationPaneButtonProperty(NavigationPane navigationPane, int height, Color gradientHighColor, Color gradientLowColor, Color borderColor, Color highlightGradientHighColor, Color highlightGradientLowColor, Color activeGradientHighColor, Color activeGradientLowColor, Color foreColor, ContentAlignment textAlignment)
        {
            this._navigationPane = navigationPane;
            this.Height = height;
            this.GradientHighColor = gradientHighColor;
            this.GradientLowColor = gradientLowColor;
            this.BorderColor = borderColor;
            this.HighlightGradientHighColor = highlightGradientHighColor;
            this.HighlightGradientLowColor = highlightGradientLowColor;
            this.ActiveGradientHighColor = activeGradientHighColor;
            this.ActiveGradientLowColor = activeGradientLowColor;
            this.ForeColor = foreColor;
            this.TextAlign = textAlignment;

        }

    }

}
