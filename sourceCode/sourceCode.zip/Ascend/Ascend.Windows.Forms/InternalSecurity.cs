using System;
using System.Collections.Generic;
using System.Text;
using System.Security;
using System.Security.Permissions;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Internal control security class.
    /// </summary>
    internal static class InternalSecurity
    {
        private static CodeAccessPermission unmanagedCode;

        /// <summary>
        /// Code access permission property for unmanaged code.
        /// </summary>
        /// <value>CodeAccessPermission</value>
        public static CodeAccessPermission UnmanagedCode
        {
            get
            {
                if (InternalSecurity.unmanagedCode == null)
                {
                    InternalSecurity.unmanagedCode = new SecurityPermission(SecurityPermissionFlag.UnmanagedCode);

                }

                return InternalSecurity.unmanagedCode;

            }

        }

    }

}
