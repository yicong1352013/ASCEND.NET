using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Collection of native Windows API methods encapsulated in managed code.
    /// </summary>
    internal class NativeMethods
    {
        /// <summary>
        /// A null handle reference.
        /// </summary>
        public static HandleRef NullHandleRef;

        static NativeMethods()
        {
            NativeMethods.NullHandleRef = new HandleRef(null, IntPtr.Zero);

        }

        
        

        /// <summary>
        /// Defines the style, color, and pattern of a physical brush.
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public class LOGBRUSH
        {
            public int lbStyle;
            public int lbColor;
            public IntPtr lbHatch;

            public LOGBRUSH()
            {
            }

        }



    }

}
