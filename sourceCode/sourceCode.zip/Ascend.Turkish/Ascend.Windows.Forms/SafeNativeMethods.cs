/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascend_adm@hotmail.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Safe native API method calls.
    /// </summary>
    internal class SafeNativeMethods
    {
        /// <summary>
        /// Gdi32.dll CreateBitmap method. Creates a bitmap with the specified width, height, and color format (color planes and bits-per-pixel).
        /// </summary>
        /// <param name="nWidth"></param>
        /// <param name="nHeight"></param>
        /// <param name="nPlanes"></param>
        /// <param name="nBitsPerPixel"></param>
        /// <param name="lpvBits"></param>
        /// <returns></returns>
        [DllImport("gdi32.dll", CharSet = CharSet.Auto, SetLastError = true, ExactSpelling = true)]
        public static extern IntPtr CreateBitmap(int nWidth, int nHeight, int nPlanes, int nBitsPerPixel, short[] lpvBits);

        /// <summary>
        /// Gdi32.dll CreateBrushIndirect method. Creates a logical brush that has the specified style, color, and pattern.
        /// </summary>
        /// <param name="lb">Pointer to a LOGBRUSH structure that contains information about the brush.</param>
        /// <returns>A logical brush</returns>
        [DllImport("gdi32.dll", CharSet = CharSet.Auto, SetLastError = true, ExactSpelling = true)]
        public static extern IntPtr CreateBrushIndirect(NativeMethods.LOGBRUSH lb);

        /// <summary>
        /// Gdi32.dll DeleteObject method.
        /// </summary>
        /// <param name="hObject"></param>
        /// <returns></returns>
        [DllImport("gdi32.dll", CharSet = CharSet.Auto, SetLastError = true, ExactSpelling = true)]
        public static extern bool DeleteObject(HandleRef hObject);

        /// <summary>
        /// Gdi32.dll PatBlt method.
        /// </summary>
        /// <param name="hdc"></param>
        /// <param name="left"></param>
        /// <param name="top"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <param name="rop"></param>
        /// <returns></returns>
        [DllImport("gdi32.dll", CharSet = CharSet.Auto, SetLastError = true, ExactSpelling = true)]
        public static extern bool PatBlt(HandleRef hdc, int left, int top, int width, int height, int rop);

        /// <summary>
        /// User32.dll ReleaseCapture method.
        /// </summary>
        /// <returns></returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern bool ReleaseCapture();

        /// <summary>
        /// Gdi32.dll SelectObject method. Selects an object into the specified device context (DC). 
        /// </summary>
        /// <param name="hDC">Handle to the DC.</param>
        /// <param name="hObject">Handle to the object to be selected.</param>
        /// <returns>A handle to the object being replaced.</returns>
        [DllImport("gdi32.dll", CharSet = CharSet.Auto, SetLastError = true, ExactSpelling = true)]
        public static extern IntPtr SelectObject(HandleRef hDC, HandleRef hObject);


        /// 
        /// <summary>
        /// Retrieves a pointer to the window that currently has the input focus.
        /// </summary>
        /// <returns>A pointer to the window that has the current focus, or NULL if there is no focus window.</returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Winapi)]
        internal static extern IntPtr GetFocus();

        /// <summary>
        /// Retrieves the control that currently has the input focus.
        /// </summary>
        /// <returns>The control that has input focus or null if there is no focus window or the window is not a .NET control</returns>
        static internal Control GetControlWithFocus()
        {
            Control controlWithFocus = null;

            IntPtr focusHandle = GetFocus();

            if (focusHandle != IntPtr.Zero)
            {
                controlWithFocus = Control.FromHandle(focusHandle);

            }

            return controlWithFocus;

        }

    }

}
