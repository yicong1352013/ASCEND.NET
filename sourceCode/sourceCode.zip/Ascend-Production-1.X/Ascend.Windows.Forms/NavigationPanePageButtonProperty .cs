/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Drawing.Design;
using System.Text;
using System.ComponentModel;
using System.Security;
using System.Security.Permissions;
using System.Drawing;
using System.Drawing.Drawing2D;
using Ascend.Resources;
using System.Windows.Forms;

namespace Ascend.Windows.Forms
{

    /// <summary>
    /// User interface (UI) for representing and editing the values of objects of the supported data types in a button.
    /// </summary>
    [TypeConverterAttribute(typeof(NavigationPanePageButtonConverter))]
    [PermissionSet(SecurityAction.LinkDemand, Name = "FullTrust")]
    [PermissionSet(SecurityAction.InheritanceDemand, Name = "FullTrust")]
    public class NavigationPanePageButtonProperty : UITypeEditor
    {
        private NavigationPanePage _navigationPanePage;

        /// <summary>
        /// Gets or sets the parent NavigationPanePage.
        /// </summary>
        [Browsable(false)]
        public NavigationPanePage NavigationPanePage
        {
            get
            {
                return this._navigationPanePage;

            }

            set
            {
                this._navigationPanePage = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the button when it is active.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the button when it is active.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ActiveGradientHighColorDescription"), ResourceDisplayName("DisplayNameActiveGradientHighColor")]
        public Color ActiveGradientHighColor
        {
            get
            {

                return this._navigationPanePage.ActiveGradientHighColor;

            }

            set
            {
                this._navigationPanePage.ActiveGradientHighColor = value;

            }
        }

        /// <summary>
        /// Determines if the ActiveGradientHighColor property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeActiveGradientHighColor()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if (parentNavigationPane.ButtonActiveGradientHighColor == this._navigationPanePage.ActiveGradientHighColor)
                    {
                        return false;

                    }
                    else
                    {
                        return true;

                    }

                }
                else
                {
                    return true;

                }

            }
            else
            {
                return true;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the button when it is active.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the button when it is active.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ActiveGradientLowColorDescription"), ResourceDisplayName("DisplayNameActiveGradientLowColor")]
        public Color ActiveGradientLowColor
        {
            get
            {
                return this._navigationPanePage.ActiveGradientLowColor;

            }

            set
            {
                this._navigationPanePage.ActiveGradientLowColor = value;

            }

        }

        /// <summary>
        /// Determines if the ActiveGradientLowColor property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeActiveGradientLowColor()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if (parentNavigationPane.ButtonActiveGradientLowColor == this._navigationPanePage.ActiveGradientLowColor)
                    {
                        return false;

                    }
                    else
                    {
                        return true;

                    }

                }
                else
                {
                    return true;

                }

            }
            else
            {
                return true;

            }

        }

        /// <summary>
        /// Gets or sets the button forecolor.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ForeColorDescription"), ResourceDisplayName("DisplayNameForeColor")]
        public Color ForeColor
        {
            get
            {
                return this._navigationPanePage.ButtonForeColor;

            }

            set
            {
                this._navigationPanePage.ButtonForeColor = value;

            }

        }

        /// <summary>
        /// Determines if the ForeColor property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeForeColor()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if (parentNavigationPane.ButtonForeColor == this._navigationPanePage.ButtonForeColor)
                    {
                        return false;

                    }
                    else
                    {
                        return true;

                    }

                }
                else
                {
                    return true;

                }

            }
            else
            {
                return true;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the button when it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the button when it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightGradientHighColorDescription"), ResourceDisplayName("DisplayNameHighlightGradientHighColor")]
        public Color HighlightGradientHighColor
        {
            get
            {
                return this._navigationPanePage.HighlightGradientHighColor;

            }

            set
            {
                this._navigationPanePage.HighlightGradientHighColor = value;

            }

        }

        /// <summary>
        /// Determines if the HighlightGradientHighColor property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeHighlightGradientHighColor()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if (parentNavigationPane.ButtonHighlightGradientHighColor == this._navigationPanePage.HighlightGradientHighColor)
                    {
                        return false;

                    }
                    else
                    {
                        return true;

                    }

                }
                else
                {
                    return true;

                }

            }
            else
            {
                return true;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the button when it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the button when it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightGradientLowColorDescription"), ResourceDisplayName("DisplayNameHighlightGradientLowColor")]
        public Color HighlightGradientLowColor
        {
            get
            {
                return this._navigationPanePage.HighlightGradientLowColor;

            }

            set
            {
                this._navigationPanePage.HighlightGradientLowColor = value;

            }

        }

        /// <summary>
        /// Determines if the HighlightGradientLowColor property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeHighlightGradientLowColor()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if (parentNavigationPane.ButtonHighlightGradientLowColor == this._navigationPanePage.HighlightGradientLowColor)
                    {
                        return false;

                    }
                    else
                    {
                        return true;

                    }

                }
                else
                {
                    return true;

                }

            }
            else
            {
                return true;

            }

        }

        /// <summary>
        /// The image associated with this control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Image . The image associated with this control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceDescriptionAttribute("ImageDescription"), ResourceCategoryAttribute("AppearanceCategory"), ResourceDisplayName("DisplayNameImage"), RefreshProperties(RefreshProperties.Repaint), DefaultValueAttribute(typeof(Image), "(none)")]
        public Image Image
        {
            get
            {
                return this._navigationPanePage.Image;

            }

            set
            {
                this._navigationPanePage.Image = value;

            }

        }

        /// <summary>
        /// The ContentAlignment associated with this controls image.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.ContentAlignment . The ContentAlignment associated with this controls image.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ImageAlignmentDescription"), ResourceDisplayName("DisplayNameImageAlign")]
        public ContentAlignment ImageAlign
        {
            get
            {
                return this._navigationPanePage.ImageAlign;

            }

            set
            {
                this._navigationPanePage.ImageAlign = value;

            }

        }

        /// <summary>
        /// Determines if the ImageAlign property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeImageAlign()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if (parentNavigationPane.ButtonImageAlign == this._navigationPanePage.ImageAlign)
                    {
                        return false;

                    }
                    else
                    {
                        return true;

                    }

                }
                else
                {
                    return true;

                }

            }
            else
            {
                return true;

            }

        }

        /// <summary>
        /// Gets or sets the image list index value of the image displayed on the control. 
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint), ResourceCategoryAttribute("AppearanceCategory"), ResourceDisplayName("DisplayNameImageIndex"), TypeConverter(typeof(ImageIndexConverter)), Editor("System.Windows.Forms.Design.ImageIndexEditor, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor)), Localizable(true), ResourceDescriptionAttribute("ImageIndexDescription"), DefaultValue(-1)]
        public int ImageIndex
        {
            get
            {
                return this._navigationPanePage.ImageIndex;

            }

            set
            {
                this._navigationPanePage.ImageIndex = value;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDisplayName("DisplayNameImageKey"), TypeConverter(typeof(ImageKeyConverter)), Editor("System.Windows.Forms.Design.ImageIndexEditor, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor)), Localizable(true), DefaultValue(""), RefreshProperties(RefreshProperties.Repaint), ResourceDescriptionAttribute("ImageIndexDescription")]
        public string ImageKey
        {
            get
            {
                return this._navigationPanePage.ImageKey;

            }

            set
            {
                this._navigationPanePage.ImageKey = value;

            }

        }

        /// <summary>
        /// Gets or sets the ImageList that contains the Image displayed on the button of the control. 
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ImageListDescription"), ResourceDisplayName("DisplayNameImageList"), RefreshProperties(RefreshProperties.Repaint), DefaultValueAttribute(typeof(ImageList), "(none)")]
        public ImageList ImageList
        {
            get
            {
                return this._navigationPanePage.ImageList;

            }

            set
            {
                this._navigationPanePage.ImageList = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientHighColorDescription"), ResourceDisplayName("DisplayNameGradientHighColor")]
        public Color GradientHighColor
        {
            get
            {
                return this._navigationPanePage.GradientHighColor;

            }

            set
            {
                this._navigationPanePage.GradientHighColor = value;

            }

        }

        /// <summary>
        /// Determines if the GradientHighColor property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeGradientHighColor()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if (parentNavigationPane.ButtonGradientHighColor == this._navigationPanePage.GradientHighColor)
                    {
                        return false;

                    }
                    else
                    {
                        return true;

                    }

                }
                else
                {
                    return true;

                }

            }
            else
            {
                return true;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientLowColorDescription"), ResourceDisplayName("DisplayNameGradientLowColor")]
        public Color GradientLowColor
        {
            get
            {
                return this._navigationPanePage.GradientLowColor;

            }

            set
            {
                this._navigationPanePage.GradientLowColor = value;

            }

        }

        /// <summary>
        /// Determines if the GradientLowColor property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeGradientLowColor()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if (parentNavigationPane.ButtonGradientLowColor == this._navigationPanePage.GradientLowColor)
                    {
                        return false;

                    }
                    else
                    {
                        return true;

                    }

                }
                else
                {
                    return true;

                }

            }
            else
            {
                return true;

            }

        }

        /// <summary>
        /// Gets or sets the font associated with the button.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ButtonFontDescription"), ResourceDisplayName("DisplayNameButtonFont")]
        public Font ButtonFont
        {
            get
            {

                return this._navigationPanePage.ButtonFont;

            }

            set
            {
                this._navigationPanePage.ButtonFont = value;

            }

        }

        /// <summary>
        /// Determines if the ButtonFont property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeButtonFont()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if ((parentNavigationPane.ButtonFont.Name != this.ButtonFont.Name) || (this.ButtonFont.Size != 8.25f) || (this.ButtonFont.Bold != true))
                    {
                        return true;

                    }
                    else
                    {
                        return false;

                    }

                }
                else
                {
                    return true;

                }

            }
            else
            {
                return true;

            }

        }

        /// <summary>
        /// Resets the button font to default values.
        /// </summary>
        public void ResetButtonFont()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if (parentNavigationPane.ButtonFont != null)
                    {
                        this.ButtonFont = new Font(parentNavigationPane.ButtonFont.Name, 8.25f, FontStyle.Bold);

                    }
                    else if (parentNavigationPane.Parent.Font != null)
                    {
                        this.ButtonFont = new Font(parentNavigationPane.Parent.Font.Name, 8.25f, FontStyle.Bold);

                    }
                    else
                    {
                        this.ButtonFont = new Font(System.Windows.Forms.Control.DefaultFont.Name, 8.25f, FontStyle.Bold);

                    }

                }
                else
                {
                    this.ButtonFont = new Font(System.Windows.Forms.Control.DefaultFont.Name, 8.25f, FontStyle.Bold);

                }

            }
            else
            {
                this.ButtonFont = new Font(System.Windows.Forms.Control.DefaultFont.Name, 8.25f, FontStyle.Bold);

            }

        }

        /// <summary>
        /// Gets or sets the text associated with this control's button. 
        /// </summary>
        /// <value>
        /// The text associated with this control's button. 
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TextDescription"), ResourceDisplayName("DisplayNameText"), DefaultValueAttribute("")]
        public string Text
        {
            get
            {
                return this._navigationPanePage.Text;

            }

            set
            {
                this._navigationPanePage.Text = value;

            }

        }

        /// <summary>
        /// The ContentAlignment associated with this controls text.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.ContentAlignment . The ContentAlignment associated with this controls text.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TextAlignmentDescription"), ResourceDisplayName("DisplayNameTextAlign")]
        public ContentAlignment TextAlign
        {
            get
            {
                return this._navigationPanePage.TextAlign;

            }

            set
            {
                this._navigationPanePage.TextAlign = value;

            }

        }

        /// <summary>
        /// Determines if the TextAlign property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeTextAlign()
        {
            if (this._navigationPanePage.Parent != null)
            {
                NavigationPane parentNavigationPane = this._navigationPanePage.Parent as NavigationPane;

                if (parentNavigationPane != null)
                {
                    if (parentNavigationPane.ButtonTextAlign == this._navigationPanePage.TextAlign)
                    {
                        return false;

                    }
                    else
                    {
                        return true;

                    }

                }
                else
                {
                    return true;

                }

            }
            else
            {
                return true;

            }

        }

        /// <summary>
        /// The tooltip text to display.
        /// </summary>
        [ResourceDescriptionAttribute("ToolTipDescription"), ResourceCategoryAttribute("AppearanceCategory"), ResourceDisplayName("DisplayNameToolTipText")]
        public string ToolTipText
        {
            get
            {
                return this._navigationPanePage.ToolTipText;

            }

            set
            {
                this._navigationPanePage.ToolTipText = value;

            }

        }

        /// <summary>
        /// Gets a value indicating whether drop-down editors should be resizable by the user.
        /// </summary>
        [Browsable(false)]
        public override bool IsDropDownResizable
        {
            get
            {
                return false;

            }

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneButtonProperty class.
        /// </summary>
        /// <param name="navigationPanePage">The NavigationPanePage control to add the property values to.</param>
        public NavigationPanePageButtonProperty(NavigationPanePage navigationPanePage)
        {
            this._navigationPanePage = navigationPanePage;

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneButtonProperty class.
        /// </summary>
        /// <param name="navigationPanePage"></param>        
        /// <param name="gradientHighColor">The gradient high color of the button.</param>
        /// <param name="gradientLowColor">The gradient low color of the button.</param>        
        /// <param name="highlightGradientHighColor">The gradient high (lighter) color for the button when it is moused over.</param>
        /// <param name="highlightGradientLowColor">The gradient low (darker) color for the button when it is moused over.</param>
        /// <param name="activeGradientHighColor">The gradient high (lighter) color for the button when it is active.</param>
        /// <param name="activeGradientLowColor">The gradient low (darker) color for the button when it is active.</param>
        /// <param name="foreColor">The button forecolor.</param>
        public NavigationPanePageButtonProperty(NavigationPanePage navigationPanePage,
            Color gradientHighColor,
            Color gradientLowColor,
            Color highlightGradientHighColor,
            Color highlightGradientLowColor,
            Color activeGradientHighColor,
            Color activeGradientLowColor,
            Color foreColor
            )
        {
            this._navigationPanePage = navigationPanePage;

            this.GradientHighColor = gradientHighColor;
            this.GradientLowColor = gradientLowColor;

            this.HighlightGradientHighColor = highlightGradientHighColor;
            this.HighlightGradientLowColor = highlightGradientLowColor;
            this.ActiveGradientHighColor = activeGradientHighColor;
            this.ActiveGradientLowColor = activeGradientLowColor;
            this.ForeColor = foreColor;
            

        }

    }
}
