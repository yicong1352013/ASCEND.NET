/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Renders a gradient navigation button based on properties.
    /// </summary>
    public class GradientNavigationButtonRender : GradientCaptionRender
    {
        private bool _shouldHighlight;
        private bool _mouseOverHighlight = true;
        private Color _gradientLowColorHighlight = Color.FromArgb(255, 165, 78);
        private Color _gradientLowColorActive = Color.FromArgb(255, 165, 78);
        private Color _gradientHighColorHighlight = Color.White;
        private Color _gradientHighColorActive = Color.FromArgb(255, 225, 155);
        private bool _activeOnClick = true;
        private bool _active;
        private bool _disposed;

        /// <summary>
        /// Occurs when the  MouseOverHighlight property changes. 
        /// </summary>
        public event EventHandler MouseOverHighlightChanged;

        /// <summary>
        /// Occurs when the  HighlightGradientLowColor property changes. 
        /// </summary>
        public event EventHandler HighlightGradientLowColorChanged;

        /// <summary>
        /// Occurs when the  HighlightGradientHighColor property changes. 
        /// </summary>
        public event EventHandler HighlightGradientHighColorChanged;

        /// <summary>
        /// Occurs when the  ActiveOnClick property changes. 
        /// </summary>
        public event EventHandler ActiveOnClickChanged;

        /// <summary>
        /// Occurs when the ActiveGradientLowColor property changes. 
        /// </summary>
        public event EventHandler ActiveGradientLowColorChanged;

        /// <summary>
        /// Occurs when the ActiveGradientHighColor property changes. 
        /// </summary>
        public event EventHandler ActiveGradientHighColorChanged;

        /// <summary>
        /// Occurs when the Active property changes. 
        /// </summary>
        public event EventHandler ActiveChanged;

        /// <summary>
        /// Occurs when the Highlight property changes. 
        /// </summary>
        public event EventHandler HighlightChanged;

        /// <summary>
        /// Specifies if the control is currently active (has focus or is selected).
        /// </summary>
        /// <value>
        /// <para>
        /// System.Boolean . Specifies if the control is currently active (has focus or is selected).
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public virtual bool Active
        {
            get
            {
                return this._active;

            }

            set
            {
                if (value == this._active)
                {
                    return;

                }

                this._active = value;
                //base.HighlightBorder = value;

                this.OnActiveChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Specifies if the control should highlight if it is moused over.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Boolean . Specifies if the control should highlight if it is moused over.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public virtual bool MouseOverHighlight
        {
            get
            {
                return this._mouseOverHighlight;

            }

            set
            {
                if (value == this._mouseOverHighlight)
                {
                    return;

                }

                this._mouseOverHighlight = value;

                this.OnMouseOverHighlightChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control when it is moused over.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control when it is moused over.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public Color HighlightGradientLowColor
        {
            get
            {
                return this._gradientLowColorHighlight;

            }

            set
            {
                if (value == this._gradientLowColorHighlight)
                {
                    return;

                }

                this._gradientLowColorHighlight = value;

                this.OnHighlightGradientLowColorChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control when it is moused over.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control when it is moused over.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public Color HighlightGradientHighColor
        {
            get
            {
                return this._gradientHighColorHighlight;

            }

            set
            {
                if (value == this._gradientHighColorHighlight)
                {
                    return;

                }

                this._gradientHighColorHighlight = value;

                this.OnHighlightGradientHighColorChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Specifies if the control should become active if clicked.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Boolean . Specifies if the control should become active if clicked.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public virtual bool ActiveOnClick
        {
            get
            {
                return this._activeOnClick;

            }

            set
            {
                if (value == this._activeOnClick)
                {
                    return;

                }

                this._activeOnClick = value;

                this.OnActiveOnClickChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control when it is active.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control when it is active.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public Color ActiveGradientLowColor
        {
            get
            {
                return this._gradientLowColorActive;

            }

            set
            {
                if (value == this._gradientLowColorActive)
                {
                    return;

                }

                this._gradientLowColorActive = value;

                this.OnActiveGradientLowColorChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control when it is active.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control when it is active.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public Color ActiveGradientHighColor
        {
            get
            {
                return this._gradientHighColorActive;

            }

            set
            {
                if (value == this._gradientHighColorActive)
                {
                    return;

                }

                this._gradientHighColorActive = value;

                this.OnActiveGradientHighColorChanged(new EventArgs());

            }

        }

        /// <summary>
        /// 
        /// </summary>
        public bool Highlight
        {
            get
            {
                return this._shouldHighlight;

            }

            set
            {
                if (value == this._shouldHighlight)
                {
                    return;

                }

                this._shouldHighlight = value;
                //base.HighlightBorder = value;

                this.OnHighlightChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Initializes a new instance of the GradientNavigationButtonRender class.
        /// </summary>
        public GradientNavigationButtonRender() : base()
        {
        }

        /// <summary>
        /// Creates the gradient brush needed to draw the background.
        /// </summary>
        protected override void CreateBackBrush()
        {
            if (base.DisplayRectangle.Width > 0 && base.DisplayRectangle.Height > 0)
            {
                if (base.Enabled)
                {
                    if (this._active)
                    {
                        if (this._shouldHighlight)
                        {
                            if (this.RenderMode == RenderMode.Glass)
                            {
                                base.CreateBackBrush(GetColorLuminanceAdjusted(this._gradientLowColorActive, .93f), this._gradientLowColorActive);

                            }
                            else
                            {
                                base.CreateBackBrush(this._gradientHighColorActive, this._gradientLowColorActive);

                            }

                        }
                        else
                        {
                            base.CreateBackBrush(this._gradientLowColorActive, this._gradientHighColorActive);

                        }

                    }
                    else if (this._shouldHighlight)
                    {
                        base.CreateBackBrush(this._gradientLowColorHighlight, this._gradientHighColorHighlight);

                    }
                    else
                    {
                        base.CreateBackBrush();

                    }

                }
                else
                {
                    base.CreateBackBrush();

                }

            }

        }

        /// <summary>
        /// Fires the event indicating that control MouseOverHighlight property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnMouseOverHighlightChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnMouseOverHighlightChanged(EventArgs e)
        {
            if (this.MouseOverHighlightChanged != null)
            {
                this.MouseOverHighlightChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control HighlightGradientLowColor property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnHighlightGradientLowColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnHighlightGradientLowColorChanged(EventArgs e)
        {
            if (this.HighlightGradientLowColorChanged != null)
            {
                this.HighlightGradientLowColorChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control HighlightGradientHighColor property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnHighlightGradientHighColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnHighlightGradientHighColorChanged(EventArgs e)
        {
            if (this.HighlightGradientHighColorChanged != null)
            {
                this.HighlightGradientHighColorChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control ActiveOnClick property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnActiveOnClickChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnActiveOnClickChanged(EventArgs e)
        {
            if (this.ActiveOnClickChanged != null)
            {
                this.ActiveOnClickChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control ActiveGradientLowColor property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnActiveGradientLowColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnActiveGradientLowColorChanged(EventArgs e)
        {
            if (this.ActiveGradientLowColorChanged != null)
            {
                this.ActiveGradientLowColorChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control ActiveGradientHighColor property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnActiveGradientHighColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnActiveGradientHighColorChanged(EventArgs e)
        {
            if (this.ActiveGradientHighColorChanged != null)
            {
                this.ActiveGradientHighColorChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control active property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnActiveChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnActiveChanged(EventArgs e)
        {
            if (this.ActiveChanged != null)
            {
                this.ActiveChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control highlight property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnHighlightChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnHighlightChanged(EventArgs e)
        {
            if (this.HighlightChanged != null)
            {
                this.HighlightChanged(this, e);

            }

        }

        /// <summary>
        /// Releases all resources used.
        /// </summary>
        /// <param name="disposing">true or false</param>
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        //nothing for the moment

                    }

                }

                this._disposed = true;

            }
            catch
            {
                throw;

            }
            finally
            {
                base.Dispose(disposing);

            }

        }

    }

}
