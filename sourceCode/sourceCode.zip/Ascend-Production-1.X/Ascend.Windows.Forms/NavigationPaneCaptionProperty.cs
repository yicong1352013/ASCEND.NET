/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Drawing.Design;
using System.Text;
using System.ComponentModel;
using System.Security;
using System.Security.Permissions;
using System.Drawing;
using System.Drawing.Drawing2D;
using Ascend.Resources;
using System.Windows.Forms;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// User interface (UI) for representing and editing the values of objects of the supported data types in a header.
    /// </summary>
    [TypeConverterAttribute(typeof(NavigationPaneCaptionConverter))]
    [System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name = "FullTrust")]
    public class NavigationPaneCaptionProperty : UITypeEditor
    {
        private NavigationPane _navigationPane;

        /// <summary>
        /// Gets or sets the parent NavigationPane.
        /// </summary>
        [Browsable(false)]
        public NavigationPane NavigationPane
        {
            get
            {
                return this._navigationPane;

            }

            set
            {
                this._navigationPane = value;

            }

        }

        /// <summary>
        /// Gets or sets the border color that should be shown in the caption.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("BorderColorDescription"), ResourceDisplayName("DisplayNameBorderColor"), DefaultValueAttribute(typeof(Color), "ActiveCaption")]
        public Color BorderColor
        {
            get
            {
                return this._navigationPane.CaptionBorderColor;

            }

            set
            {
                this._navigationPane.CaptionBorderColor = value;

            }

        }

        /// <summary>
        /// Gets or sets if the active button image should be shown in the caption.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ImageInCaptionDescription"), ResourceDisplayName("DisplayNameImageInCaption"), DefaultValueAttribute(false)]
        public bool DisplayImage
        {
            get
            {
                return this._navigationPane.ImageInCaption;

            }

            set
            {
                this._navigationPane.ImageInCaption = value;

            }

        }

        /// <summary>
        /// Gets or sets the font associated with the caption.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), Localizable(true), ResourceDescriptionAttribute("CaptionFontDescription"), ResourceDisplayName("DisplayNameCaptionFont")]
        public Font Font
        {
            get
            {
                return this._navigationPane.CaptionFont;

            }

            set
            {
                this._navigationPane.CaptionFont = value;

            }

        }

        /// <summary>
        /// Determines if the Font property has default values or not.
        /// </summary>
        /// <remarks>
        /// This method is used internally to the control and should not be called by your code.
        /// </remarks>
        /// <returns>true or false</returns>
        public bool ShouldSerializeFont()
        {
            if ((this._navigationPane.CaptionFont.Name != this._navigationPane.Font.Name) || (this._navigationPane.CaptionFont.Size != 11.25f) || (this._navigationPane.CaptionFont.Bold != true))
            {
                return true;

            }
            else
            {
                return false;

            }

        }

        /// <summary>
        /// Resets the font to default values.
        /// </summary>
        public void ResetFont()
        {
            if (this._navigationPane.Font != null)
            {
                this.Font = new Font(this._navigationPane.Font.Name, 11.25f, FontStyle.Bold);

            }
            else if (this._navigationPane.Parent.Font != null)
            {
                this.Font = new Font(this._navigationPane.Parent.Font.Name, 11.25f, FontStyle.Bold);

            }
            else
            {
                this.Font = new Font(System.Windows.Forms.Control.DefaultFont.Name, 11.25f, FontStyle.Bold);

            }

        }

        /// <summary>
        /// Gets or sets the forecolor
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ForeColorDescription"), ResourceDisplayName("DisplayNameForeColor"), DefaultValueAttribute(typeof(Color), "ActiveCaptionText")]
        public Color ForeColor
        {
            get
            {
                return this._navigationPane.CaptionForeColor;

            }

            set
            {
                this._navigationPane.CaptionForeColor = value;

            }

        }

        /// <summary>
        /// Specifies the direction of the linear gradient for the caption.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Drawing2D.LinearGradientMode . Specifies the direction of a linear gradient.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("CaptionGradientModeDescription"), ResourceDisplayName("DisplayNameCaptionGradientMode"), DefaultValueAttribute(LinearGradientMode.Vertical)]
        public LinearGradientMode GradientMode
        {
            get
            {
                return this._navigationPane.CaptionGradientMode;

            }

            set
            {
                this._navigationPane.CaptionGradientMode = value;

            }

        }

        /// <summary>
        /// Gets or sets the height of the footer.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("CaptionHeightDescription"), ResourceDisplayName("DisplayNameCaptionHeight"), DefaultValueAttribute(26)]
        public int Height
        {
            get
            {
                return this._navigationPane.CaptionHeight;

            }

            set
            {
                this._navigationPane.CaptionHeight = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientHighColorDescription"), ResourceDisplayName("DisplayNameGradientHighColor"), DefaultValueAttribute(typeof(Color), "GradientActiveCaption")]
        public Color GradientHighColor
        {
            get
            {
                return this._navigationPane.CaptionGradientHighColor;

            }

            set
            {
                this._navigationPane.CaptionGradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientLowColorDescription"), ResourceDisplayName("DisplayNameGradientLowColor"), DefaultValueAttribute(typeof(Color), "ActiveCaption")]
        public Color GradientLowColor
        {
            get
            {
                return this._navigationPane.CaptionGradientLowColor;

            }

            set
            {
                this._navigationPane.CaptionGradientLowColor = value;

            }

        }

        /// <summary>
        /// The ContentAlignment associated with the caption image.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.ContentAlignment . The ContentAlignment associated with the caption image.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ImageAlignmentDescription"), ResourceDisplayName("DisplayNameImageAlign"), DefaultValueAttribute(ContentAlignment.MiddleRight)]
        public ContentAlignment ImageAlign
        {
            get
            {
                return this._navigationPane.CaptionImageAlign;

            }

            set
            {
                this._navigationPane.CaptionImageAlign = value;

            }

        }

        /// <summary>
        /// The ContentAlignment associated with the caption text.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.ContentAlignment . The ContentAlignment associated with the caption text.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("TextAlignmentDescription"), ResourceDisplayName("DisplayNameTextAlign"), DefaultValueAttribute(ContentAlignment.MiddleLeft)]
        public ContentAlignment TextAlign
        {
            get
            {
                return this._navigationPane.CaptionTextAlign;

            }

            set
            {
                this._navigationPane.CaptionTextAlign = value;

            }

        }

        /// <summary>
        /// Gets a value indicating whether drop-down editors should be resizable by the user.
        /// </summary>
        [Browsable(false)]
        public override bool IsDropDownResizable
        {
            get
            {
                return false;

            }

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneCaptionProperty class.
        /// </summary>
        /// <param name="navigationPane">The NavigationPane control to add the property values to.</param>
        public NavigationPaneCaptionProperty(NavigationPane navigationPane)
        {
            this._navigationPane = navigationPane;
   
        }
        
        /// <summary>
        /// Initializes a new instance of the NavigationPaneCaptionProperty class.
        /// </summary>
        /// <param name="navigationPane"></param>
        /// <param name="height">The height of the caption.</param>
        /// <param name="gradientHighColor">The gradient high color of the caption.</param>
        /// <param name="gradientLowColor">The gradient low color of the caption.</param>
        /// <param name="gradientMode">Specifies the direction of the linear gradient for the caption.</param>
        /// <param name="displayImage">Should the active button image be shown in the caption.</param>
        /// <param name="font">The font to use in the caption.</param>
        /// <param name="foreColor">The forecolor to use in the caption.</param>
        /// <param name="imageAlign">The alignment of the inmage in the caption.</param>
        /// <param name="textAlign">The alignment of the text in the caption.</param>
        /// <param name="borderColor">The color of the border shown in the cation.</param>
        public NavigationPaneCaptionProperty(NavigationPane navigationPane, int height, Color gradientHighColor, Color gradientLowColor, LinearGradientMode gradientMode, bool displayImage, Font font, Color foreColor, ContentAlignment imageAlign, ContentAlignment textAlign, Color borderColor)
        {
            this._navigationPane = navigationPane;
            this.Height = height;
            this.GradientHighColor = gradientHighColor;
            this.GradientLowColor = gradientLowColor;
            this.GradientMode = gradientMode;
            this.DisplayImage = displayImage;
            this.Font = font;
            this.ForeColor = foreColor;
            this.ImageAlign = imageAlign;
            this.TextAlign = textAlign;
            this.BorderColor = borderColor;

        }

    }

}
