using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Defines values representing GradientNavigationButton events
    /// </summary>
    public enum GradientNavigationButtonAction
    {
        /// <summary>
        /// Represents the Selecting event.
        /// </summary>
        Selecting,
        /// <summary>
        /// Represents the Selected event
        /// </summary>
        Selected,
        /// <summary>
        /// Represents the Deselecting event
        /// </summary>
        Deselecting,
        /// <summary>
        /// Represents the Deselected event
        /// </summary>
        Deselected

    }

    /// <summary>
    /// Provides data for the Selecting and Deselecting events of a GradientNavigationButton control. 
    /// </summary>
    public class GradientNavigationButtonCancelEventArgs : CancelEventArgs
    {
        private GradientNavigationButtonAction _gradientNavigationButtonAction;

        /// <summary>
        /// Gets a value indicating which event is occurring. 
        /// </summary>
        /// <value>
        /// One of the GradientNavigationButtonAction values.
        /// </value>
        public GradientNavigationButtonAction Action
        {
            get
            {
                return this._gradientNavigationButtonAction;

            }

        }
        
        /// <summary>
        /// Initializes a new instance of the GradientNavigationButtonCancelEventArgs class.
        /// </summary>
        /// <param name="cancel">true to cancel the GradientNavigationButton change by default; otherwise, false.</param>
        /// <param name="action">One of the GradientNavigationButtonAction values.</param>
        public GradientNavigationButtonCancelEventArgs(bool cancel, GradientNavigationButtonAction action) : base(cancel)
        {
            this._gradientNavigationButtonAction = action;
   
        }

    }

}
