/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing.Design;
using System.Text;
using Ascend.Resources;
using System.Drawing;
using System.Security;
using System.Security.Permissions;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// User interface (UI) for representing and editing the values of objects of the supported data types in a footer.
    /// </summary>
    [TypeConverterAttribute(typeof(NavigationPaneFooterConverter))]
    [System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name = "FullTrust")]
    public class NavigationPaneFooterProperty : UITypeEditor
    {
        private NavigationPane _navigationPane;

        /// <summary>
        /// Gets or sets the parent NavigationPane.
        /// </summary>
        [Browsable(false)]
        public NavigationPane NavigationPane
        {
            get
            {
                return this._navigationPane;

            }

            set
            {
                this._navigationPane = value;

            }

        }

        /// <summary>
        /// Gets or sets the height of the footer.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("FooterHeightDescription"), ResourceDisplayName("DisplayNameFooterHeight"), DefaultValueAttribute(30)]
        public int Height
        {
            get
            {
                return this._navigationPane.FooterHeight;

            }

            set
            {
                this._navigationPane.FooterHeight = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientHighColorDescription"), ResourceDisplayName("DisplayNameGradientHighColor"), DefaultValueAttribute(typeof(Color), "ButtonHighlight")]
        public Color GradientHighColor
        {
            get
            {
                return this._navigationPane.FooterGradientHighColor;

            }

            set
            {
                this._navigationPane.FooterGradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control when it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control when it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightGradientLowColorDescription"), ResourceDisplayName("DisplayNameHighlightGradientLowColor"), DefaultValueAttribute(typeof(Color), "255, 165, 78")]
        public Color HighlightGradientLowColor
        {
            get
            {
                return this._navigationPane.FooterHighlightGradientLowColor;

            }

            set
            {
                this._navigationPane.FooterHighlightGradientLowColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientLowColorDescription"), ResourceDisplayName("DisplayNameGradientLowColor"), DefaultValueAttribute(typeof(Color), "GradientActiveCaption")]
        public Color GradientLowColor
        {
            get
            {
                return this._navigationPane.FooterGradientLowColor;

            }

            set
            {
                this._navigationPane.FooterGradientLowColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control when it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control when it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightGradientHighColorDescription"), ResourceDisplayName("DisplayNameHighlightGradientHighColor"), DefaultValueAttribute(typeof(Color), "White")]
        public Color HighlightGradientHighColor
        {
            get
            {
                return this._navigationPane.FooterHighlightGradientHighColor;

            }

            set
            {
                this._navigationPane.FooterHighlightGradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets a value indicating whether drop-down editors should be resizable by the user.
        /// </summary>
        [Browsable(false)]
        public override bool IsDropDownResizable
        {
            get
            {
                return false;

            }

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneFooterProperty class.
        /// </summary>
        /// <param name="navigationPane">The NavigationPane control to add the property values to.</param>
        public NavigationPaneFooterProperty(NavigationPane navigationPane)
        {
            this._navigationPane = navigationPane;

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneFooterProperty class.
        /// </summary>
        /// <param name="navigationPane"></param>
        /// <param name="height">The height of the footer.</param>
        /// <param name="gradientHighColor">The gradient high color of the footer.</param>
        /// <param name="gradientLowColor">The gradient low color of the footer.</param>
        /// <param name="highlightGradientHighColor">The highlight gradient high color of the footer.</param>
        /// <param name="highlightGradientLowColor">The highlight gradient low color of the footer.</param>
        public NavigationPaneFooterProperty(NavigationPane navigationPane, int height, Color gradientHighColor, Color gradientLowColor, Color highlightGradientHighColor, Color highlightGradientLowColor)
        {
            this._navigationPane = navigationPane;
            this.Height = height;
            this.GradientHighColor = gradientHighColor;
            this.GradientLowColor = gradientLowColor;
            this.HighlightGradientHighColor = highlightGradientHighColor;
            this.HighlightGradientLowColor = highlightGradientLowColor;

        }

    }

}
