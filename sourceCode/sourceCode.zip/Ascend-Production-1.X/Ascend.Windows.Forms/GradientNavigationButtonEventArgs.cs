using System;
using System.Collections.Generic;
using System.Text;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Provides data for the Selected and Deselected events of a GradientNavigationButton control.
    /// </summary>
    public class GradientNavigationButtonEventArgs : EventArgs
    {
        private GradientNavigationButtonAction _gradientNavigationButtonAction;

        /// <summary>
        /// Gets a value indicating which event is occurring. 
        /// </summary>
        /// <value>
        /// One of the GradientNavigationButtonAction values.
        /// </value>
        public GradientNavigationButtonAction Action
        {
            get
            {
                return this._gradientNavigationButtonAction;

            }

        }

        /// <summary>
        /// Initializes a new instance of the GradientNavigationButtonEventArgs class.
        /// </summary>
        /// <param name="action">One of the GradientNavigationButtonAction values.</param>
        public GradientNavigationButtonEventArgs(GradientNavigationButtonAction action)
        {
            this._gradientNavigationButtonAction = action;
     
        }

    }

}
