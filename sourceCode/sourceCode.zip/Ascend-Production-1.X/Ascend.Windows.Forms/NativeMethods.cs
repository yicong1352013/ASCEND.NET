using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Collection of native Windows API methods encapsulated in managed code.
    /// </summary>
    internal class NativeMethods
    {
        /// <summary>
        /// Retrieves a pointer to the window that currently has the input focus.
        /// </summary>
        /// <returns>A pointer to the window that has the current focus, or NULL if there is no focus window.</returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Winapi)]
        internal static extern IntPtr GetFocus();

        /// <summary>
        /// Retrieves the control that currently has the input focus.
        /// </summary>
        /// <returns>The control that has input focus or null if there is no focus window or the window is not a .NET control</returns>
        static internal Control GetControlWithFocus()
        {
            Control controlWithFocus = null;

            IntPtr focusHandle = GetFocus();

            if (focusHandle != IntPtr.Zero)
            {
                controlWithFocus = Control.FromHandle(focusHandle);

            }

            return controlWithFocus;

        } 


    }

}
