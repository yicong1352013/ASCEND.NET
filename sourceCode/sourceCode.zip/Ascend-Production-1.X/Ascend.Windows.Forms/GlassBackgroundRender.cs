/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing.Drawing2D;
using System.Drawing;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Renders a glass background based on properties.
    /// </summary>
    public class GlassBackgroundRender : GradientBackgroundRender
    {
        /// <summary>
        /// Initializes a new instance of the GlassBackgroundRender class.
        /// </summary>
        public GlassBackgroundRender() : base()
        {            
        }

        /// <summary>
        /// Sets the rendering hints based on the AntiAlias property.
        /// </summary>
        /// <param name="e">A System.Windows.Forms.PaintEventArgs that contains the event data.</param>
        /// <remarks>
        /// This method must be called before any drawing methods are called.
        /// </remarks>
        protected override void SetRenderingHints(System.Windows.Forms.PaintEventArgs e)
        {
            base.SetRenderingHints(e);

            e.Graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
            e.Graphics.CompositingQuality = CompositingQuality.HighQuality;

        }

        /// <summary>
        /// Creates the blended gradient brush needed to draw the background.
        /// </summary>
        protected override void CreateBackBrush()
        {
            if (this.DisplayRectangle.Width > 0 && this.DisplayRectangle.Height > 0)
            {
                Color[] col = new Color[] { Color.FromArgb(225, 234, 245), Color.FromArgb(209, 223, 240), Color.FromArgb(199, 216, 237), Color.FromArgb(231, 242, 255) };
                float[] pos = new float[] { 0.0f, 0.2f, 0.2f, 1.0f };

                ColorBlend blend = new ColorBlend();
                blend.Colors = col;
                blend.Positions = pos;
                this.BackBrush = new LinearGradientBrush(this.DisplayRectangle, Color.Transparent, Color.Transparent, LinearGradientMode.Vertical);
                this.BackBrush.InterpolationColors = blend;

            }

        }

    }

}
