/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing.Design;
using System.ComponentModel;
using System.Security;
using System.Security.Permissions;
using System.Drawing;
using Ascend.Resources;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// User interface (UI) for representing and editing the values of objects of the supported data types in a splitbar.
    /// </summary>
    [TypeConverterAttribute(typeof(NavigationPaneSplitBarConverter))]
    [System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name = "FullTrust")]     
    public class NavigationPaneSplitBarProperty : UITypeEditor
    {
        private NavigationPane _navigationPane;

        /// <summary>
        /// Gets or sets the parent NavigationPane.
        /// </summary>
        [Browsable(false)]
        public NavigationPane NavigationPane
        {
            get
            {
                return this._navigationPane;

            }

            set
            {
                this._navigationPane = value;

            }

        }

        /// <summary>
        /// Gets or sets the height of the splitbar.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("SplitBarHeightDescription"), ResourceDisplayName("DisplayNameSplitBarHeight"), DefaultValueAttribute(7)]
        public int Height
        {
            get
            {
                return this._navigationPane.SplitBarHeight;

            }

            set
            {
                this._navigationPane.SplitBarHeight = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientHighColorDescription"), ResourceDisplayName("DisplayNameGradientHighColor"), DefaultValueAttribute(typeof(Color), "GradientActiveCaption")]
        public Color GradientHighColor
        {
            get
            {
                return this._navigationPane.SplitBarGradientHighColor;

            }

            set
            {
                this._navigationPane.SplitBarGradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientLowColorDescription"), ResourceDisplayName("DisplayNameGradientLowColor"), DefaultValueAttribute(typeof(Color), "ActiveCaption")]
        public Color GradientLowColor
        {
            get
            {
                return this._navigationPane.SplitBarGradientLowColor;

            }

            set
            {
                this._navigationPane.SplitBarGradientLowColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the border color of the split bar.
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint)]
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("BorderColorDescription"), ResourceDisplayName("DisplayNameBorderColor"), DefaultValueAttribute(typeof(Color), "ActiveCaption")]
        public Color BorderColor
        {
            get
            {
                return this._navigationPane.SplitBarBorderColor;

            }

            set
            {
                this._navigationPane.SplitBarBorderColor = value;

            }

        }

        /// <summary>
        /// Gets a value indicating whether drop-down editors should be resizable by the user.
        /// </summary>
        [Browsable(false)]
        public override bool IsDropDownResizable
        {
            get
            {
                return false;

            }

        }

        /// <param name="context">An <see cref="T:System.ComponentModel.ITypeDescriptorContext"></see> that can be used to gain additional context information.</param>
        /// <returns>A <see cref="T:System.Drawing.Design.UITypeEditorEditStyle"></see> value that indicates the style of editor used by the <see cref="M:System.Drawing.Design.UITypeEditor.EditValue(System.IServiceProvider,System.Object)"></see> method. If the <see cref="T:System.Drawing.Design.UITypeEditor"></see> does not support this method, then <see cref="M:System.Drawing.Design.UITypeEditor.GetEditStyle"></see> will return <see cref="F:System.Drawing.Design.UITypeEditorEditStyle.None"></see>.</returns>
        public override System.Drawing.Design.UITypeEditorEditStyle GetEditStyle(System.ComponentModel.ITypeDescriptorContext context)
        {
            return UITypeEditorEditStyle.None;

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneSplitBarProperty class.
        /// </summary>
        /// <param name="navigationPane">The NavigationPane control to add the property values to.</param>
        public NavigationPaneSplitBarProperty(NavigationPane navigationPane)
        {
            this._navigationPane = navigationPane;

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneSplitBarProperty class.
        /// </summary>
        /// <param name="navigationPane">The navigation pane.</param>
        /// <param name="height">The height of the splitbar.</param>
        /// <param name="gradientHighColor">The gradient high color of the split bar.</param>
        /// <param name="gradientLowColor">The gradient low color of the split bar.</param>
        /// <param name="borderColor">The color to use for the border of the split bar.</param>
        public NavigationPaneSplitBarProperty(NavigationPane navigationPane, int height, Color gradientHighColor, Color gradientLowColor, Color borderColor)
        {
            this._navigationPane = navigationPane;
            this.Height = height;
            this.GradientHighColor = gradientHighColor;
            this.GradientLowColor = gradientLowColor;
            this.BorderColor = borderColor;

        }

    }

}
