using System;
using System.Collections.Generic;
using System.Text;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Provides data for the Selected and Deselected events of a NavigationPane control.
    /// </summary>
    public class NavigationPaneEventArgs : EventArgs
    {
        private NavigationPaneAction _navigationPaneAction;
        private NavigationPanePage _navigationPanePage;
        private int _navigationPanePageIndex;
        private string _navigationPanePageKey;

        /// <summary>
        /// Gets a value indicating which event is occurring. 
        /// </summary>
        /// <value>
        /// One of the NavigationPaneAction values.
        /// </value>
        public NavigationPaneAction Action
        {
            get
            {
                return this._navigationPaneAction;

            }

        }

        /// <summary>
        /// Gets the zero-based index of the NavigationPanePage in the NavigationPanePages collection.
        /// </summary>
        /// <value>
        /// The zero-based index of the NavigationPanePage in the NavigationPanePages collection.
        /// </value>
        public int NavigationPanePageIndex
        {
            get
            {
                return this._navigationPanePageIndex;

            }

        }

        /// <summary>
        /// Gets the key of the NavigationPanePage in the NavigationPanePages collection.
        /// </summary>
        /// <value>
        /// The key of the NavigationPanePage in the NavigationPanePages collection.
        /// </value>
        public string NavigationPanePageKey
        {
            get
            {
                return this._navigationPanePageKey;

            }

        }

        /// <summary>
        /// Gets the NavigationPanePage the event is occurring for.
        /// </summary>
        /// <value>
        /// The NavigationPanePage the event is occurring for.
        /// </value>
        public NavigationPanePage NavigationPanePage
        {
            get
            {
                return this._navigationPanePage;

            }

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPaneEventArgs class.
        /// </summary>
        /// <param name="navigationPanePage">The NavigationPanePage the event is occurring for.</param>
        /// <param name="navigationPanePageIndex">The zero-based index of NavigationPanePage in the NavigationPanePages collection.</param>
        /// <param name="navigationPanePageKey">The key of the NavigationPanePage in the NavigationPanePages collection.</param>
        /// <param name="action">One of the NavigationPaneAction values.</param>
        public NavigationPaneEventArgs(NavigationPanePage navigationPanePage, int navigationPanePageIndex, string navigationPanePageKey, NavigationPaneAction action)
        {
            this._navigationPanePage = navigationPanePage;
            this._navigationPanePageIndex = navigationPanePageIndex;
            this._navigationPanePageKey = navigationPanePageKey;
            this._navigationPaneAction = action;
     
        }

    }

}
