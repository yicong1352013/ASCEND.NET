/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using Ascend.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Represents a Windows navigation button control with a gradient background.
    /// </summary>
    [ToolboxBitmap(typeof(GradientNavigationButton), "GradientNavigationButton.ico"), ResourceDescriptionAttribute("GradientNavigationButtonDescription")]
    public class GradientNavigationButton : GradientCaption
    {
        private bool _disposed;
        private bool _focusHighlight;
        private bool _showBorderOnHighlight;
        private bool _borderAdded;
        private bool _stayActiveAfterClick = true;
        private bool _wasActive;

        /// <summary>
        /// Occurs when the Active property changes. 
        /// </summary>
        [ResourceDescriptionAttribute("ActiveChangedEventDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameActiveChanged")]
        public event EventHandler ActiveChanged;

        /// <summary>
        /// Occurs when the ActiveGradientHighColor property changes. 
        /// </summary>
        [ResourceDescriptionAttribute("ActiveGradientHighColorEventDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameActiveGradientHighColorChanged")]
        public event EventHandler ActiveGradientHighColorChanged;

        /// <summary>
        /// Occurs when the ActiveGradientLowColor property changes. 
        /// </summary>
        [ResourceDescriptionAttribute("ActiveGradientLowColorEventDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameActiveGradientLowColorChanged")]
        public event EventHandler ActiveGradientLowColorChanged;

        /// <summary>
        /// Occurs when the ActiveOnClick property changes. 
        /// </summary>
        [ResourceDescriptionAttribute("ActiveOnClickEventDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameActiveOnClickChanged")]
        public event EventHandler ActiveOnClickChanged;

        /// <summary>
        /// Occurs when a GradientNavigationButton highlight is removed.
        /// </summary>
        [ResourceDescriptionAttribute("DehighlightedDescription"), ResourceCategoryAttribute("ActionCategory"), ResourceDisplayName("DisplayNameDehighlighted")]
        public event EventHandler Dehighlighted;

        /// <summary>
        /// Occurs when a GradientNavigationButton is deselected.
        /// </summary>
        [ResourceDescriptionAttribute("DeselectedDescription"), ResourceCategoryAttribute("ActionCategory"), ResourceDisplayName("DisplayNameDeselected")]
        public event EventHandler<GradientNavigationButtonEventArgs> Deselected;

        /// <summary>
        /// Occurs before a GradientNavigationButton is deselected, enabling a handler to cancel the GradientNavigationButton change. 
        /// </summary>
        [ResourceDescriptionAttribute("DeselectingDescription"), ResourceCategoryAttribute("ActionCategory"), ResourceDisplayName("DisplayNameDeselecting")]
        public event EventHandler<GradientNavigationButtonCancelEventArgs> Deselecting;

        /// <summary>
        /// Occurs when a GradientNavigationButton is highlighted.
        /// </summary>
        [ResourceDescriptionAttribute("HighlightedDescription"), ResourceCategoryAttribute("ActionCategory"), ResourceDisplayName("DisplayNameHighlighted")]
        public event EventHandler Highlighted;

        /// <summary>
        /// Occurs when the HighlightGradientLowColor property changes. 
        /// </summary>
        [ResourceDescriptionAttribute("HighlightGradientLowColorEventDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameHighlightGradientLowColorChanged")]
        public event EventHandler HighlightGradientLowColorChanged;

        /// <summary>
        /// Occurs when the HighlightGradientHighColor property changes. 
        /// </summary>
        [ResourceDescriptionAttribute("HighlightGradientHighColorEventDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameHighlightGradientHighColorChanged")]
        public event EventHandler HighlightGradientHighColorChanged;

        /// <summary>
        /// Occurs when the MouseOverHighlight property changes. 
        /// </summary>
        [ResourceDescriptionAttribute("MouseOverHighlightEventDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameMouseOverHighlightChanged")]
        public event EventHandler MouseOverHighlightChanged;

        /// <summary>
        /// Occurs when a control is selected.
        /// </summary>
        [ResourceDescriptionAttribute("SelectedDescription"), ResourceCategoryAttribute("ActionCategory"), ResourceDisplayName("DisplayNameSelected")]
        public event EventHandler<GradientNavigationButtonEventArgs> Selected;

        /// <summary>
        /// Occurs before a control is selected, enabling a handler to cancel the control change. 
        /// </summary>
        [ResourceDescriptionAttribute("SelectingDescription"), ResourceCategoryAttribute("ActionCategory"), ResourceDisplayName("DisplayNameSelecting")]
        public event EventHandler<GradientNavigationButtonCancelEventArgs> Selecting;

        /// <summary>
        /// Specifies if the control is currently active (has focus or is selected).
        /// </summary>
        /// <value>
        /// <para>
        /// System.Boolean . Specifies if the control is currently active (has focus or is selected).
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ActiveDescription"), ResourceDisplayName("DisplayNameActive"), DefaultValueAttribute(false)]
        public virtual bool Active
        {
            get
            {
                return ((GradientNavigationButtonRender)base.GradientRender).Active;

            }

            set
            {
                if (value == ((GradientNavigationButtonRender)base.GradientRender).Active)
                {
                    return;

                }

                if (value == false)
                {
                    bool cancel = false;
                    GradientNavigationButtonCancelEventArgs gradientNavigationButtonCancelEventArgs = new GradientNavigationButtonCancelEventArgs(cancel, GradientNavigationButtonAction.Deselecting);

                    this.OnDeselecting(gradientNavigationButtonCancelEventArgs);

                    if (gradientNavigationButtonCancelEventArgs.Cancel) return;

                }
                else
                {
                    bool cancel = false;
                    GradientNavigationButtonCancelEventArgs gradientNavigationButtonCancelEventArgs = new GradientNavigationButtonCancelEventArgs(cancel, GradientNavigationButtonAction.Selecting);

                    this.OnSelecting(gradientNavigationButtonCancelEventArgs);

                    if (gradientNavigationButtonCancelEventArgs.Cancel) return;

                }

                ((GradientNavigationButtonRender)base.GradientRender).Active = value;

                base.Invalidate();

                this.OnActiveChanged(new EventArgs());

                if (value == false)
                {
                    this.OnDeselected(new GradientNavigationButtonEventArgs(GradientNavigationButtonAction.Deselected));

                }
                else
                {
                    this.OnSelected(new GradientNavigationButtonEventArgs(GradientNavigationButtonAction.Selected));

                }

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control when it is active.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control when it is active.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ActiveGradientHighColorDescription"), ResourceDisplayName("DisplayNameActiveGradientHighColor"), DefaultValueAttribute(typeof(Color), "255, 225, 155")]
        public Color ActiveGradientHighColor
        {
            get
            {
                return ((GradientNavigationButtonRender)base.GradientRender).ActiveGradientHighColor;

            }

            set
            {
                if (value == ((GradientNavigationButtonRender)base.GradientRender).ActiveGradientHighColor)
                {
                    return;

                }

                ((GradientNavigationButtonRender)base.GradientRender).ActiveGradientHighColor = value;

                base.Invalidate();

                this.OnActiveGradientHighColorChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control when it is active.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control when it is active.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ActiveGradientLowColorDescription"), ResourceDisplayName("DisplayNameActiveGradientLowColor"), DefaultValueAttribute(typeof(Color), "255, 165, 78")]
        public Color ActiveGradientLowColor
        {
            get
            {
                return ((GradientNavigationButtonRender)base.GradientRender).ActiveGradientLowColor;

            }

            set
            {
                if (value == ((GradientNavigationButtonRender)base.GradientRender).ActiveGradientLowColor)
                {
                    return;

                }

                ((GradientNavigationButtonRender)base.GradientRender).ActiveGradientLowColor = value;

                base.Invalidate();

                this.OnActiveGradientLowColorChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Specifies if the control should become active if clicked.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Boolean . Specifies if the control should become active if clicked.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("ActiveOnClickDescription"), ResourceDisplayName("DisplayNameActiveOnClick"), DefaultValueAttribute(true)]
        public virtual bool ActiveOnClick
        {
            get
            {
                return ((GradientNavigationButtonRender)base.GradientRender).ActiveOnClick;

            }

            set
            {
                if (value == ((GradientNavigationButtonRender)base.GradientRender).ActiveOnClick)
                {
                    return;

                }

                ((GradientNavigationButtonRender)base.GradientRender).ActiveOnClick = value;

                this.OnActiveOnClickChanged(new EventArgs());

            }

        }

        /// <value>The default Size of the control.</value>
        protected override System.Drawing.Size DefaultSize
        {
            get
            {
                return new Size(165, 26);

            }

        }

        /// <summary>
        /// Sets or returns the specified foreground color for the style. Typically, this property sets the color for the text. The default value is MenuText.
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientModeDescription"), ResourceDisplayName("DisplayNameForeColor"), DefaultValueAttribute(typeof(Color), "MenuText")]
        public override Color ForeColor
        {
            get
            {
                return base.ForeColor;

            }

            set
            {
                if (base.ForeColor == value)
                {
                    return;

                }

                ((GradientNavigationButtonRender)this.GradientRender).ForeColor = value;
                base.ForeColor = value;

            }

        }

        /// <summary>
        /// Specifies if the control should highlight if it has focus.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Boolean . Specifies if the control should highlight if it has focus.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("FocusHighlightDescription"), ResourceDisplayName("DisplayNameFocusHighlight"), DefaultValueAttribute(true)]
        public bool FocusHighlight
        {
            get
            {
                return this._focusHighlight;

            }

            set
            {
                if (value == this._focusHighlight)
                {
                    return;

                }

                this._focusHighlight = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientHighColorDescription"), ResourceDisplayName("DisplayNameGradientHighColor"), DefaultValueAttribute(typeof(Color), "ButtonHighlight")]
        public new Color GradientHighColor
        {
            get
            {
                return base.GradientHighColor;

            }

            set
            {
                base.GradientHighColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("GradientLowColorDescription"), ResourceDisplayName("DisplayNameGradientLowColor"), DefaultValueAttribute(typeof(Color), "GradientActiveCaption")]
        public new Color GradientLowColor
        {
            get
            {
                return base.GradientLowColor;

            }

            set
            {
                base.GradientLowColor = value;

            }

        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control when it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control when it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightGradientHighColorDescription"), ResourceDisplayName("DisplayNameHighlightGradientHighColor"), DefaultValueAttribute(typeof(Color), "White")]
        public Color HighlightGradientHighColor
        {
            get
            {
                return ((GradientNavigationButtonRender)base.GradientRender).HighlightGradientHighColor;

            }

            set
            {
                if (value == ((GradientNavigationButtonRender)base.GradientRender).HighlightGradientHighColor)
                {
                    return;

                }

                ((GradientNavigationButtonRender)base.GradientRender).HighlightGradientHighColor = value;

                base.Invalidate();

                this.OnHighlightGradientHighColorChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control when it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control when it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("HighlightGradientLowColorDescription"), ResourceDisplayName("DisplayNameHighlightGradientLowColor"), DefaultValueAttribute(typeof(Color), "255, 165, 78")]
        public Color HighlightGradientLowColor
        {
            get
            {
                return ((GradientNavigationButtonRender)base.GradientRender).HighlightGradientLowColor;

            }

            set
            {
                if (value == ((GradientNavigationButtonRender)base.GradientRender).HighlightGradientLowColor)
                {
                    return;

                }

                ((GradientNavigationButtonRender)base.GradientRender).HighlightGradientLowColor = value;

                base.Invalidate();

                this.OnHighlightGradientLowColorChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Specifies if the control should highlight if it is moused over.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Boolean . Specifies if the control should highlight if it is moused over.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("MouseOverHighlightDescription"), ResourceDisplayName("DisplayNameMouseOverHighlight"), DefaultValueAttribute(true)]
        public virtual bool MouseOverHighlight
        {
            get
            {
                return ((GradientNavigationButtonRender)base.GradientRender).MouseOverHighlight;

            }

            set
            {
                if (value == ((GradientNavigationButtonRender)base.GradientRender).MouseOverHighlight)
                {
                    return;

                }

                ((GradientNavigationButtonRender)base.GradientRender).MouseOverHighlight = value;

                this.OnMouseOverHighlightChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Specifies if the control should add a 1 pixel border if the control is highlighted.
        /// </summary>
        /// <remarks>
        /// If a border greater than 0 is definded on any edge of the control this value will be ignored.
        /// The BorderColor property will be used for the color.
        /// </remarks>
        /// <value>
        /// <para>
        /// System.Boolean . Specifies if the control should add a 1 pixel border if the contro is highlighted.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("ShowBorderOnHighlightDescription"), ResourceDisplayName("DisplayNameShowBorderOnHighlight"), DefaultValueAttribute(false)]
        public bool ShowBorderOnHighlight
        {
            get
            {
                return this._showBorderOnHighlight;

            }

            set
            {
                this._showBorderOnHighlight = value;

            }

        }

        /// <summary>
        /// Specifies if the button should stay active after it is clicked.
        /// </summary>
        /// <remarks>
        /// True by default.
        /// </remarks>
        /// <value>
        /// System.Boolean . If true the button will stay active after clicked.
        /// </value>
        [ResourceCategoryAttribute("BehaviorCategory"), ResourceDescriptionAttribute("StayActiveAfterClickDescription"), ResourceDisplayName("DisplayNameStayActiveAfterClick"), DefaultValueAttribute(true)]
        public bool StayActiveAfterClick
        {
            get
            {
                return this._stayActiveAfterClick;

            }

            set
            {
                this._stayActiveAfterClick = value;

            }

        }

        /// <summary>
        /// Initializes a new instance of the GradientNavigationButton class.
        /// </summary>
        public GradientNavigationButton()
            : base()
        {
            this.GradientHighColor = SystemColors.ButtonHighlight;
            this.GradientLowColor = SystemColors.GradientActiveCaption;
            this.ForeColor = SystemColors.MenuText;
            this._focusHighlight = true;

        }

        /// <summary>
        /// Initializes the class used for rendering. 
        /// Rendering class must be based on IGradientReder.
        /// </summary>
        protected override void InitializeRender()
        {
            base.GradientRender = new GradientNavigationButtonRender();
            ((GradientNavigationButtonRender)base.GradientRender).Font = this.Font;
            ((GradientNavigationButtonRender)base.GradientRender).ForeColor = this.ForeColor;

        }

        /// <summary>
        /// Raises the MouseEnter event. Called when the mouse pointer moves over the control.
        /// </summary>
        /// <param name="e">System.EventArgs. An EventArgs that contains the event data.</param>
        protected override void OnMouseEnter(System.EventArgs e)
        {
            base.OnMouseEnter(e);

            if (((GradientNavigationButtonRender)base.GradientRender).MouseOverHighlight)
            {
                ((GradientNavigationButtonRender)base.GradientRender).Highlight = true;

                this.OnHighlighted(EventArgs.Empty);

                base.Invalidate();

            }

            if (!this._stayActiveAfterClick)
            {
                if (this._wasActive && !this.Active)
                {
                    this.Active = true;

                }

            }

        }

        /// <summary>
        /// Raises the MouseLeave event. Called when the mouse pointer leaves the control.
        /// </summary>
        /// <param name="e">System.EventArgs. An EventArgs that contains the event data.</param>
        protected override void OnMouseLeave(System.EventArgs e)
        {
            base.OnMouseLeave(e);

            if (((GradientNavigationButtonRender)base.GradientRender).MouseOverHighlight)
            {
                ((GradientNavigationButtonRender)base.GradientRender).Highlight = false;

                this.OnDehighlighted(EventArgs.Empty);

                base.Invalidate();

            }

            if (!this._stayActiveAfterClick)
            {
                if (this.Active)
                {
                    this._wasActive = true;

                    this.Active = false;

                }

            }

        }

        /// <summary>
        /// Raises the MouseDown event. Called when the mouse button is pressed while in the control.
        /// </summary>
        /// <param name="e">A System.Windows.Forms.MouseEventArgs that contains the event data.</param>
        protected override void OnMouseDown(System.Windows.Forms.MouseEventArgs e)
        {
            base.OnMouseDown(e);

            if (((GradientNavigationButtonRender)base.GradientRender).Active)
            {
                this.Focus();

            }
            else
            {
                if (!this._stayActiveAfterClick)
                {
                    ((GradientNavigationButtonRender)base.GradientRender).Active = true;

                    base.Invalidate();

                }

            }

        }

        /// <param name="e">An System.Windows.Forms.MouseEventArgs that contains the event data.</param>
        protected override void OnMouseClick(System.Windows.Forms.MouseEventArgs e)
        {
            if ((((GradientNavigationButtonRender)base.GradientRender).ActiveOnClick) && (!((GradientNavigationButtonRender)base.GradientRender).Active))
            {
                if (this._stayActiveAfterClick)
                {
                    this.Active = true;

                }
                else
                {
                    ((GradientNavigationButtonRender)base.GradientRender).Highlight = false;
                    this.Active = false;

                }

            }

            base.OnMouseClick(e);

        }

        /// <summary>
        /// Fires the event indicating that control active property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnActiveChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnActiveChanged(EventArgs e)
        {
            if (this.ActiveChanged != null)
            {
                this.ActiveChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control ActiveGradientHighColor property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnActiveGradientHighColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnActiveGradientHighColorChanged(EventArgs e)
        {
            if (this.ActiveGradientHighColorChanged != null)
            {
                this.ActiveGradientHighColorChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control ActiveGradientLowColor property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnActiveGradientLowColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnActiveGradientLowColorChanged(EventArgs e)
        {
            if (this.ActiveGradientLowColorChanged != null)
            {
                this.ActiveGradientLowColorChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control ActiveOnClick property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnActiveOnClickChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnActiveOnClickChanged(EventArgs e)
        {
            if (this.ActiveOnClickChanged != null)
            {
                this.ActiveOnClickChanged(this, e);

            }

        }

        /// <summary>
        /// Raises the Dehighlighted event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        /// <remarks>
        /// Raising an event invokes the event handler through a delegate. For more information, see Raising an Event.
        /// The OnDehighlighted method also enables derived classes to handle the event without attaching a delegate. This is the preferred technique for handling the event in a derived class.
        /// Notes to Inheritors When overriding OnDehighlighted in a derived class, be sure to call the base class's OnDehighlighted method so that registered delegates receive the event. 
        /// </remarks>
        protected virtual void OnDehighlighted(EventArgs e)
        {
            if (this._showBorderOnHighlight && this._borderAdded)
            {
                this._borderAdded = false;
                this.Border = new Border(0);

            }

            if (this.Dehighlighted != null)
            {
                this.Dehighlighted(this, e);

            }

        }

        /// <summary>
        /// Raises the Deselected event.
        /// </summary>
        /// <param name="e">A GradientNavigationButtonEventArgs that contains the event data.</param>
        /// <remarks>
        /// Raising an event invokes the event handler through a delegate. For more information, see Raising an Event.
        /// The OnDeselected method also enables derived classes to handle the event without attaching a delegate. This is the preferred technique for handling the event in a derived class.
        /// Notes to Inheritors When overriding OnDeselected in a derived class, be sure to call the base class's OnDeselected method so that registered delegates receive the event. 
        /// </remarks>
        protected virtual void OnDeselected(GradientNavigationButtonEventArgs e)
        {
            if (this.Deselected != null)
            {
                this.Deselected(this, e);

            }

        }

        /// <summary>
        /// Raises the Deselecting event.
        /// </summary>
        /// <param name="e">A GradientNavigationButtonCancelEventArgs that contains the event data.</param>
        /// <remarks>
        /// Raising an event invokes the event handler through a delegate.
        /// The OnDeselecting method also enables derived classes to handle the event without attaching a delegate. This is the preferred technique for handling the event in a derived class.
        /// Notes to Inheritors When overriding OnDeselecting in a derived class, be sure to call the base class's OnDeselecting method so that registered delegates receive the event. 
        /// </remarks>
        protected virtual void OnDeselecting(GradientNavigationButtonCancelEventArgs e)
        {
            if (this.Deselecting != null)
            {
                this.Deselecting(this, e);

            }

        }

        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        protected override void OnEnter(System.EventArgs e)
        {
            if (this._focusHighlight)
            {
                ((GradientNavigationButtonRender)base.GradientRender).Highlight = true;

                this.OnHighlighted(EventArgs.Empty);

            }

            base.OnEnter(e);

            base.Invalidate();

        }

        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        protected override void OnGotFocus(System.EventArgs e)
        {
            if (this._focusHighlight)
            {
                ((GradientNavigationButtonRender)base.GradientRender).Highlight = true;

                this.OnHighlighted(EventArgs.Empty);

            }

            base.OnGotFocus(e);

            base.Invalidate();

        }

        /// <summary>
        /// Raises the Highlighted event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        /// <remarks>
        /// Raising an event invokes the event handler through a delegate. For more information, see Raising an Event.
        /// The OnHighlighted method also enables derived classes to handle the event without attaching a delegate. This is the preferred technique for handling the event in a derived class.
        /// Notes to Inheritors When overriding OnHighlighted in a derived class, be sure to call the base class's OnHighlighted method so that registered delegates receive the event. 
        /// </remarks>
        protected virtual void OnHighlighted(EventArgs e)
        {
            if (this._showBorderOnHighlight && this.Border.All == 0)
            {
                this._borderAdded = true;
                this.Border = new Border(1);

            }

            if (this.Highlighted != null)
            {
                this.Highlighted(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control HighlightGradientHighColor property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnHighlightGradientHighColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnHighlightGradientHighColorChanged(EventArgs e)
        {
            if (this.HighlightGradientHighColorChanged != null)
            {
                this.HighlightGradientHighColorChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that control HighlightGradientLowColor property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnHighlightGradientLowColorChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnHighlightGradientLowColorChanged(EventArgs e)
        {
            if (this.HighlightGradientLowColorChanged != null)
            {
                this.HighlightGradientLowColorChanged(this, e);

            }

        }

        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        protected override void OnLeave(System.EventArgs e)
        {
            if (this._focusHighlight)
            {
                ((GradientNavigationButtonRender)base.GradientRender).Highlight = false;

                this.OnDehighlighted(EventArgs.Empty);

            }

            base.OnLeave(e);

            base.Invalidate();

        }

        /// <param name="e">An <see cref="T:System.EventArgs"></see> that contains the event data.</param>
        protected override void OnLostFocus(System.EventArgs e)
        {
            if (this._focusHighlight)
            {
                ((GradientNavigationButtonRender)base.GradientRender).Highlight = false;

                this.OnDehighlighted(EventArgs.Empty);

            }

            base.OnLostFocus(e);

            base.Invalidate();

        }

        /// <summary>
        /// Fires the event indicating that control MouseOverHighlight property has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnMouseOverHighlightChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnMouseOverHighlightChanged(EventArgs e)
        {
            if (this.MouseOverHighlightChanged != null)
            {
                this.MouseOverHighlightChanged(this, e);

            }

        }

        /// <summary>
        /// Raises the Selected event.
        /// </summary>
        /// <param name="e">A GradientNavigationButtonEventArgs that contains the event data.</param>
        protected virtual void OnSelected(GradientNavigationButtonEventArgs e)
        {
            if (this.Selected != null)
            {
                this.Selected(this, e);

            }

        }

        /// <summary>
        /// Raises the Selecting event.
        /// </summary>
        /// <param name="e">A GradientNavigationButtonCancelEventArgs that contains the event data.</param>
        /// <remarks>
        /// Raising an event invokes the event handler through a delegate.
        /// The OnSelecting method also enables derived classes to handle the event without attaching a delegate. This is the preferred technique for handling the event in a derived class.
        /// Notes to Inheritors When overriding OnSelecting in a derived class, be sure to call the base class's OnSelecting method so that registered delegates receive the event. 
        /// </remarks>
        protected virtual void OnSelecting(GradientNavigationButtonCancelEventArgs e)
        {
            if (this.Selecting != null)
            {
                this.Selecting(this, e);

            }

        }

        /// <summary>
        /// Releases the unmanaged resources used by the GradientNavigationButton and optionally releases the managed resources.
        /// </summary>
        /// <param name="disposing">true to release both managed and unmanaged resources; false to release only unmanaged resources.</param>
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        ((GradientNavigationButtonRender)base.GradientRender).Dispose();

                    }

                }

                this._disposed = true;

            }
            catch
            {
                throw;

            }
            finally
            {
                base.Dispose(disposing);

            }

        }

        /// <summary>
        /// Raises the MouseUp event.
        /// </summary>
        /// <param name="e">A <see cref="T:System.Windows.Forms.MouseEventArgs"></see> that contains the event data.</param>
        protected override void OnMouseUp(System.Windows.Forms.MouseEventArgs e)
        {
            this._wasActive = false;

            if (!this._stayActiveAfterClick && this.Active)
            {
                this.Active = false;

            }

        }

    }

}
