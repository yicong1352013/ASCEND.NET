/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using Ascend.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Represents a split bar with bumps and a gradient background.
    /// </summary>
    [ToolboxBitmap(typeof(GradientSplitBar), "GradientSplitBar.ico"), Designer("Ascend.Windows.Forms.Design.GradientSplitBarDesigner, Ascend.Design, Culture=neutral, PublicKeyToken=5123e2ac4258b06a"), ResourceDescriptionAttribute("GradientSplitBarDescription")]
    public class GradientSplitBar : GradientPanel
    {
        /// <summary>
        /// Occurs when the BumpCount property changes.
        /// </summary>
        [ResourceDescriptionAttribute("BumpCountChangedDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameBumpCountChanged")]
        public event EventHandler BumpCountChanged;

        /// <summary>
        /// Occurs when the Direction property changes.
        /// </summary>
        [ResourceDescriptionAttribute("DirectionChangedDescription"), ResourceCategoryAttribute("PropertyChangedCategory"), ResourceDisplayName("DisplayNameDirectionChanged")]
        public event EventHandler DirectionChanged;

        /// <summary>
        /// Specifies the number of bumps to be drawn on the split bar.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Negative numbers will be converted to 0. If a bump count number is greater than the surface allows, only the amount that can be drawn will be drawn.
        /// </para>
        /// </remarks>
        /// <value>
        /// <para>
        /// System.Int32
        /// </para>
        /// <para>
        /// This property is read/write.
        /// </para>
        /// </value>
        [DescriptionAttribute("BumpCountDescription"), CategoryAttribute("Appearance"), ResourceDisplayName("DisplayNameBumpCount"), DefaultValueAttribute(9), BrowsableAttribute(true)]
        public int BumpCount
        {
            get
            {
                return ((GradientSplitBarRender)base.GradientRender).BumpCount;

            }

            set
            {
                if (value < 0) value = 0;

                if (value == ((GradientSplitBarRender)base.GradientRender).BumpCount)
                {
                    return;

                }

                ((GradientSplitBarRender)base.GradientRender).BumpCount = value;

                base.Invalidate();

                this.OnBumpCountChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Specifies the direction the split bar should be drawn.
        /// </summary>
        /// <value>
        /// <para>
        /// GradientSplitBarDirection
        /// </para>
        /// <para>
        /// This property is read/write.
        /// </para>
        /// </value>
        [DescriptionAttribute("GradientSplitBarDirectionDescription"), CategoryAttribute("Appearance"), ResourceDisplayName("DisplayNameDirection"), DefaultValueAttribute(GradientSplitBarDirection.Horizontal), BrowsableAttribute(true)]
        public GradientSplitBarDirection Direction
        {
            get
            {
                return ((GradientSplitBarRender)base.GradientRender).Direction;

            }

            set
            {
                if (value == ((GradientSplitBarRender)base.GradientRender).Direction) return;

                ((GradientSplitBarRender)base.GradientRender).Direction = value;

                if (((GradientSplitBarRender)base.GradientRender).Direction == GradientSplitBarDirection.Horizontal)
                {
                    if (this.DesignMode)
                    {
                        int saveHeight = this.Height;

                        this.Height = 6;
                        this.Width = saveHeight;

                    }

                    base.GradientRender.GradientMode = LinearGradientMode.Vertical;
                    this.Cursor = Cursors.HSplit;

                }
                else
                {
                    if (this.DesignMode)
                    {
                        int saveWidth = this.Width;

                        this.Width = 6;
                        this.Height = saveWidth;

                    }

                    base.GradientRender.GradientMode = LinearGradientMode.Horizontal;
                    this.Cursor = Cursors.VSplit;

                }

                base.Invalidate();

                this.OnDirectionChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Gets the default size of the control.
        /// </summary>
        /// <value>
        /// The default Size of the control.
        /// </value>
        protected override System.Drawing.Size DefaultSize
        {
            get
            {
                return new Size(151, 6);

            }

        }

        /// <summary>
        /// Initializes a new instance of the GradientSplitBar class.
        /// </summary>
        public GradientSplitBar() : base()
        {
        }

        /// <summary>
        /// Initializes the class used for rendering. 
        /// Rendering class must be based on IGradientReder.
        /// </summary>
        protected override void InitializeRender()
        {
            base.GradientRender = new GradientSplitBarRender();

        }

        /// <summary>
        /// Fires the event indicating that the control bump count has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnBumpCountChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnBumpCountChanged(EventArgs e)
        {
            if (this.BumpCountChanged != null)
            {
                this.BumpCountChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that the control direction has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnDirectionChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnDirectionChanged(EventArgs e)
        {
            if (this.DirectionChanged != null)
            {
                this.DirectionChanged(this, e);

            }

        }

    }

}
