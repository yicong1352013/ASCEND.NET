/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Drawing.Design;
using System.Text;
using System.ComponentModel;
using System.Security;
using System.Security.Permissions;
using System.Drawing;
using System.Drawing.Drawing2D;
using Ascend.Resources;
using System.Windows.Forms;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// User interface (UI) for representing and editing the values of objects of the supported data types in a footer.
    /// </summary>
    [TypeConverterAttribute(typeof(NavigationPanePageFooterConverter))]
    [PermissionSet(SecurityAction.LinkDemand, Name = "FullTrust")]
    [PermissionSet(SecurityAction.InheritanceDemand, Name = "FullTrust")]
    public class NavigationPanePageFooterProperty : UITypeEditor
    {
        private NavigationPanePage _navigationPanePage;

        /// <summary>
        /// Gets or sets the parent NavigationPanePage.
        /// </summary>
        [Browsable(false)]
        public NavigationPanePage NavigationPanePage
        {
            get
            {
                return this._navigationPanePage;

            }

            set
            {
                this._navigationPanePage = value;

            }

        }

        /// <summary>
        /// The image associated with this control's button when minimized.
        /// </summary>
        /// <value>
        /// 	<para>
        /// System.Drawing.Image . The image associated with this control's button when minimized.
        /// </para>
        /// 	<para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        [ResourceDescriptionAttribute("ImageDescription"), ResourceCategoryAttribute("AppearanceCategory"), ResourceDisplayName("DisplayNameImage"), RefreshProperties(RefreshProperties.Repaint), DefaultValueAttribute(typeof(Image), "(none)")]
        public Image Image
        {
            get
            {
                return this._navigationPanePage.ImageFooter;

            }

            set
            {
                this._navigationPanePage.ImageFooter = value;

            }

        }

        /// <summary>
        /// Gets or sets the image list index value of the image displayed on the control's button when minimized. 
        /// </summary>
        [RefreshProperties(RefreshProperties.Repaint), ResourceCategoryAttribute("AppearanceCategory"), ResourceDisplayName("DisplayNameImageIndex"), TypeConverter(typeof(ImageIndexConverter)), Editor("System.Windows.Forms.Design.ImageIndexEditor, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor)), Localizable(true), ResourceDescriptionAttribute("ImageIndexDescription"), DefaultValue(-1)]
        public int ImageIndex
        {
            get
            {
                return this._navigationPanePage.ImageIndexFooter;

            }

            set
            {
                this._navigationPanePage.ImageIndexFooter = value;

            }

        }

        /// <summary>
        /// Gets or sets the image key associated with the page's button when minimized.
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDisplayName("DisplayNameImageKey"), TypeConverter(typeof(ImageKeyConverter)), Editor("System.Windows.Forms.Design.ImageIndexEditor, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor)), Localizable(true), DefaultValue(""), RefreshProperties(RefreshProperties.Repaint), ResourceDescriptionAttribute("ImageIndexDescription")]
        public string ImageKey
        {
            get
            {
                return this._navigationPanePage.ImageKeyFooter;

            }

            set
            {
                this._navigationPanePage.ImageKeyFooter = value;

            }

        }

        /// <summary>
        /// Gets or sets the ImageList that contains the Image displayed on the button of the control when minimized. 
        /// </summary>
        [ResourceCategoryAttribute("AppearanceCategory"), ResourceDescriptionAttribute("ImageListDescription"), ResourceDisplayName("DisplayNameImageList"), RefreshProperties(RefreshProperties.Repaint), DefaultValueAttribute(typeof(ImageList), "(none)")]
        public ImageList ImageList
        {
            get
            {
                return this._navigationPanePage.ImageListFooter;

            }

            set
            {
                this._navigationPanePage.ImageListFooter = value;

            }

        }

        /// <summary>
        /// Gets a value indicating whether drop-down editors should be resizable by the user.
        /// </summary>
        [Browsable(false)]
        public override bool IsDropDownResizable
        {
            get
            {
                return false;

            }

        }
        
        /// <summary>
        /// Initializes a new instance of the NavigationPanePageFooterProperty class.
        /// </summary>
        /// <param name="navigationPanePage">The NavigationPanePage control to add the property values to.</param>
        public NavigationPanePageFooterProperty(NavigationPanePage navigationPanePage)
        {
            this._navigationPanePage = navigationPanePage;

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPanePageFooterProperty class.
        /// </summary>
        /// <param name="navigationPanePage">The NavigationPanePage control to add the property values to.</param>
        /// <param name="imageKey">The image key to use.</param>
        /// <param name="imageIndex">The image index to use.</param>
        public NavigationPanePageFooterProperty(NavigationPanePage navigationPanePage, string imageKey, int imageIndex)
        {
            this._navigationPanePage = navigationPanePage;

            this.ImageKey = imageKey;
            this.ImageIndex = imageIndex;

        }


    }

}
