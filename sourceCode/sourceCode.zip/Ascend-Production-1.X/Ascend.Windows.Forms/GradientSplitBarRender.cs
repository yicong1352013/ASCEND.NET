/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing.Drawing2D;
using System.Drawing;

namespace Ascend.Windows.Forms
{
    /// <summary>
    /// Represents a split bar control with a gradient background.
    /// </summary>
    public class GradientSplitBarRender : GradientBackgroundRender
    {
        private int _bumpCount = 9;
        private GradientSplitBarDirection _direction = GradientSplitBarDirection.Horizontal;

        /// <summary>
        /// Occurs when the Direction property changes.
        /// </summary>
        public event EventHandler DirectionChanged;

        /// <summary>
        /// Occurs when the BumpCount property changes.
        /// </summary>
        public event EventHandler BumpCountChanged;

        /// <summary>
        /// Initializes a new instance of the GradientSplitBarRender class.
        /// </summary>
        public GradientSplitBarRender() : base()
        {
            base.GradientHighColor = SystemColors.GradientActiveCaption;
            base.GradientLowColor = SystemColors.ActiveCaption;
            this.GradientMode = LinearGradientMode.Vertical;

        }

        /// <summary>
        /// Specifies the direction the split bar should be drawn.
        /// </summary>
        /// <value>
        /// 	<para>
        /// GradientSplitBarDirection
        /// </para>
        /// 	<para>
        /// This property is read/write.
        /// </para>
        /// </value>
        public GradientSplitBarDirection Direction
        {
            get
            {
                return this._direction;

            }

            set
            {
                if (value == this._direction) return;

                this._direction = value;

                if (this._direction == GradientSplitBarDirection.Horizontal)
                {
                    this.GradientMode = LinearGradientMode.Vertical;

                }
                else
                {
                    this.GradientMode = LinearGradientMode.Horizontal;

                }

                this.OnDirectionChanged(new EventArgs());

            }

        }

        /// <summary>
        /// Specifies the number of bumps to be drawn on the split bar.
        /// </summary>
        /// <remarks>
        /// 	<para>
        /// Negative numbers will be converted to 0. If a bump count number is greater than the surface allows, only the amount that can be drawn will be drawn.
        /// </para>
        /// </remarks>
        /// <value>
        /// 	<para>
        /// System.Int32
        /// </para>
        /// 	<para>
        /// This property is read/write.
        /// </para>
        /// </value>
        public int BumpCount
        {
            get
            {
                return this._bumpCount;

            }

            set
            {
                if (value < 0) value = 0;

                if (value == this._bumpCount)
                {
                    return;

                }

                this._bumpCount = value;

                this.OnBumpCountChanged(new EventArgs());

            }

        }

        private void DrawBumps(System.Windows.Forms.PaintEventArgs e)
        {
            if (this.DisplayRectangle.Width > 0 && this.DisplayRectangle.Height > 0)
            {
                Pen darkDarkPen = new Pen(new SolidBrush(SystemColors.ControlDarkDark), 2);
                try
                {
                    Pen lightLightPen = new Pen(new SolidBrush(SystemColors.ControlLightLight), 2);
                    try
                    {
                        Pen lightPen = new Pen(new SolidBrush(SystemColors.ControlLight), 1);
                        try
                        {
                            if (this._direction == GradientSplitBarDirection.Horizontal)
                            {
                                int x = ((this.DisplayRectangle.Width / 2) - (this._bumpCount * 2));
                                int y = (this.DisplayRectangle.Top + 2 + this.Border.Top);
                                for (int i = 0; i < this._bumpCount; i++)
                                {
                                    e.Graphics.DrawLine(darkDarkPen, x, y, (x + 2), y);
                                    e.Graphics.DrawLine(lightLightPen, (x + 1), (y + 1), x + 3, (y + 1));
                                    e.Graphics.DrawLine(lightPen, (x + 1), (y + 1), (x + 1), (y + 1));

                                    x += 4;

                                }

                            }
                            else
                            {
                                int x = (this.DisplayRectangle.Left + 2 + this.Border.Left);
                                int y = ((this.DisplayRectangle.Height / 2) - (this._bumpCount * 2));
                                for (int i = 0; i < this._bumpCount; i++)
                                {
                                    e.Graphics.DrawLine(darkDarkPen, x, y, x, y + 2);
                                    e.Graphics.DrawLine(lightLightPen, (x + 1), (y + 1), (x + 1), y + 3);
                                    e.Graphics.DrawLine(lightPen, (x + 1), (y + 1), (x + 1), (y + 1));

                                    y += 4;

                                }

                            }

                        }
                        catch
                        {
                            throw;

                        }
                        finally
                        {
                            lightPen.Dispose();

                        }

                    }
                    catch
                    {
                        throw;

                    }
                    finally
                    {
                        lightLightPen.Dispose();

                    }

                }
                catch
                {
                    throw;

                }
                finally
                {
                    darkDarkPen.Dispose();

                }

            }

        }

        /// <summary>
        /// Fires the event indicating that the control direction has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnDirectionChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnDirectionChanged(EventArgs e)
        {
            if (this.DirectionChanged != null)
            {
                this.DirectionChanged(this, e);

            }

        }

        /// <summary>
        /// Fires the event indicating that the control bump count has changed.  Inheriting controls should use this in favour of actually listening to the event, but should not forget to call base.OnBumpCountChanged() to ensure that the event is still fired for external listeners.
        /// </summary>
        /// <param name="e">A System.EventArgs that contains the event data.</param>
        protected void OnBumpCountChanged(EventArgs e)
        {
            if (this.BumpCountChanged != null)
            {
                this.BumpCountChanged(this, e);

            }

        }

        /// <summary>
        /// Draws the bumps of the control.
        /// </summary>
        /// <param name="e">A System.Windows.Forms.PaintEventArgs that contains the event data.</param>
        public override void Render(System.Windows.Forms.PaintEventArgs e)
        {
            base.Render(e);
            this.DrawBumps(e);

        }

    }

}
