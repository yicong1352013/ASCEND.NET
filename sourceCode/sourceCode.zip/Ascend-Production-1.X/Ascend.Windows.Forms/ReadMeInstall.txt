
10/8/2006: RTM version 1.0.0.6

To install the tools just run Ascend.Install.msi and follow the prompts. Visual Studio should be closed while installing.

If you have been using an earlier version keep in mind that you will need to update your project references to point to the Ascend assemblies version 1.0.0.6 .

There are no known breaking changes between RC 1 and this release.

Please let me know of any problems you may have at http://www.codeplex.com/Project/ListForums.aspx?ProjectName=ASCENDNET . We hate tools that cause us extra work because of bugs and I don�t want to be in that group but we all know how hard it is to write the �perfect� application. If you just want to tell us how good the tools are I would take that also. <smile>

Thanks,
Ascend.Net Team