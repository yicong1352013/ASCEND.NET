using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms.Design.Behavior;

namespace Ascend.Windows.Forms.Design
{
    /// <summary>
    /// 
    /// </summary>
    public class NavigationPaneBehavior : Behavior
    {
        /// <param name="g">A <see cref="T:System.Windows.Forms.Design.Behavior.Glyph"></see>.</param>
        /// <param name="button">A <see cref="T:System.Windows.Forms.MouseButtons"></see> value indicating which button was clicked.</param>
        /// <returns>true if the message was handled; otherwise, false.</returns>
        public override bool OnMouseUp(System.Windows.Forms.Design.Behavior.Glyph g, System.Windows.Forms.MouseButtons button)
        {
            if (button == System.Windows.Forms.MouseButtons.Left)
            {
                
            }

            return base.OnMouseUp(g, button);

        }

    }

}
