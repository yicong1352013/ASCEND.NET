/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace Ascend.Windows.Forms.Design
{
    /// <summary>
    /// Designer class for extending the design mode behavior of a NavigationPanePage which should receive scroll messages.
    /// </summary>
    public class NavigationPanePageDesigner : ParentControlDesigner
    {
        private DesignerActionListCollection _actionLists;

        /// <summary>
        /// Gets the design-time action lists supported by the component associated with the designer.
        /// </summary>
        /// <value>
        /// The design-time action lists supported by the component associated with the designer. 
        /// </value>
        public override DesignerActionListCollection ActionLists
        {
            get
            {
                if (this._actionLists == null)
                {
                    this._actionLists = new DesignerActionListCollection();
                    this._actionLists.Add(new NavigationPanePageActionList((NavigationPanePage)Control));

                }

                return this._actionLists;

            }

        }

        /// <summary>
        /// Initializes a new instance of the NavigationPanePageDesigner class.
        /// </summary>
        public NavigationPanePageDesigner() : base()
        {
        }

        /// <summary>
        /// Gets the pen used to draw the design border 
        /// </summary>
        private Pen BorderPen
        {
            get
            {
                Color color = (this.Control.BackColor.GetBrightness() < 0.5) ? ControlPaint.Light(this.Control.BackColor) : ControlPaint.Dark(this.Control.BackColor);
                Pen pen = new Pen(color);
                pen.DashStyle = DashStyle.Dash;

                return pen;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        public override System.Windows.Forms.Design.SelectionRules SelectionRules
        {
            get
            {
                return SelectionRules.Locked;

            }

        }

        /// <summary>
        /// Receives a call when the control that the designer is managing has painted its surface so the designer can paint any additional adornments on top of the control. 
        /// </summary>
        /// <param name="pe">A PaintEventArgs the designer can use to draw on the control.</param>
        protected override void OnPaintAdornments(System.Windows.Forms.PaintEventArgs pe)
        {
            base.OnPaintAdornments(pe);

            this.DrawBorder(pe.Graphics);

        }

        /// <summary>
        /// Draws a dashed border around control at design time.
        /// </summary>
        /// <param name="graphics">The graphics object to use</param>
        protected virtual void DrawBorder(Graphics graphics)
        {
            NavigationPanePage panel = (NavigationPanePage)base.Component;

            if ((panel == null) || !panel.Visible)
            {
                return;

            }

            Pen pen = this.BorderPen;
            try
            {
                Rectangle rectangle = this.Control.ClientRectangle;
                if (this.Control.RightToLeft == RightToLeft.Yes)
                {
                    rectangle.X++;
                    rectangle.Width--;

                }

                rectangle.Width--;
                rectangle.Height--;
                graphics.DrawRectangle(pen, rectangle);

            }
            catch
            {
                throw;

            }
            finally
            {
                pen.Dispose();

            }

        }

        /// <summary>
        /// Allows a designer to change or remove items from the set of properties that it exposes through a TypeDescriptor.
        /// </summary>
        /// <param name="properties">The properties for the class of the component.</param>
        protected override void PostFilterProperties(System.Collections.IDictionary properties)
        {
            properties.Remove("Anchor");
            properties.Remove("Dock");
            properties.Remove("Margin");
            properties.Remove("MaximumSize");
            properties.Remove("MinimumSize");

            base.PostFilterProperties(properties);

        }

        /// <summary>
        /// Allows a designer to change or remove items from the set of events that it exposes through a TypeDescriptor.
        /// </summary>
        /// <param name="events">The events for the class of the component.</param>
        protected override void PostFilterEvents(System.Collections.IDictionary events)
        {
            events.Remove("DockChanged");
            events.Remove("LocationChanged");
            events.Remove("ParentChanged");

            base.PostFilterEvents(events);

        }

    }

}
