/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Drawing;
using System.Security.Permissions;
using System.Text;
using System.Windows.Forms.Design;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Ascend.Windows.Forms.Design
{
    /// <summary>
    /// Extends the design mode behavior of the GradientBackground.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ParentControlDesigner provides a base class for designers of components that derive from ParentControlDesigner. In addition to the methods and functionality inherited from the ComponentDesigner class, ParentControlDesigner provides additional methods to support extending and altering the behavior of an associated Control at design time.
    /// </para>
    /// <para>
    /// You can associate a designer with a type using a DesignerAttribute. For an overview of customizing design time behavior.
    /// </para>
    /// </remarks>
    public class GradientPanelDesigner : ParentControlDesigner
    {
        private DesignerActionListCollection _actionLists;

        /// <summary>
        /// Gets the pen used to draw the design border 
        /// </summary>
        protected Pen BorderPen
        {
            get
            {
                Color color = (((GradientPanel)this.Control).GradientLowColor.GetBrightness() < 0.5) ? ControlPaint.Light(((GradientPanel)this.Control).GradientLowColor) : ControlPaint.Dark(((GradientPanel)this.Control).GradientLowColor);
                Pen pen = new Pen(color);
                pen.DashStyle = DashStyle.Dash;

                return pen;

            }

        }

        /// <summary>
        /// Gets the design-time action lists supported by the component associated with the designer.
        /// </summary>
        /// <value>
        /// The design-time action lists supported by the component associated with the designer. 
        /// </value>
        public override DesignerActionListCollection ActionLists
        {
            get
            {
                if (this._actionLists == null)
                {
                    this._actionLists = new DesignerActionListCollection();
                    this._actionLists.Add(new GradientPanelActionList((GradientPanel)Control));

                }

                return this._actionLists;

            }

        }

        /// <summary>
        /// Receives a call when the control that the designer is managing has painted its surface so the designer can paint any additional adornments on top of the control. 
        /// </summary>
        /// <param name="pe">A PaintEventArgs the designer can use to draw on the control.</param>
        protected override void OnPaintAdornments(PaintEventArgs pe)
        {
            this.DrawBorder(pe.Graphics);

            base.OnPaintAdornments(pe);

        }

        /// <summary>
        /// Allows a designer to change or remove items from the set of properties that it exposes through a TypeDescriptor. 
        /// </summary>
        /// <param name="properties">The properties for the class of the component.</param>
        protected override void PostFilterProperties(System.Collections.IDictionary properties)
        {
            properties.Remove("BackColor");
            properties.Remove("BackgroundImage");
            properties.Remove("BackgroundImageLayout");
            properties.Remove("Text");

        }

        /// <summary>
        /// Allows a designer to change or remove items from the set of events that it exposes through a TypeDescriptor.
        /// </summary>
        /// <param name="events">The events for the class of the component.</param>
        protected override void PostFilterEvents(System.Collections.IDictionary events)
        {
            events.Remove("BackColorChanged");
            events.Remove("BackgroundImageChanged");
            events.Remove("BackgroundImageLayoutChanged");
            events.Remove("TextChanged");

        }

        /// <summary>
        /// Draws a dashed border around control at design time.
        /// </summary>
        /// <param name="graphics">The graphics object to use</param>
        protected virtual void DrawBorder(Graphics graphics)
        {
            GradientPanel gradientPanel = (GradientPanel)base.Component;

            if ((gradientPanel == null) || !gradientPanel.Visible) return;

            Pen pen = this.BorderPen;
            try
            {
                Rectangle rectangle = this.Control.ClientRectangle;
                if (this.Control.RightToLeft == RightToLeft.Yes)
                {
                    rectangle.X++;
                    rectangle.Width--;

                }

                rectangle.Width--;
                rectangle.Height--;
                graphics.DrawRectangle(pen, rectangle);

            }
            catch
            {
                throw;

            }
            finally
            {
                pen.Dispose();

            }

        }

    }

}
