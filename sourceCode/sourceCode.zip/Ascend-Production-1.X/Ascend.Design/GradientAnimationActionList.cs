/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using Ascend.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

namespace Ascend.Windows.Forms.Design
{
    /// <summary>
    /// Provides the base class for types that define a list of items used to create a DesignerActionPanel.
    /// </summary>
    public class GradientAnimationActionList : DesignerActionList
    {
        private GradientAnimation _gradientAnimation;

        /// <summary>
        /// Initializes a new instance of the GradientAnimationActionList class.
        /// </summary>
        /// <param name="gradientAnimation">A GradientAnimation component.</param>
        public GradientAnimationActionList(GradientAnimation gradientAnimation) : base(gradientAnimation)
        {
            this._gradientAnimation = gradientAnimation;

        }

        /// <summary>
        /// Specifies the position and manner in which a control is docked.
        /// </summary>
        /// <remarks>
        /// <para>
        /// When a control is docked to an edge of its container, it is always positioned flush against that edge when the container is resized. If more than one control is docked to an edge, the controls appear side by side according to their z-order; controls higher in the z-order are positioned farther from the container's edge.
        /// </para>
        /// <para>
        /// If Left, Right, Top, or Bottom is selected, the specified and opposite edges of the control are resized to the size of the containing control's corresponding edges. If Fill is selected, all four sides of the control are resized to match the containing control's edges.
        /// </para>
        /// </remarks>
        /// <value>
        /// <para>
        /// System.Windows.Forms.DockStyle
        /// </para>
        /// <para>
        /// This property is read/write.
        /// </para>
        /// </value>
        public DockStyle Dock
        {
            get
            {
                return this._gradientAnimation.Dock;

            }
            set
            {
                this.GetPropertyByName("Dock").SetValue(this._gradientAnimation, value);

            }
        }

        /// <summary>
        /// Gets or sets the gradient high (lighter) color for the control.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient high color of the control.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public Color GradientHighColor
        {
            get
            {
                return this._gradientAnimation.GradientHighColor;

            }

            set
            {
                this.GetPropertyByName("GradientHighColor").SetValue(this._gradientAnimation, value);

            }

        }

        /// <summary>
        /// Gets or sets the gradient low (darker) color for the control.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Color . A Color that represents the gradient low color of the control.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public Color GradientLowColor
        {
            get
            {
                return this._gradientAnimation.GradientLowColor;

            }

            set
            {
                this.GetPropertyByName("GradientLowColor").SetValue(this._gradientAnimation, value);

            }

        }

        /// <summary>
        /// Specifies the direction of a linear gradient.
        /// </summary>
        /// <value>
        /// <para>
        /// System.Drawing.Drawing2D.LinearGradientMode . Specifies the direction of a linear gradient.
        /// </para>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public LinearGradientMode GradientMode
        {
            get
            {
                return this._gradientAnimation.GradientMode;

            }

            set
            {
                this.GetPropertyByName("GradientMode").SetValue(this._gradientAnimation, value);

            }

        }

        /// <summary>
        /// Gets or sets the name of the control.
        /// </summary>
        /// <value>
        /// <para>
        /// This property is read/write. 
        /// </para>
        /// </value>
        public string Name
        {
            get
            {
                return this._gradientAnimation.Name;

            }

            set
            {
                this.GetPropertyByName("Name").SetValue(this._gradientAnimation, value);

            }

        }

        private PropertyDescriptor GetPropertyByName(string propertyName)
        {
            PropertyDescriptor propertyDescriptor;

            propertyDescriptor = TypeDescriptor.GetProperties(this._gradientAnimation)[propertyName];

            if (propertyDescriptor == null)
            {
                throw new ArgumentException(ResourceText.GetLocalizedString("GAPropertyNotFoundExceptionText"));

            }
            else
            {
                return propertyDescriptor;

            }

        }

        /// <summary>
        /// Returns the collection of DesignerActionItem objects contained in the list. 
        /// </summary>
        /// <returns>A DesignerActionItem array that contains the items in this list.</returns>
        public override DesignerActionItemCollection GetSortedActionItems()
        {
            DesignerActionItemCollection items = new DesignerActionItemCollection();

            items.Add(new DesignerActionPropertyItem("Name", ResourceText.GetLocalizedString("ActionListDisplayNameName"), "Design", ResourceText.GetLocalizedString("NameDescription")));

            items.Add(new DesignerActionHeaderItem(ResourceText.GetLocalizedString("ActionListAppearanceCategory"), "Appearance"));
            items.Add(new DesignerActionTextItem(ResourceText.GetLocalizedString("ActionListAppearanceTextItem"), "Appearance"));
            items.Add(new DesignerActionPropertyItem("GradientHighColor", ResourceText.GetLocalizedString("ActionListDisplayNameGradientHighColor"), "Appearance", ResourceText.GetLocalizedString("GradientHighColorDescription")));
            items.Add(new DesignerActionPropertyItem("GradientLowColor", ResourceText.GetLocalizedString("ActionListDisplayNameGradientLowColor"), "Appearance", ResourceText.GetLocalizedString("GradientLowColorDescription")));
            items.Add(new DesignerActionPropertyItem("GradientMode", ResourceText.GetLocalizedString("ActionListDisplayNameGradientMode"), "Appearance", ResourceText.GetLocalizedString("GradientModeDescription")));

            items.Add(new DesignerActionHeaderItem(ResourceText.GetLocalizedString("ActionListLayoutCategory"), "Layout"));
            items.Add(new DesignerActionTextItem(ResourceText.GetLocalizedString("ActionListLayoutTextItem"), "Layout"));
            items.Add(new DesignerActionPropertyItem("Dock", ResourceText.GetLocalizedString("ActionListDisplayNameDock"), "Layout", ResourceText.GetLocalizedString("DockedDescription")));

            return items;

        }

    }

}
