using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Windows.Forms;
using System.Diagnostics;

namespace Ascend.ToolboxControlInstaller
{
    [RunInstaller(true)]
    public partial class ToolboxInstaller : Installer
    {
        private string _installPath = string.Empty;

        public ToolboxInstaller()
        {
            InitializeComponent();

        }

        /// <param name="stateSaver">An <see cref="T:System.Collections.IDictionary"></see> used to save information needed to perform a commit, rollback, or uninstall operation.</param>
        public override void Install(System.Collections.IDictionary stateSaver)
        {
            base.Install(stateSaver);

        }

        /// <param name="savedState">An <see cref="T:System.Collections.IDictionary"></see> that contains the state of the computer after all the installers in the collection have run.</param>
        public override void Commit(System.Collections.IDictionary savedState)
        {
            base.Commit(savedState);

            if (this.Context.Parameters["ShouldDo"] == "2")
            {
                this._installPath = this.Context.Parameters["InPath"];

                PackageToolbox packageToolbox = new PackageToolbox(this._installPath);
                //packageToolbox.

                

            }

        }

    }

}