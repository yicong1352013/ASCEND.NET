/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;
using System;
using System.Collections.Generic;
using System.Drawing.Design;
using System.Text;
using System.Reflection;
using System.Runtime.InteropServices;

using MsVsShell = Microsoft.VisualStudio.Shell;

namespace Ascend.ToolboxControlInstaller
{
    /// <summary>
    /// This package provides code for adding ToolboxItems to the Visual Studio 2005 toolbox.
    /// </summary>
    [MsVsShell.ProvideLoadKey("standard", "1.0", "\"Ascend.NET\" Windows Forms Controls", "Ascend.Net Project", 150)]
    [MsVsShell.InstalledProductRegistration(true, null, null, null)]
    [MsVsShell.DefaultRegistryRoot(@"Software\Microsoft\VisualStudio\8.0")]
    [Guid("D6832E72-5699-4bc2-A21D-931E54C94EEF")]
    [MsVsShell.PackageRegistration(UseManagedResourcesOnly = true)]
    [ProvideToolboxItems(2)]
    public class PackageToolbox : MsVsShell.Package, IVsInstalledProduct
    {
        private string _ascendAssemblyPath = string.Empty;

        /// <summary>
        /// Inializes a new instance of the PackageToolbox class.
        /// </summary>
        /// <param name="AscendAssemblyPath">The install path.</param>
        public PackageToolbox(string AscendAssemblyPath)
        {
            StringBuilder path = new StringBuilder();
            path.Append(AscendAssemblyPath);
            path.Append("Ascend.Windows.Forms.dll");

            this._ascendAssemblyPath = path.ToString();

            this.ToolboxInitialized += new EventHandler(this.PackageToolbox_ToolboxInitialized);
            this.ToolboxUpgraded += new EventHandler(this.PackageToolbox_ToolboxUpgraded);
  
        }

        /// <summary>
        /// This method is called when the "counter" is incremented.  This tell Visual Studio that items may have changed and need to be reinstalled.
        /// </summary>
        void PackageToolbox_ToolboxUpgraded(object sender, EventArgs e)
        {
            this.RemoveToolboxItems();
            this.InstallToolboxItems();

        }

        /// <summary>
        /// This method will add items to the toolbox.
        /// </summary>
        void PackageToolbox_ToolboxInitialized(object sender, EventArgs e)
        {
            this.InstallToolboxItems();

        }

        /// <summary>
        /// Removes tool box items
        /// </summary>
        void RemoveToolboxItems()
        {
            AssemblyName assemblyName = AssemblyName.GetAssemblyName(this._ascendAssemblyPath);

            IToolboxService tbxService = (IToolboxService)GetService(typeof(IToolboxService));

            foreach (ToolboxItem item in ToolboxService.GetToolboxItems(assemblyName))
            {
                tbxService.RemoveToolboxItem(item, "Ascend.Net");

            }

        }

        /// <summary>
        /// Installs toolbox items
        /// </summary>
        void InstallToolboxItems()
        {
            AssemblyName assemblyName = AssemblyName.GetAssemblyName(this._ascendAssemblyPath);

            IToolboxService tbxService = (IToolboxService)GetService(typeof(IToolboxService));

            foreach (ToolboxItem item in ToolboxService.GetToolboxItems(assemblyName))
            {
                tbxService.AddToolboxItem(item, "Ascend.Net");

            }

        }

        #region IVsInstalledProduct Members

        /// <summary>
        /// This method is called during Devenv /Setup to get the bitmap to
        /// display on the splash screen for this package.
        /// </summary>
        /// <param name="pIdBmp">The resource id corresponding to the bitmap to display on the splash screen</param>
        /// <returns>HRESULT, indicating success or failure</returns>
        public int IdBmpSplash(out uint pIdBmp)
        {
            pIdBmp = 300;

            return VSConstants.S_OK;

        }

        /// <summary>
        /// This method is called to get the icon that will be displayed in the
        /// Help About dialog when this package is selected.
        /// </summary>
        /// <param name="pIdIco">The resource id corresponding to the icon to display on the Help About dialog</param>
        /// <returns>HRESULT, indicating success or failure</returns>
        public int IdIcoLogoForAboutbox(out uint pIdIco)
        {
            pIdIco = 400;

            return VSConstants.S_OK;

        }

        /// <summary>
        /// This methods provides the product official name, it will be
        /// displayed in the help about dialog.
        /// </summary>
        /// <param name="pbstrName">Out parameter to which to assign the product name</param>
        /// <returns>HRESULT, indicating success or failure</returns>
        public int OfficialName(out string pbstrName)
        {
            pbstrName = GetResourceString("@100");
            return VSConstants.S_OK;

        }

        /// <summary>
        /// This methods provides the product description, it will be
        /// displayed in the help about dialog.
        /// </summary>
        /// <param name="pbstrProductDetails">Out parameter to which to assign the description of the package</param>
        /// <returns>HRESULT, indicating success or failure</returns>
        public int ProductDetails(out string pbstrProductDetails)
        {
            pbstrProductDetails = GetResourceString("@102");
            return VSConstants.S_OK;

        }

        /// <summary>
        /// This methods provides the product version, it will be
        /// displayed in the help about dialog.
        /// </summary>
        /// <param name="pbstrPID">Out parameter to which to assign the version number</param>
        /// <returns>HRESULT, indicating success or failure</returns>
        public int ProductID(out string pbstrPID)
        {
            pbstrPID = GetResourceString("@104");
            return VSConstants.S_OK;

        }

        #endregion

        /// <summary>
        /// This method loads a localized string based on the specified resource.
        /// </summary>
        /// <param name="resourceName">Resource to load</param>
        /// <returns>String loaded for the specified resource</returns>
        public string GetResourceString(string resourceName)
        {
            string resourceValue;

            IVsResourceManager resourceManager = (IVsResourceManager)GetService(typeof(SVsResourceManager));
            if (resourceManager == null)
            {
                throw new InvalidOperationException("Could not get SVsResourceManager service. Make sure the package is Sited before calling this method");

            }

            Guid packageGuid = this.GetType().GUID;
            
            int hr = resourceManager.LoadResourceString(ref packageGuid, -1, resourceName, out resourceValue);
            
            Microsoft.VisualStudio.ErrorHandler.ThrowOnFailure(hr);

            return resourceValue;

        }

    }

}
