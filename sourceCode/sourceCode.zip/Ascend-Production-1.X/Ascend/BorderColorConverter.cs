/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Drawing;
using System.Globalization;
using System.Text;
using Ascend.Resources;

namespace Ascend
{
    /// <summary>
    /// Provides a type converter to convert expandable objects to and from various other representations.
    /// </summary>
    public class BorderColorConverter : TypeConverter
    {
        /// <summary>
        /// Initializes a new instance of the BorderColorConverter class.
        /// </summary>
        public BorderColorConverter()
        {
        }

        /// <summary>
        /// Returns whether this converter can convert the object to the specified type.
        /// </summary>
        /// <remarks>
        /// Use the context parameter to extract additional information about the environment from which this converter is invoked. This parameter can be null, so always check it. Also, properties on the context object can return null.
        /// </remarks>
        /// <param name="context">An ITypeDescriptorContext that provides a format context.</param>
        /// <param name="destinationType">A Type that represents the type you want to convert to.</param>
        /// <returns>true if this converter can perform the conversion; otherwise, false.</returns>
        public override bool CanConvertTo(ITypeDescriptorContext context, System.Type destinationType)
        {
            if (destinationType == typeof(InstanceDescriptor))
            {
                return true;

            }

            return base.CanConvertTo(context, destinationType);

        }

        /// <summary>
        /// Converts the given object to the type of this converter, using the specified context and culture information. 
        /// </summary>
        /// <param name="context">An ITypeDescriptorContext that provides a format context.</param>
        /// <param name="culture">The CultureInfo to use as the current culture.</param>
        /// <param name="value">The Object to convert.</param>
        /// <returns>An Object that represents the converted value.</returns>
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            string valueString = value as string;
            if (valueString == null)
            {
                return base.ConvertFrom(context, culture, value);

            }

            valueString = valueString.Trim();
            if (valueString.Length == 0)
            {
                return null;

            }

            if (culture == null)
            {
                culture = CultureInfo.CurrentCulture;

            }

            char separator = culture.TextInfo.ListSeparator[0];
            char[] separatorArray = new char[1] { separator };
            string[] textArray = valueString.Split(separatorArray);

            for (int i = 0; i < textArray.Length; i++)
            {
                textArray[i] = textArray[i].Substring((textArray[i].LastIndexOf('[') + 1), (textArray[i].LastIndexOf(']') - (textArray[i].LastIndexOf('[') + 1)));

            }

            Color[] colorArray = new Color[textArray.Length];

            TypeConverter converter = TypeDescriptor.GetConverter(typeof(Color));
            for (int x = 0; x < colorArray.Length; x++)
            {
                colorArray[x] = (Color)converter.ConvertFromString(context, culture, textArray[x]);

            }

            if (colorArray.Length == 4)
            {
                return new BorderColor(colorArray[0], colorArray[1], colorArray[2], colorArray[3]);

            }

            throw new ArgumentException(ResourceText.GetLocalizedString("FailedParseFormatError"));

        }

        /// <summary>
        /// Converts the given value object to the specified type, using the specified context and culture information.
        /// </summary>
        /// <remarks>
        /// <para>The most common types to convert are to and from a string object. This implementation calls ToString on the object if the object is valid and if the destination type is string.</para>
        /// <para>Use the context parameter to extract additional information about the environment from which this converter is invoked. This parameter can be null, so always check it. Also, properties on the context object can return null.</para>
        /// </remarks>
        /// <param name="context">An ITypeDescriptorContext that provides a format context.</param>
        /// <param name="culture">A CultureInfo object. If null is passed, the current culture is assumed.</param>
        /// <param name="value">The Object to convert.</param>
        /// <param name="destinationType">The Type to convert the value parameter to.</param>
        /// <returns>An Object that represents the converted value.</returns>
        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, System.Type destinationType)
        {
            if (destinationType == null)
            {
                throw new ArgumentNullException("destinationType");

            }

            if ((destinationType != typeof(InstanceDescriptor)) || !(value is BorderColor))
            {
                return base.ConvertTo(context, culture, value, destinationType);

            }

            BorderColor borderColor = (BorderColor)value;

            if (borderColor.ShouldSerializeAll())
            {
                Type[] typeArray = new Type[1] { typeof(Color) };
                object[] objArray = new object[1] { borderColor.All };
                return new InstanceDescriptor(typeof(BorderColor).GetConstructor(typeArray), objArray);

            }

            Type[] typeArray2 = new Type[4] { typeof(Color), typeof(Color), typeof(Color), typeof(Color) };
            object[] objArray2 = new object[4] { borderColor.Left, borderColor.Top, borderColor.Right, borderColor.Bottom };
            return new InstanceDescriptor(typeof(BorderColor).GetConstructor(typeArray2), objArray2);

        }

        /// <summary>
        /// Creates an instance of the Type that this TypeConverter is associated with, using the specified context, given a set of property values for the object.
        /// </summary>
        /// <param name="context">An ITypeDescriptorContext that provides a format context.</param>
        /// <param name="propertyValues">An System.Collections.IDictionary of new property values.</param>
        /// <returns>An System.Object representing the given System.Collections.IDictionary, or null if the object cannot be created. This method always returns null.</returns>
        public override System.Object CreateInstance(System.ComponentModel.ITypeDescriptorContext context, System.Collections.IDictionary propertyValues)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context");

            }

            if (propertyValues == null)
            {
                throw new ArgumentNullException("propertyValues");

            }

            BorderColor borderColor = (BorderColor)context.PropertyDescriptor.GetValue(context.Instance);
            Color colorAll = (Color)propertyValues["All"];
            if (borderColor.All != colorAll)
            {
                return new BorderColor(colorAll);

            }

            return new BorderColor((Color)propertyValues["Left"], (Color)propertyValues["Top"], (Color)propertyValues["Right"], (Color)propertyValues["Bottom"]);

        }

        /// <param name="context">An System.ComponentModel.ITypeDescriptorContext that provides a format context.</param>
        /// <returns>true if changing a property on this object requires a call to System.ComponentModel.TypeConverter.CreateInstance(System.Collections.IDictionary) to create a new value; otherwise, false.</returns>
        public override System.Boolean GetCreateInstanceSupported(System.ComponentModel.ITypeDescriptorContext context)
        {
            return true;

        }

        /// <summary>
        /// Retrieves the set of properties for this type. By default, a type does not have any properties to return. An easy implementation of this method can call the TypeDescriptor.GetProperties method for the correct data type. 
        /// </summary>
        /// <param name="context">An System.ComponentModel.ITypeDescriptorContext that provides a format context.</param>
        /// <param name="value">The value of the object to get the properties for.</param>
        /// <param name="attributes">An array of MemberAttribute objects that describe the properties.</param>
        /// <returns>A System.ComponentModel.PropertyDescriptorCollection with the properties that are exposed for this data type, or null if there are no properties.</returns>
        public override System.ComponentModel.PropertyDescriptorCollection GetProperties(System.ComponentModel.ITypeDescriptorContext context, System.Object value, System.Attribute[] attributes)
        {
            PropertyDescriptorCollection propertyDescriptorCollection = TypeDescriptor.GetProperties(typeof(BorderColor), attributes);
            string[] textArray = new string[5] { "All", "Left", "Top", "Right", "Bottom" };
            return propertyDescriptorCollection.Sort(textArray);

        }

        /// <param name="context">An System.ComponentModel.ITypeDescriptorContext that provides a format context.</param>
        /// <returns>true if System.ComponentModel.TypeConverter.GetProperties(System.Object) should be called to find the properties of this object; otherwise, false.</returns>
        public override System.Boolean GetPropertiesSupported(System.ComponentModel.ITypeDescriptorContext context)
        {
            return true;

        }

    }

}
