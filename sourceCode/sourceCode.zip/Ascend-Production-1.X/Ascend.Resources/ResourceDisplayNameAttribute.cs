/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.ComponentModel;
using System.Reflection;

namespace Ascend.Resources
{
    /// <summary>
    /// Specifies the display name for a property, event, or public void method which takes no arguments. 
    /// </summary>
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = true)]
    public sealed class ResourceDisplayNameAttribute : DisplayNameAttribute
    {
        private bool _localized;

        /// <summary>
        /// Gets the display name for a property, event, or public void method that takes no arguments stored in this attribute.
        /// </summary>
        public override string DisplayName
        {
            get
            {
                if (!this._localized)
                {
                    this._localized = true;

                    System.Resources.ResourceManager resourceManager = new System.Resources.ResourceManager("Ascend.Resources.DefaultResource", Assembly.GetExecutingAssembly()); ;
                    this.DisplayNameValue = resourceManager.GetString(this.DisplayNameValue);

                }


                return base.DisplayName;

            }

        }

        /// <summary>
        /// Initializes a new instance of the ResourceDisplayNameAttribute class.
        /// </summary>
        /// <param name="displayName">The resouce name.</param>
        public ResourceDisplayNameAttribute(string displayName) : base(displayName)
        {
        }

    }

}
