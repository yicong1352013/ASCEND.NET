/* **********************************************************************************
 *
 * Copyright (c) Ascend.NET Project. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for Ascend. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for Ascend, please send an email to ascendlic@<TBD>.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for Ascend.NET.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Text;

namespace Ascend.Resources
{
    /// <summary>
    /// Specifies the name of the category in which to group the property or event when displayed in a PropertyGrid control set to Categorized mode.
    /// </summary>
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = true)]
    public sealed class ResourceCategoryAttribute : CategoryAttribute
    {
        /// <summary>
        /// Looks up the localized name of the specified category. 
        /// </summary>
        protected override string GetLocalizedString(string value)
        {
            System.Resources.ResourceManager resourceManager = new System.Resources.ResourceManager("Ascend.Resources.DefaultResource", Assembly.GetExecutingAssembly()); ;
            return resourceManager.GetString(this.Category);

        }

        /// <summary>
        /// Initializes a new instance of the ResourceCategoryAttribute class using the specified resource name. 
        /// </summary>
        /// <param name="category">The category name.</param>
        public ResourceCategoryAttribute(string category) : base(category)
        {
        }

    }

}
